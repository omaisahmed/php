-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2019 at 03:28 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rainbow`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pcord` int(15) NOT NULL AUTO_INCREMENT,
  `pname` varchar(100) NOT NULL,
  `pdescription` varchar(2000) NOT NULL,
  `pimages` varchar(100) NOT NULL,
  `pprice` int(6) NOT NULL,
  `pstock` int(6) NOT NULL,
  `pcatagoey` varchar(100) NOT NULL,
  `pdrand` varchar(100) NOT NULL,
  PRIMARY KEY (`pcord`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pcord`, `pname`, `pdescription`, `pimages`, `pprice`, `pstock`, `pcatagoey`, `pdrand`) VALUES
(1, 'Pahchan Mart ', 'xyz', 'img\\men\\1.jpg', 2500, 20, 'Men Clothes', 'Men Facation'),
(2, 'Shalwar kameez', 'xyz', 'img\\men\\2.jpg', 7000, 10, 'Men Clothes', 'Men Faction '),
(3, 'Waistcoat', 'xyz', 'img\\men\\3.jpg', 5000, 15, 'Men Clothes', 'Men Faction '),
(4, 'Shalwar kameez', 'xyz', 'img\\men\\4.jpg', 4590, 15, 'Men Clothes', 'Men Faction '),
(5, 'Sherwani', 'xyz', 'img\\men\\5.jpg', 1599, 20, 'Men Clothes', 'Men Faction '),
(6, 'Waistcoat', 'xyz', 'img\\men\\9.jpg', 2599, 30, 'Men Clothes', 'Men Faction '),
(7, 'Urban Sole Casual Shoes Winter Collection - SS 7109', 'xyz', 'img\\men\\s1.jpg', 2999, 15, 'Shoes', 'Men Facation'),
(8, 'white stylish casual shoes for men', 'xyz', 'img\\men\\s2.jpg', 2500, 10, 'Shoes', 'Men Faction '),
(9, 'Stylish Nagra Brown Color for Man', 'xyz', 'img\\men\\s3.jpg', 3999, 15, 'Shoes', 'Men Faction '),
(10, 'Black Rubber Moccasins For Men', 'xyz', 'img\\men\\s4.jpg', 199, 40, 'Shoes', 'Men Faction '),
(11, 'Stylish Gucci Mens Fancy Shoes', 'xyz', 'img\\men\\s5.jpg', 7599, 20, 'Shoes', 'Men Faction '),
(12, 'Mardan Shoes Buy One Black Loafers Get One Brown Sandal Free For Men', 'xyz', 'img\\men\\s6.jpg', 1999, 30, 'Shoes', 'Men Faction '),
(13, 'Manjolica Floret Unstitched Single Shirt Grey Lawn Collection Vol. 1', 'xyz', 'img\\women\\wo1.jpg', 990, 50, 'clothes', 'Women Facation'),
(14, 'New Stylish Chiffon Embroided Suit For Women (Unstitched)', 'xyz', 'img\\women\\wo2.jpg', 4199, 40, 'Clothes', 'Women Faction '),
(15, 'Daraz Select Red 3PC Printed Unstitched Lawn Suit - Lawn ', 'xyz', 'img\\women\\wo3.jpg', 2299, 15, 'Clothes', 'Women Faction  '),
(16, 'E Passion Heavy Embrodered Chiffon Bridal Maxy', 'xyz', 'img\\women\\wo4.jpg', 24999, 5, 'Clothes', 'Women Faction '),
(17, 'Designer Embroidered Chiffon Bridal Dress UnStitched (SB-21)', 'xyz', 'img\\women\\wo5.jpg', 9999, 8, 'clothes', 'Women Faction '),
(18, 'Pakistani Bridal Dress 2018 - Peach', 'xyz', 'img\\women\\wo6.jpg', 7599, 15, 'clothes', 'Women Faction '),
(19, '4 Inches - Blue Velvet Heel For Her - Blue Colour', 'xyz', 'img\\women\\ws1.jpg', 1600, 50, 'shoes', 'Women Facation'),
(20, 'Fashion Formal Leena Red', 'xyz', 'img\\women\\ws2.jpg', 599, 40, 'shoes', 'Women Faction '),
(21, 'Leather Hand Made Pink Color Multani Khusa For Women KN-W-122', 'xyz', 'img\\women\\ws3.jpg', 1299, 15, 'shoes', 'Women Faction  '),
(22, 'Fashion Summer Women Slip On Bow Jelly Flats Sandals Beach Clear ', 'xyz', 'img\\women\\ws4.jpg', 1498, 15, 'shoes', 'Women Faction '),
(23, '3''''/8cm Ladies Heel Ivory Lace Crystal Pearls Wedding Bridal Shoes ', 'xyz', 'img\\women\\ws5.jpg', 5155, 12, 'shoes', 'Women Faction '),
(24, '\r\nWomen "Pearl" Closed Pointed Toe Patent Suede Upper Closed Heel Cu', 'xyz', 'img\\women\\ws6.jpg', 3899, 15, 'shoes', 'Women Faction '),
(25, 'LED Sports Watch - Black - for Men', 'xyz', 'img\\watches\\watch1.jpg', 99, 50, 'watches', 'Men / women Facation'),
(26, 'Kenneth Cole 15095003 - Stainless Steel Wrist Watch For Men - Silver', 'xyz', 'img\\watches\\watch2.jpg', 25000, 10, 'watches', 'Men / women Facation'),
(27, 'Rado Integral Mother of Pearl Watch for Men', 'xyz', 'img\\watches\\watch3.jpg', 473000, 15, 'watches', 'Men / women Facation'),
(28, '\r\nBrown Leather Double Bracelet Love Watch For Girls', 'xyz', 'img\\watches\\watch4.jpg', 299, 15, 'watches', 'Men / women Facation'),
(29, 'Stylish Brecelet Watch For Women/Girls', 'xyz', 'img\\watches\\watch5.jpg', 399, 20, 'watches', 'Men / women Facation'),
(30, 'Buy FAP Analog Paris Design Pink', 'xyz', 'img\\watches\\watch6.jpg', 1989, 30, 'watches', 'Men / women Facation'),
(31, 'Huawei Y7 Prime 2019 - 6.26" -3GB - 32GB -Blue', 'xyz', 'img\\mobile\\mobile1.jpg', 27998, 10, 'mobile', 'Men / women Facation'),
(32, 'Poplikdfr For Samsung A7 2018 3D Coloured Painted Leather Protective ', 'xyz', 'img\\mobile\\mobile2.jpg', 710, 15, 'mobile', 'Men / women Facation'),
(33, 'Nokia 216 White', 'xyz', 'img\\mobile\\mobile3.jpg', 7000, 15, 'mobile', 'Men / women Facation');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
