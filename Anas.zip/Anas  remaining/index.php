<!doctype html>
<html>
<?php
session_start();
 //unset($_SESSION['pcode']);
if (!isset($_SESSION["pcode"]))
{
	
	$_SESSION["pcode"]=array();
	$_SESSION["pqty"]=array();
	$_SESSION["index"]=0;
	$_SESSION["total"]=0;
}
else
{
	$_SESSION['expire'] =5*60;
}


$servername="localhost";
$uname="root";
$password="";
$dbname="rainbow";
$con=new MySQLi($servername,$uname,$password,$dbname);
$sql="select * from product";


?>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link rel="stylesheet" href="lib/css/bootstrap.min.css">
<!--<link rel="stylesheet" href="lib/styelsheet.css">-->
<link rel="stylesheet" href="lib/style.css">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
<script src="lib/js/bootstrap.min.js" ></script>

<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->



</head>

<body class="bg-light">
<nav class="navbar navbar-light bg-light">
<div class="logo-name" ><b>RAINBOW</b></div>
<div class="icon">
	

  <a href="addtocart.php" class="search_icon"><i class="fas fa-shopping-cart">(<?php echo $_SESSION["index"];?>)</i></a>
</div>
</nav>
<nav class="navbar sticky-top navbar-light bg-dark">

   <div class="d-flex justify-content-center h-100">
              
</nav>

      <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
      
       <!-- Modal Header -->
 <div class="modal-header bg-color">
 
          <h4 class="modal-title">Login </h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <form action="#" method="post">
        <div class="modal-body" >
        <h5>Email</h5>
     
          <input type="email" placeholder="Enter Your Email" name="email">
        	
           <h5>Password</h5>
          
          <input type="password" placeholder="Enter Your Password" name"P1">
        	
        </div>
        </form>
        <!-- Modal footer -->
        <div class="modal-footer" >
        <button type="submit" class="bu-color" data-dismiss="modal">Login</button>
        
        <button type="button" class="bu-color" data-dismiss="modal">Sign Up</button>
          <button type="button" class="bu-color" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
    
  </div>
  <!--Modal And--> 

<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container1">
	<div class="ws_images"><ul>
		<li><img src="data1/images/slide03.jpg" alt="slide-03" title="slide-03" id="wows1_0"/></li>
		<li><img src="data1/images/slide01.jpg" alt="slide-01" title="slide-01" id="wows1_1"/></li>
		<li><img src="data1/images/slide04.jpg" alt="slide-04" title="slide-04" id="wows1_2"/></li>
		<li><img src="data1/images/slide08.jpg" alt="slide-08" title="slide-08" id="wows1_3"/></li>
		<li><img src="data1/images/slide06.png" alt="slide-06" title="slide-06" id="wows1_4"/></li>
		<li><img src="data1/images/slide07.jpg" alt="slide-07" title="slide-07" id="wows1_5"/></li>
		<li><a href="http://wowslider.com/vf"><img src="data1/images/slide02.jpg" alt="full screen slider" title="full screen slider" id="wows1_6"/></a></li>
		<li><img src="data1/images/slide05.jpg" alt="slide-05" title="slide-05" id="wows1_7"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="slide-03"><img src="data1/tooltips/slide03.jpg" alt="slide-03"/>1</a>
		<a href="#" title="slide-01"><img src="data1/tooltips/slide01.jpg" alt="slide-01"/>2</a>
		<a href="#" title="slide-04"><img src="data1/tooltips/slide04.jpg" alt="slide-04"/>3</a>
		<a href="#" title="slide-08"><img src="data1/tooltips/slide08.jpg" alt="slide-08"/>4</a>
		<a href="#" title="slide-06"><img src="data1/tooltips/slide06.png" alt="slide-06"/>5</a>
		<a href="#" title="slide-07"><img src="data1/tooltips/slide07.jpg" alt="slide-07"/>6</a>
		<a href="#" title="full screen slider"><img src="data1/tooltips/slide02.jpg" alt="full screen slider"/>7</a>
		<a href="#" title="slide-05"><img src="data1/tooltips/slide05.jpg" alt="slide-05"/>8</a>
	</div></div><span class="wsl"><a href="http://wowslider.com/vu">image carousel</a> by WOWSlider.com v7.4</span>
	<div class="ws_shadow"></div>
	</div>	
	<script type="text/javascript" src="engine1/wowslider.js"></script>
	<script type="text/javascript" src="engine1/script.js"></script>
	<!-- End WOWSlider.com BODY section -->

<!--text Area-->

<nav class="navbar sticky-top navbar-light bg-dark">

   <div class="d-flex justify-content-center h-100">
        <div class="searchbar">
          <input class="search_input" type="text" name="" placeholder="Search...">
          <a href="#" class="search_icon"><i class="fas fa-search"></i></a>
        </div>
      </div><button class="bu-color" data-toggle="modal" data-target="#myModal">login</button>

       
</nav>
 
<br>
	<div class="size container">
    	<div id="rainbow-text" >
        <div id="rainbow-nav" >
        	<div id="text">
            <div>
            <h2>Category</h2>
            <?php
			$sql="select pcatagoey from product group by pcatagoey";
	$result=$con->query($sql);
	while($row=$result->fetch_assoc())
	{
		$catagoey=$row["pcatagoey"];
			
			echo "$catagoey<br>";
	}
			
			?>
            
            </div>
            </div>
            
        
        </div>
        
         <div id="rainbow-product" >
        	
<?php
$sql1="select * from product where pcatagoey='Men Clothes'";  
$result1=$con->query($sql1);

$count=1;
while ($row1=$result1->fetch_assoc())
{
$pcode=$row1["pcode"];
$catagoey=$row["pcatagoey"];


$name=$row1["pname"];
$price=$row1["pprice"];
$image=$row1["pimages"];
$e=$row1["pcatagoey"];
$f=$row1["pcode"];

echo" <div class='card'>";
 echo" <img class='card-img-top' src='$image' alt='raimbow'>";
 echo" <div class='card-body'>";
 echo"   <h5 class='card-title'>$name</h5>";
 echo"   <p class='card-text'><b>Rs:</b>$price</p>";
  echo"  <a href='cart.php?pcode=$pcode' class='btn btn-primary'>ADD TO CART</a>";
 echo" </div>";
echo"</div>";



$count++;
}
$_SESSION["name"]=$name;

$_SESSION["price"]=$price;
?>
    


  


        </div>
    		
        </div>
    </div>
<!--product end-->

<br>






<!-- Footer -->
<footer class="page-footer font-small blue-grey lighten-5 bg-color">

    <div class="bg-color">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">RAINBOW SHOPPING MART IN YOUR CITY (KARACHI)</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right f-link">

            <!-- Facebook -->
            
            <a class="fb-ic">
              <i class="fab fa-facebook-f white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic">
              <i class="fab fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic">
              <i class="fab fa-google-plus-g white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic">
              <i class="fab fa-linkedin-in white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic">
              <i class="fab fa-instagram white-text"> </i>
            </a>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class=" text-center text-md-left mt-5">

      <!-- Grid row -->
      <div class="row mt-3 dark-grey-text">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">Company name</h6>
          <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Products</h6>
          <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p class="para">
            <a class="dark-grey-text" href="#!">Pakistan</a>
          </p>
          <p class="para">
            <a class="dark-grey-text" href="#!">Pakistan</a>
          </p>
          <p class="para">
            <a class="dark-grey-text" href="#!">Pakistan</a>
          </p>
          <p class="para">
            <a class="dark-grey-text" href="#!">Pakistan</a>
          </p class="para">

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
          <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p class="para">
            <a class="dark-grey-text" href="#!">Your Account</a>
          </p>
          <p class="para">
            <a class="dark-grey-text" href="#!">Become an Affiliate</a>
          </p>
          <p class="para">
            <a class="dark-grey-text" href="#!">Shipping Rates</a>
          </p>
          <p class="para">
            <a class="dark-grey-text" href="#!">Help</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <i class="fas fa-home mr-3"></i> Pakistan Karachi</p>
          <p>
            <i class="fas fa-envelope mr-3"></i> anas@gmal.com</p>
          <p>
            <i class="fas fa-phone mr-3"></i> +92 3032841012</p>
          <p>

            <i class="fas fa-print mr-3"></i> +92 3032841012</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center text-black-50 py-3 bg-dark">© 2019 Copyright:
      <a class="dark-grey-text" href="https://mdbootstrap.com/education/bootstrap/"> Muhammad Anas.com</a>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->













 



</body>
</html>

