<?php

define('DB_NAME', 'uexel');

/** MySQL database username */
define('DB_USER', 'uexel');

/** MySQL database password */
define('DB_PASSWORD', 'XTAL');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Easypay Details */
define('HOST', 'https://uexel.com'); // your host
define('URL', 'https://uexel.com'); // url
define('STORE_ID', '1234');   // your store id
define('HASH_KEY', '23222sdfsafsf'); // your hash key
define('STORE_NAME', 'storename');        ///your store name
define('EXPIRY_DATE', '10'); /// days to expire
define('ORDER_PREFIX', 'cd');
define('LIVE', 'no');
define('PAYMENT_METHOD', ''); // null for all payment methods
define('AUTO_REDIRECT','0'); // 



?>