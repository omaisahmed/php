-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2019 at 01:21 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eliteshoppy`
--

-- --------------------------------------------------------

--
-- Table structure for table `popularproducts`
--

CREATE TABLE `popularproducts` (
  `pcode` varchar(50) NOT NULL,
  `id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `popularproducts`
--

INSERT INTO `popularproducts` (`pcode`, `id`) VALUES
('C-0001', 1),
('C-00010', 10),
('C-0002', 2),
('C-0003', 3),
('C-0004', 4),
('C-0005', 5),
('C-0006', 6),
('C-0007', 7),
('C-0008', 8),
('C-0009', 9);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pcode` varchar(50) NOT NULL,
  `pcategory` varchar(50) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `pprice` varchar(50) NOT NULL,
  `dprice` varchar(50) NOT NULL,
  `pdescription` varchar(50) NOT NULL,
  `pimage` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pcode`, `pcategory`, `pname`, `pprice`, `dprice`, `pdescription`, `pimage`) VALUES
('C-0001', 'mens', 'Formal Blue Shirt', 'Rs.600', 'Rs.650', 'Formal Blue Shirt', 'images/m1.jpg'),
('C-00010', 'womens', 'Sleeveless Solid Blue Top', 'Rs.1200', 'Rs.1250', 'Sleeveless Solid Blue Top', 'images/w2.jpg'),
('C-00011', 'womens', 'Skinny Jeans', 'Rs.1200', 'Rs.1250', 'Skinny Jeans', 'images/w3.jpg'),
('C-00012', 'womens', 'Black Basic Shorts', 'Rs.900', 'Rs.950', 'Black Basic Shorts', 'images/w4.jpg'),
('C-00013', 'womens', 'Pink Track Pants', 'Rs.950', 'Rs.1000', 'Pink Track Pants', 'images/w5.jpg'),
('C-00014', 'womens', 'Analog Watch', 'Rs.1500', 'Rs.1550', 'Analog Watch', 'images/w6.jpg'),
('C-00015', 'womens', 'Ankle Length Socks', 'Rs.350', 'Rs.400', 'Ankle Length Socks', 'images/w7.jpg'),
('C-00016', 'womens', 'Reebok Women\'s Tights', 'Rs.400', 'Rs.450', 'Reebok Women\'s Tights', 'images/w8.jpg'),
('C-00017', 'bags', 'Laptop Messenger Bag', 'Rs.1800', 'Rs.1900', 'Laptop Messenger Bag', 'images/b1.jpg'),
('C-00018', 'bags', 'Puma Backpack', 'Rs.2000', 'Rs.2100', 'Puma Backpack', 'images/b2.jpg'),
('C-00019', 'bags', 'Laptop Backpack', 'Rs.1800', 'Rs.2000', 'Laptop Backpack', 'images/b3.jpg'),
('C-0002', 'mens', 'Gabi Full Sleeve Sweatshirt', 'Rs.500', 'Rs.550', 'Gabi Full Sleeve Sweatshirt', 'images/m2.jpg'),
('C-00020', 'bags', 'Travel Duffel Bag', 'Rs.2200', 'Rs.2400', 'Travel Duffel Bag', 'images/b4.jpg'),
('C-00021', 'bags', 'Hand-held Bag', 'Rs.2500', 'Rs.2700', 'Hand-held Bag', 'images/b5.jpg'),
('C-00022', 'bags', 'Butterflies Bag', 'Rs.2800', 'Rs.3000', 'Butterflies Bag', 'images/b6.jpg'),
('C-00023', 'bags', 'Costa Swiss Bag', 'Rs.3000', 'Rs.3300', 'Costa Swiss Bag', 'images/b7.jpg'),
('C-00024', 'bags', 'Noble Designs Bag', 'Rs.2800', 'Rs.3000', 'Noble Designs Bag', 'images/b8.jpg'),
('C-00025', 'footwear', 'Running Shoes', 'Rs.3000', 'Rs.3500', 'Running Shoes', 'images/s1.jpg'),
('C-00026', 'footwear', 'Shoetopia Lace Up', 'Rs.2500', 'Rs.2800', 'Shoetopia Lace Up', 'images/s2.jpg'),
('C-00027', 'footwear', 'Steemo Casuals(Black)', 'Rs.2800', 'Rs.3000', 'Steemo Casuals(Black)', 'images/s3.jpg'),
('C-00028', 'footwear', 'Benetton Flip Flops', 'Rs.2500', 'Rs.2800', 'Benetton Flip Flops', 'images/s4.jpg'),
('C-00029', 'footwear', 'Moonwalk Bellies', 'Rs.2000', 'Rs.2200', 'Moonwalk Bellies', 'images/s5.jpg'),
('C-0003', 'mens', 'Dark Blue Track Pants', 'Rs.450', 'Rs.500', 'Dark Blue Track Pants', 'images/m3.jpg'),
('C-00030', 'footwear', 'Aero Canvas Loafers', 'Rs.2700', 'Rs.2900', 'Aero Canvas Loafers', 'images/s6.jpg'),
('C-00031', 'footwear', 'Sparx Sporty Canvas Shoes', 'Rs.3500', 'Rs.3800', 'Sparx Sporty Canvas Shoes', 'images/s7.jpg'),
('C-00032', 'footwear', 'Women BLACK Heels', 'Rs.3200', 'Rs.3500', 'Women BLACK Heels', 'images/s8.jpg'),
('C-0004', 'mens', 'Round Neck Black T-Shirt', 'Rs.400', 'Rs.450', 'Round Neck Black T-Shirt', 'images/m4.jpg'),
('C-0005', 'mens', 'Men\'s Black Jeans', 'Rs.500', 'Rs.550', 'Men\'s Black Jeans', 'images/m5.jpg'),
('C-0006', 'mens', 'Reversible Belt', 'Rs.300', 'Rs.350', 'Reversible Belt', 'images/m6.jpg'),
('C-0007', 'mens', 'Analog Watch', 'Rs.700', 'Rs.750', 'Analog Watch', 'images/m7.jpg'),
('C-0008', 'mens', 'Party Men\'s Blazer', 'Rs.650', 'Rs.700', 'Party Men\'s Blazer', 'images/m8.jpg'),
('C-0009', 'womens', 'A-line Black Skirt', 'Rs.1000', 'Rs.1050', 'A-line Black Skirt', 'images/w1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `popularproducts`
--
ALTER TABLE `popularproducts`
  ADD PRIMARY KEY (`pcode`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pcode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
