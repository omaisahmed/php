<?php
session_start();
$a=$_POST["t1"];
$b=$_POST["t2"];
$connect=mysqli_connect("localhost","root","","eliteshoppy");
$sql="select * from signup where email='$a' and password='$b'";
$result=$connect->query($sql);
$row=$result->fetch_assoc();
$user=$row["name"];
$_SESSION["name"]=$user;
if($result->num_rows>0)
{
header("location:index.php");
}
else
 {
	echo "<script>alert('Invalid Username or Password');</script>"; 
 }

?>