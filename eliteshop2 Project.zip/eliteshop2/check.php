<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
$a=$_POST["pincode"];

$servername="localhost";
$uname="root";
$password="";
$dbname="eliteshoppy";
$connect=new MySQLi($servername,$uname,$password,$dbname);
$sql="insert into checkout(Pincode) values('$a')";
$result=$connect->query($sql);

header("location:cart.php?click=signin");
?>

</body>
</html>