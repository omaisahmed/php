

        function validatesignup(){

            var a = document.getElementById("pass-signup").value;
            var b = document.getElementById("confirm_pass-signup").value;
            if (a!=b) {
               alert("Passwords do no match");
               return false;
            }
        }

        //function validatesignin(){
          //  var pass1 = document.getElementById("pass-signup").value;
            //var a = document.getElementById("email-signin").value;
            //var pass2 = document.getElementById("pass-signin").value;
            //if (pass1 == pass2) {
              // alert("Login Successfully!");

               //return false;
            //}
        //}
     