<?php
session_start();

$pcode=$_GET["pcode"];
$i=$_SESSION["index"];
$_SESSION["pcode"][$i]=$pcode;
$_SESSION["pqty"][$i]=1;
$i++;
$_SESSION["index"]=$i;

//header("location:javascript://history.back()");
//header('Location: ' . $_SERVER['HTTP_REFERER']);
header('Location: searchresult.php?search=mens');
//echo "<script>";
//echo "window.loca";
//echo "</script>";
//header("PHP[SELF]");
//window.history.back();
?>