<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Agregar nuevo proyecto de ley";
$_data['text_1_1'] 		= "Bill actualizaci�n";
$_data['text_2'] 		= "Informaci�n Nomenclatura";
$_data['text_3'] 		= "A�adir Bill";
$_data['text_4'] 		= "Formulario de Inscripci�n del proyecto de ley";
$_data['text_5'] 		= "Tipo de factura";
$_data['text_6'] 		= "Seleccionar el tipo de";
$_data['text_7'] 		= "Fecha de asunto";
$_data['text_8'] 		= "Bill Mes";
$_data['text_9'] 		= "Seleccione mes";
$_data['text_10'] 		= "Bill A�o";
$_data['text_11'] 		= "Seleccionar a�o";
$_data['text_12'] 		= "Cantidad total";
$_data['text_13'] 		= "Nombre Dep�sito bancario";
$_data['text_14'] 		= "detalles";
$_data['text_15'] 		= "Agregado Bill con �xito";
$_data['text_16'] 		= "Actualizaci�n Bill con �xito";
$_data['text_17'] 		= "";

?>