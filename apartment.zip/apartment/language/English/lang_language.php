<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Language Setup";
$_data['text_2'] 		= "Language Selection";
$_data['text_3'] 		= "Select language";
$_data['text_4'] 		= "Settings Updated Successfully";


?>