<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Owner Details";
$_data['text_2'] 		= "Owner Name";
$_data['text_3'] 		= "Designation";
$_data['text_4'] 		= "Email";
$_data['text_5'] 		= "Contact";
$_data['text_6'] 		= "Present Address";
$_data['text_7'] 		= "Member Details";
$_data['text_8'] 		= "Permanent Address";
$_data['text_9'] 		= "NID";

?>