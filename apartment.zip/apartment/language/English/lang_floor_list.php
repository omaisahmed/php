<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['floor_list_title'] 						= "Floor List";
$_data['add_new_floor_information_breadcam'] 	= "Floor Information";
$_data['delete_floor_information'] 				= "Deleted Floor Information Successfully.";
$_data['floor_no'] 								= "Floor No";
$_data['floor_details']							= "Floor Details";
$_data['add_floor'] 							= "Add Floor";
$_data['delete_msg'] 							= "Are you sure you want to delete this Floor ?";
$_data['add_msg'] 								= "Added Floor Information Successfully";
$_data['update_msg'] 							= "Update Floor Information Successfully";
?>