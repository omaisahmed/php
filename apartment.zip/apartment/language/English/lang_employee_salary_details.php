<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Salary Details";
$_data['text_2'] 		= "Issue Date";
$_data['text_3'] 		= "Month Name";
$_data['text_4'] 		= "Year";
$_data['text_5'] 		= "Amount";
$_data['text_6'] 		= "Employee Dashboard";
$_data['text_7'] 		= "Employee Details";
$_data['text_8'] 		= "Employee Name";
$_data['text_9'] 		= "Email";
$_data['text_10'] 		= "Contact";
$_data['text_11'] 		= "Present Address";
$_data['text_12'] 		= "Permanent Address";

?>