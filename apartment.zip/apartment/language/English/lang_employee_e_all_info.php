<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Salary Report";
$_data['text_2'] 		= "Issue Date";
$_data['text_3'] 		= "Month Name";
$_data['text_4'] 		= "Year";
$_data['text_5'] 		= "Amount";
$_data['text_6'] 		= "Print Information";

?>