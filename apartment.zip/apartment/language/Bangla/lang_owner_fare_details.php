<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাড়া বিস্তারিত";
$_data['text_2'] 		= "ভাড়াটিয়ার নাম";
$_data['text_3'] 		= "মেঝে সংখ্যা";
$_data['text_4'] 		= "ইউনিট সংখ্যা";
$_data['text_5'] 		= "মাস নাম";
$_data['text_6'] 		= "ভাড়া";
$_data['text_7'] 		= "মোট বিল";
$_data['text_8'] 		= "প্রদানের তারিখ";
$_data['text_9'] 		= "পানি বিল";
$_data['text_10'] 		= "বিদ্যুৎ বিল";
$_data['text_11'] 		= "গ্যাস বিল";
$_data['text_12'] 		= "নিরাপত্তা বিল";
$_data['text_13'] 		= "ইউটিলিটি বিল";
$_data['text_14'] 		= "অন্যান্য বিল";
$_data['text_15'] 		= "মোট ভাড়া";

?>