<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাড়া সংগ্রহ প্রতিবেদন";
$_data['text_2'] 		= "প্রতিবেদন";
$_data['text_3'] 		= "ভাড়া সংগ্রহ প্রতিবেদন ফরম";
$_data['text_4'] 		= "মেঝে নির্বাচন";
$_data['text_5'] 		= "ইউনিট নির্বাচন";
$_data['text_6'] 		= "মাস নির্বাচন";
$_data['text_7'] 		= "দাখিল করুন";

?>