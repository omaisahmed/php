<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "বছর সেটআপ";
$_data['text_2'] 		= "বছর এন্ট্রি ফর্ম";
$_data['text_3'] 		= "বছরের নাম";
$_data['text_4'] 		= "বছর তালিকা";
$_data['text_5'] 		= "বছর তথ্য সফলভাবে যোগ করা হয়েছে";
$_data['text_6'] 		= "বছর তথ্য সফলভাবে পরিবর্তন করা হয়েছে";
$_data['text_7'] 		= "বছর তথ্য সফলভাবে মূছে ফেলা হয়েছে";
$_data['text_8'] 		= "বছর বিবরণ";

?>