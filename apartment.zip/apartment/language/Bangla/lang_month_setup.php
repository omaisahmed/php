<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "মাস সেটআপ";
$_data['text_2'] 		= "মাস এন্ট্রি ফর্ম";
$_data['text_3'] 		= "মাসের নাম";
$_data['text_4'] 		= "মাস তালিকা";
$_data['text_5'] 		= "মাস তথ্য সফলভাবে যোগ করা হয়েছে";
$_data['text_6'] 		= "মাস তথ্য সফলভাবে পরিবর্তন করা হয়েছে";
$_data['text_7'] 		= "মাস তথ্য সফলভাবে মূছে ফেলা হয়েছে";
$_data['text_8'] 		= "মাস বিবরণ";

?>