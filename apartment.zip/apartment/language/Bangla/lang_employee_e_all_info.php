<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "বেতন প্রতিবেদন";
$_data['text_2'] 		= "প্রদানের তারিখ";
$_data['text_3'] 		= "মাস নাম";
$_data['text_4'] 		= "বছর";
$_data['text_5'] 		= "পরিমাণ";
$_data['text_6'] 		= "তথ্য প্রিন্ট";

?>