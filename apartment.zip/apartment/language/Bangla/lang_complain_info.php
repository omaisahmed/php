<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "তারিখ";
$_data['text_2'] 		= "মাস";
$_data['text_3'] 		= "বছর";
$_data['text_4'] 		= "শিরনাম";
$_data['text_5'] 		= "বিবরণ";
$_data['text_6'] 		= "অভিযোগ প্রতিবেদন";

?>