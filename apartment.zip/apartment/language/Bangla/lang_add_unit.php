<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_new_unit'] 								= "নতুন ইউনিট যোগ";
$_data['add_new_unit_entry_form'] 					= "ইউনিট এন্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 				= "মেঝে সংখ্যা";
$_data['add_new_form_field_text_2'] 				= "ইউনিট সংখ্যা";
$_data['add_new_unit_information_breadcam'] 		= "ইউনিট তথ্য";
$_data['add_new_unit_breadcam'] 					= "ইউনিট যোগ";
$_data['select_floor'] 								= "নির্বাচন করুন";
$_data['add_unit_successfully'] 					= "ইউনিট সফলভাবে যোগ হয়েছে";
$_data['update_unit_successfully'] 					= "ইউনিট সফলভাবে পরিবর্তন হয়েছে";

?>