<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 				= "ইউনিট তালিকা";
$_data['text_2'] 				= "মেঝে সংখ্যা";
$_data['text_3'] 				= "ইউনিট সংখ্যা";
$_data['text_4'] 				= "ইউনিট বিস্তারিত";
$_data['text_5'] 				= "মালিকের নাম";
$_data['text_6'] 				= "ই-মেইল";
$_data['text_7'] 				= "যোগাযোগের নম্বর";
$_data['text_8'] 				= "ঠিকানা";
$_data['text_9'] 				= "মালিক ড্যাশবোর্ড";

?>