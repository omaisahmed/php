<?php
define('CURRENCY', '$');
define('WEB_URL', 'http://localhost/PHP/Apartment%20Management%20System/');
define('ROOT_PATH', 'C:\xampp\htdocs\PHP\Apartment%20Management%20System/');


define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'dbapartment');
$link = mysql_connect(DB_HOSTNAME,DB_USERNAME,DB_PASSWORD) or die(mysql_error());mysql_select_db(DB_DATABASE, $link) or die(mysql_error());?>