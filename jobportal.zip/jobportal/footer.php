 <div style="width:100%;font-family:Arial, Helvetica, sans-serif; font-size:14px; background-color:#000; color:#FFFFFF; height:auto;border:solid 0px #CC0000;">
 <div style="width:1050px;font-family:Arial, Helvetica, sans-serif; font-size:14px; background-color:#000; color:#FFFFFF; margin:auto;height:auto;border:solid 0px #CC0000;">

<div style="width:1048px; height:auto; ">
	  <table style="width:1048px;font-family:Arial, Helvetica, sans-serif; font-size:14px;background-color:#000;color:#FFFFFF; height:auto;border:solid 0px #CC0000;">

	  <tr align="center">
	  <td style="width:18px; height:20px; border:solid 0px #99FF00;"></td>
	  <td style="width:80px; height:20px; border:solid 0px #99FF00;"><a href="" style=" text-decoration:none; color:#FFFFFF;">Resume Forward</a> </td>
	  <td style="width:80px; height:20px; border:solid 0px #99FF00;"><a href="#" style=" text-decoration:none; color:#FFFFFF;">Resume Writing</a></td>
	  <td style="width:60px; height:20px; border:solid 0px #99FF00;"><a href="#" style=" text-decoration:none; color:#FFFFFF;">Job Seeker </a></td>
	  <td style="width:75px; height:20px; border:solid 0px #99FF00;"><a href="#" style=" text-decoration:none; color:#FFFFFF;"> Career Report</a></td>
	  <td style="width:80px; height:20px; border:solid 0px #99FF00;"> <a href="#" style=" text-decoration:none; color:#FFFFFF;">Profile Verification</a></td>
	  <td style="width:70px; height:20px; border:solid 0px #99FF00;"><a href="#" style=" text-decoration:none; color:#FFFFFF;">Growth Combo</a></td>

	  <td style="width:75px; height:20px; border:solid 0px #99FF00;"><a href="#" style=" text-decoration:none; color:#FFFFFF;">My Account</a></td>
	   <td style="width:10px; height:20px; border:solid 0px #99FF00;"></td>
	  </tr>
	  </table>
</div>

<!--1-->
<div style="width:1048px; height:180px; border:#000000 0px solid; color:#FFFFFF;">
	 <div style="width:251px;background-color:#000;  height:170px; float:left;color:#FFFFFF; border:solid 0px #000000;">
	 <table style="width:250px; margin-left:0px;font-family:Arial, Helvetica, sans-serif;color:#FFFFFF; font-size:14px; height:auto;">



	  <tr style="color:#FFFFFF;">
	  <td width="125" ><a href="AboutUs.php" style="text-decoration:none;color:#FFFFFF;"> About Us</a></td>
	  <td width="113" > <a href="Privacy&Policy.php" style="text-decoration:none;color:#FFFFFF; ">Privacy & Policy</a></td>

	  </tr>

	     <tr>
	  <td > <a href="Terms&Condition.php" style="text-decoration:none;color:#FFFFFF; ">Terms & Conditions</a>
	  </td><td > <a href="ContactUs.php" style="text-decoration:none;color:#FFFFFF;">Contact Us</a></td>
	  </tr>
	  </table></div>


 <!--2--><div style="width:541px;background-color:#000;  height:170px; float:left;color:#FFFFFF; border:solid 0px #CCCCCC;">
<div style="width:470px; height:90px; background-color:#000; font-size:12px; border:#CCCCCC 1px solid;  border-radius: 10px; box-shadow: 0px 0px 10px #CCCCCC; margin-top:40px;  margin-bottom:20px; margin-left:20px;">

<div style=" width:450px; height:70px; color:#ACACAC; margin-left:10px; margin-right:10px; margin-bottom:10px; margin-top:5px;"align="justify">
<b>Disclaimer </b><br />
PHPGURUKUL Job Portal is a resume service provider. Though we help in circulating your resume to relevant avenues in the market for suitable jobs and many customers have benefited from over service, we do not guarantee jobs or interview calls by purchasing any product from us. </div>
</div>
</div>

<!--3-->
<div style="width:240px;background-color:#000;  height:170px; float:left;color:#FFFFFF; border:solid 1px #000;">
 <table height="165" style="width:251px; height:auto;color:#FFFFFF;font-family:Arial, Helvetica, sans-serif; font-size:14px;">
	  <tr>
	  <td colspan="2"><h3>Payment Methods</h3></td>
	  </tr>

	  <tr><td><img src="images/visa.jpg" width="88" /></td>
	    <td><img src="images/master_card.jpg"width="88" /></td></tr>
	   <tr><td>&nbsp;</td><td></td></tr>
	  <tr><td colspan="2">We also accept Indian Debit Cards and Net Banking. See all supported Payment Options.</td></tr>

	   </table>
</div>
</div>

