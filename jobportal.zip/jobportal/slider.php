 <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />

<div style="width:1048px; height:300px; border:solid 1px #D2D2FF;">

<div id="slider" style="width:1048px; height:300px;border:solid 0px #FFF;" align="center";>
<img src="images/pick-job-candidates.jpg"  height="345" width="1047"/>
<img src="images/slide12.png"  />
<img src="images/slide13.png"  />
	   </div>
       
       </div>