-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2019 at 11:47 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mharoonheavydrill`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

CREATE TABLE IF NOT EXISTS `adminuser` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`id`, `email`, `password`, `username`) VALUES
(1, 'Pakistan', '123456', 'Muhammad Haroon');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `images` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `description`, `images`, `category`) VALUES
(1, 'Submersible Pump Grundfos', 'Grundfos Stainless Steel SP pumps are known world-wide for their high efficiency and reliable service. Grundfos SP submersible pumps come in diameters from four to ten inches. Four inch pumps are available from 1.2 to 10 horsepower with flows from 5 to 75gpm. All Grundfos SP are made of corrosion resistant stainless steel and will provide years of reliable service. SP pumps combine the very best materials with superior hydraulic design. To understand true cost of ownership one must not only consider the initial cost but the cost of operation over the life of the pump. 85% of the total cost come during the pumps operation. That''s where Grundfos SP subermisble pumps shine .', 'img/submersible.jpg', 'Water Drilling'),
(2, 'Drill Bit For Water Well', 'Steel Tooth Rotary Bits are the most common types of drill bits, while Insert Bits are steel tooth bit with tungsten carbide inserts. Polycrystalline Diamond Compact Bits use synthetic diamonds attached to the carbide inserts. .', 'img/drill bit.jpg', 'Water Drilling'),
(3, 'Casing For Water Well', 'Casing is the tubular structure that is placed in the drilled well to maintain the well opening. Along with grout, the casing also confines the ground water to its zone underground and prevents contaminants from mixing with the water.', 'img/casing well.jpg', 'Water Drilling'),
(4, 'Plc Electric Panel', 'Electrical control panels are designed and used to control mechanical equipment. Each one is designed for a specific equipment arrangement and includes devices that allow an operator to control specified equipment. Electrical panel components control every piece of equipment in every industry.', 'img/electric panel.JPG', 'Water Drilling'),
(5, 'Gravel', 'A gravel pack is simply a downhole filter designed to prevent the production of unwanted formation sand. The formation sand is held in place by properly sized gravel pack sand that, in turn, is held in place with a properly-sized screen. To determine what size gravel-pack sand is required, samples of the formation sand must be evaluated to determine the median grain size diameter and grain size distribution.[1] The quality of the sand used is as important as the proper sizing. The American Petroleum Institute (API) has set forth the minimum specifications desirable for gravel-pack sand in API RP 58, Testing Sand Used in Gravel-Packing Operations', 'img/Gravel1.jpg', 'Water Drilling'),
(6, 'Water Well Pipe', 'Pipe-in-pipe systems are now commonly used to distribute water in many Norwegian homes. The inner pipe for drinking water is made of a plastic called cross-linked polyethylene (PEX). ... There are no health risks associated with drinking water from PEX pipes.', 'img/well pipe.jpg', 'Water Drilling'),
(7, 'Wire', 'Stainless steel wire is used in various applications in many different industries due to its popular characteristics. One of the greatest benefits of using stainless steel wire is its corrosion resistance. Stainless steel wire is also resistant to high temperatures and mechanical pressure.', 'img/wires.jpg', 'Water Drilling'),
(8, 'Submersible Pump Winding', 'The most common cause of failure in a Submersible Electric Motor is Overheating, as this causes the insulation materials in the motor to deteriorate until failure occurs. Sometimes the overheating can introduce other problems in the motor, before it fails, which accelerates the process.Jul', 'img/submersible pump winding.jpg', 'Motor Winding'),
(9, 'M Haroon Heavydrill', 'slider', 'img/slider1.jpg', 'Slider');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
