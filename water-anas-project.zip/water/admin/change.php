<!doctype html>
<?php
session_start();
$servername="localhost";
$uname="root";
$password="";
$dbname="mharoonheavydrill";
$con=new MySQLi($servername,$uname,$password,$dbname);
$sql="select * from  service";

$result=$con->query($sql);
$row=$result->fetch_assoc();	
	
	$name=$row["name"];
$image=$row["images"];
$description=$row["description"];
$category=$row["category"];

?>
<html>
	

	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<div class="jumbotron bg-dark">
		<h1 align="center" class="text-warning">Welcome <?php echo $_SESSION["name"] ?></h1>
		<a href="index.php" style="float: right"><input type="button" value="log out" class="bg-warning" style="height: 60px; width: 70px; border-radius: 50px; border: 0 solid; "></a>
</div>

        
             
	<div class="container">
		<p> <h1><?php echo $category ?></h1></p>
	</div>

	<?php	
	$sql1="select * from service where category='Water Drilling'";  
$result1=$con->query($sql1);
while ($row1=$result1->fetch_assoc())
{

$id=$row1["id"];
$name=$row1["name"];
$image=$row1["images"];
$description=$row1["description"];
$category=$row1["category"];
		         
  
    echo"<article class='jumbotron'>";
    echo"<div class=''>";
          echo" <div class='container'>";
  echo"<div class='row'>";
    echo"<div class='col-sm-8'>";
		echo"<br>";
       echo"<h1> $name </h1>";
		echo"<br>";
      echo"<p> $description </p>";
    echo"</div>";
	  echo"<div class='col-sm-4' align=center>";
		  echo" $image ";
	echo"<br><br>";
	echo"<a href='update.php?id=$id'><input type='button' value='Changeing' ></a>";
	  echo"</div>";
	   
        echo"</div>";
   echo"</div>";
		echo"</div>";
echo"</article>";

  
echo"</div>";
	echo"<br>";
	
}
	?>
	
	<br><br><br>
	
	<div class="container">
		<p> <h1><?php echo $category ?></h1></p>
	</div>

	<?php	
	$sql1="select * from service where category='Motor Winding'";  
$result1=$con->query($sql1);
while ($row1=$result1->fetch_assoc())
{


$name=$row1["name"];
$image=$row1["images"];
$description=$row1["description"];
$category=$row1["category"];
		         
  
    echo"<article class='jumbotron'>";
    echo"<div class=''>";
          echo" <div class='container'>";
  echo"<div class='row'>";
    echo"<div class='col-sm-8'>";
		echo"<br>";
       echo"<h1> $name </h1>";
		echo"<br>";
      echo"<p> $description </p>";
    echo"</div>";
	  echo"<div class='col-sm-4' align=center>";
		  echo" $image ";
		echo"<br><br>";
	echo"<a href=''><input type='button' value='Changeing' ></a>";
	  echo"</div>";
	   
        echo"</div>";
   echo"</div>";
		echo"</div>";
echo"</article>";

  
echo"</div>";
	echo"<br>";
	
}
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
</body>
</html>