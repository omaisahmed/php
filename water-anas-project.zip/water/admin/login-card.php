<!doctype html>
<?php
session_start();

?>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php

$a=$_POST["username"];
$b=$_POST["userpassword"];

$servername="localhost";
$uname="root";
$upassword="";
$dbname="mharoonheavydrill";

$con=new MYSQLi($servername,$uname,$upassword,$dbname);

$sql="select * from adminuser where email='$a' and password='$b'";

$result=$con->query($sql);
	 $row=$result->fetch_assoc();
	
	$name=$row["username"];
	
 if($result->num_rows>0)
 {
	 //echo $name;
	header("location:change.php");
	$_SESSION["name"]=$name;
 }
 else
 {
	echo "Invalid user"; 
 }
 
?>
</body>
</html>