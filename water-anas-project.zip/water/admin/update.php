<?php
session_start();
$id=$_GET["id"];
$_SESSION["pcode"][$i]=$id;