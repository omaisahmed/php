<!DOCTYPE html>
<?php
session_start();
$servername="localhost";
$uname="root";
$password="";
$dbname="mharoonheavydrill";
$con=new MySQLi($servername,$uname,$password,$dbname);
$sql="select * from  service";

?>
<!-- saved from url=(0067)https://www.epiroc.com/en-vn/products/drill-rigs/well-drilling-rigs -->
<html class="business solr js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" style=""><!-- G Services Disabled? false --><head class="at-element-marker"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <!-- Google Tag Manager -->
        <script type="text/javascript" async="" src="./index_files/recaptcha__en.js.download"></script><script type="text/javascript" async="" src="./index_files/analytics.js.download"></script><script async="" src="./index_files/gtm.js.download"></script><script>
            (function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({'gtm.start': new Date().getTime(), event: 'gtm.js'});
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-WRTZF56');
	</script>
<!--bootstrap link-->
	<link rel="stylesheet" href="lib/css/bootstrap.min.css">
<script src="lib/js/jquery-3.3.1.min.js"></script>
<script src="lib/js/bootstrap.min.js"></script>


	
	<!--bootstrap link -->
	
	
<!-- Mobile settings http://t.co/dKP3o1e -->
<meta name="HandheldFriendly" content="True">
<meta name="MobileOptimized" content="320">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- About this document -->
<meta name="author" content="Epiroc">

<!-- In order: first try the page title (=internalTitle - inner name - pagenode name -->
<title>mharoonheavydrill</title>
<meta keywords="mharoonheavydrill M haroon mharoonkhan Mharroon heavydrillmachine heavydrill heavydrillpress heavymachine heavymachinepriceinpakistan heavydrillingmud heavydrilling drillmachine drilling drillmeaninginurdu drillmachinepriceinpakistan">
	
<meta name="description" content="We offer a total solution for your well drilling needs.">




<!-- Twitter card data -->
<meta name="twitter:card" content="summary">
    
<meta name="twitter:site">
<meta name="twitter:title" content="Well drilling rigs - Epiroc">
<meta name="twitter:description" content="We offer a total solution for your well drilling needs.">

<!-- OpenGraph data-->
<meta property="og:title" content="Well drilling rigs - epiroc">
<meta property="og:type" content="article">
<meta property="og:description" content="We offer a total solution for your well drilling needs.">
<meta property="og:site_name" content="Epiroc">



<!-- Windows 8 tile -->
<meta name="application-name" content="Epiroc Website">
<meta name="msapplication-TileColor" content="#FFFFFF">
<meta name="msapplication-TileImage" content="tile.png">

<!-- No indexing tag for search engines -->

<!-- Canonical tags -->

<!-- Tags end -->

    <link href="./index_files/css" rel="stylesheet" type="text/css">
    <link href="./index_files/css(1)" rel="stylesheet">
    
<script type="text/javascript" src="./index_files/jquery.min.5e8d3382f82b03b0bf3fea3024eecd61.js.download"></script>
<script type="text/javascript" src="./index_files/handlebars.min.78c41acd2d2959129ef2c23ebde64f3b.js.download"></script>
<script type="text/javascript" src="./index_files/clientlib-preloaded.min.d2e3337a004f35fb9db7f247717daf19.js.download"></script>
  
<link rel="stylesheet" href="./index_files/clientlib-preloaded.min.a1a5a6dd4b4ecf380f62c085ec14903e.css" type="text/css">

            <script src="./index_files/satelliteLib-62a59cd7a68056ab7e1784055309ae6e66a38dd8.js.download"></script><script src="./index_files/mbox-contents-d49c6d03011e9c0011e62f41e8d33410669c48e0.js.download"></script><style id="at-makers-style" class="at-flicker-control">
.mboxDefault {visibility:hidden;}
</style>
        
<script src="./index_files/satellite-5a1d883c64746d108e000edb.js.download"></script><script src="./index_files/satellite-5a1d8a9c64746d284a006c2b.js.download"></script><script src="./index_files/s-code-contents-75bed0a4b037849fd4837544ab1b87d5e237f27d.js.download"></script><script src="./index_files/satellite-5bfbe93f64746d58170086ef.js.download"></script></head>
	<style >
	
		.border-active{
            background-color:#ffc72c;
    border:2px solid #fff;
        }
        
	
	</style>


<body class="c-site page-loaded">

	
	
 

<script>

var digitalData = {
        page: {
                pageInfo:{
                	pageID:"\/content\/products\/en\/drill\u002Drigs\/well\u002Ddrilling\u002Drigs",
                	onsiteSearchCategory:"",
                	onsiteSearchTerm:"",
                	onsiteSearchResults:"",
                	htmlStatus:"200",
                	errorpage:"", 
                	segmentSelected: ""
                },
                category:{
                	primaryCategory: "drill\u002Drigs",
                	subCategory1:"well\u002Ddrilling\u002Drigs",
                	subCategory2:"",
                	subCategory3:"",
                	subCategory4:"",
                	subCategory5:"",
                	subCategory6:"",
                	pageType:"\/apps\/business\/templates\/product\u002Drange",
                	businessDivision:"Surface and Exploration Drilling",
                	businessArea:"MR"   	
                },
                attributes:{
                	language:"English",
                	digitalChannel:"epiroc: web",
                	brand:"epiroc",
                	country:"Vietnam",
                	onsiteSearchType:"",
                	downloadType:"",
                	tags:""
                }
        },
        user:{
                profileInfo:{
                	profileID:"",
                	author: "false"
                },
        		attributes:{
        			loginStatus:""
        		}
        } 
};
digitalData.event=[];
digitalData.product=[];
digitalData.component=[];

if( false){
	var pagename = "well\u002Ddrilling\u002Drigs";
	digitalData.product.push({productInfo:{	productName : pagename	}});
}

</script>

   	

<div id="navigationDivBusiness" class="c-row c-row--relative u-z-beta u-bgcolor-darkblue" style="margin-top: 150px;">
	<!--nav -->
    <nav class="navbar navbar-expand-lg navbar-dark static-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
          <h4 class="text-warning">M Haroon Heavydrill</h4>
        </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>   
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="o-list c-nav-main-ba-ba navbar-nav ml-auto">
                
                                     
                            <li class="ignore-full-width c-nav-main-ba__item js-dropdown nav-item active border-active" data-target-selector="#dropdown-products">
                                <a href="index.php" class="c-nav-main-ba__link">Services</a>
		                       
		                        
		                    </li>
	                    
                           
	                                            
                            <li class="ignore-full-width c-nav-main-ba__item js-dropdown nav-item active " data-target-selector="#dropdown-services">
                                <a href="about.php" class="c-nav-main-ba__link">About Us</a>
		                        
		                    </li>
	                    
					<li class="ignore-full-width c-nav-main-ba__item js-dropdown nav-item active" data-target-selector="#dropdown-services">
                                <a href="#contact" class="c-nav-main-ba__link">Contact</a>
		                        
		                    </li>
	                    
                </ul>
	  </div>
	  </div>
            </nav>

		
    </div>

            
  <!--nav end-->
    
	<div class="c-row c-row--divider">
            <div class="c-breadcrumb" style="margin-bottom: 0px;">
               
            </div>
        </div>
    

        		<?php
$sql1="select * from service where category='Slider'";  
$result1=$con->query($sql1);
$row1=$result1->fetch_assoc();	
	
	
	$image=$row1["images"];
?>
        
        
   

    
    
    <div class="hero">


		<div class="container-fluid">
      <img src="<?php echo $image ?>" class="img-fluid img" alt="Responsive image" style="width: 100%">
</div>


      
	<div class="c-row c-row--divider">
            <div class="c-breadcrumb" style="margin-bottom: 0px;">
               
            </div>
        </div>
    


    
    <div class="s-editor">

    <div class="o-grid">
        
<!--Water Drilling-->
        
            <div class="o-grid__item u-2-of-3-bp4 u-4-of-4-bp5 u-bgcolor-lightgrey u-plr-zeta u-pt-zeta u-pb-zeta">
    
        <div class="s-editor">
            <div class="count-lg">           
	<div>
		<p class="u-color-darkblue u-mt-beta u-beta-font-weight"><h1>Water Drilling </h1> </p>
	</div>
            </div>
            <div class="o-grid">             
            </div>
            <div class="count-sm">                                
	<div>
		<p class="u-color-darkblue u-mt-beta u-beta-font-weight"> <h1>Water Drilling </h1></p>
	</div>
            </div>
        </div>
		<?php
$sql1="select * from service where category='Water Drilling'";  
$result1=$con->query($sql1);


while ($row1=$result1->fetch_assoc())
{


$name=$row1["name"];
$image=$row1["images"];
$description=$row1["description"];

	 //submersible pimp
    echo"<article class='u-bgcolor-hit u-b-mediumgrey'>";
    echo"<div class='o-grid u-z-alpha js-blocklink u-relative flex-bp3'>";
    echo"  <div class='o-grid__item u-plr-delta u-pt-epsilon u-pb-epsilon u-4-of-7-bp3 u-5-of-7-bp6 js-blocklink__link'>";
     echo"       <h5 class='c-product-range__title js-blocklink__link'>";
        echo"   <a href='#' class='js-blocklink__source'>$name</a>";
            echo"</h5>";
            echo"<p class='u-highlight u-mb-gamma u-color-darkblue'></p>";
            echo"<p class='u-highlight u-mb-gamma u-color-darkblue u-gamma-font-weight'>$description</p>";
            
       echo"<ul class='o-list c-list-ui u-mb-beta c-small'></ul>";

       echo" </div>";
                     echo"    <img src='$image'>";
   echo"</div>";
echo"</article>";


}		
?>   
</div>
		
	<!--Water Drilling End-->
	
	<!--Motor Winding-->
	
		<div class="o-grid__item u-2-of-3-bp4 u-4-of-4-bp5 u-bgcolor-lightgrey u-plr-zeta u-pt-zeta u-pb-zeta">       
        <div class="s-editor">
            <div class="count-lg">              
	<div>
		<p class="u-color-darkblue u-mt-beta u-beta-font-weight"><h1>Motor Winding  </h1> </p>
	</div>
            </div>
            <div class="o-grid">      
            </div>
            <div class="count-sm">          
	<div>
		<p class="u-color-darkblue u-mt-beta u-beta-font-weight"> <h1>Motor Winding </h1></p>
	</div>

            </div>
        </div>

        		<?php
$sql1="select * from service where category='Motor Winding'";  
$result1=$con->query($sql1);


while ($row1=$result1->fetch_assoc())
{


$name=$row1["name"];
$image=$row1["images"];
$description=$row1["description"];

	 //submersible pimp
    echo"<article class='u-bgcolor-hit u-b-mediumgrey'>";
    echo"<div class='o-grid u-z-alpha js-blocklink u-relative flex-bp3'>";
    echo"  <div class='o-grid__item u-plr-delta u-pt-epsilon u-pb-epsilon u-4-of-7-bp3 u-5-of-7-bp6 js-blocklink__link'>";
     echo"       <h5 class='c-product-range__title js-blocklink__link'>";
        echo"   <a href='#' class='js-blocklink__source'>$name</a>";
            echo"</h5>";
            echo"<p class='u-highlight u-mb-gamma u-color-darkblue'></p>";
            echo"<p class='u-highlight u-mb-gamma u-color-darkblue u-gamma-font-weight'>$description</p>";
            
       echo"<ul class='o-list c-list-ui u-mb-beta c-small'></ul>";

       echo" </div>";
                     echo"    <img src='$image'>";
   echo"</div>";
echo"</article>";


}		
?>		
</div>
	<!--Motor Winding End-->
</div>
</div>

<!--footer-->

<footer class="page-footer font-small unique-color-dark bg-dark text-light">

    <div class="bg-warning">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">M Haroon Heavydrill </h6>
          </div>
          <!-- Grid column -->


        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5 " id="contact">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Discover</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php" class="text-light">Services</a>
          </p>
          <p>
            <a href="about.php" class="text-light">About Us</a>
          </p>
          <p>
            <a href="#contact" class="text-light">Contact</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-3 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Services Available This provinces</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="#!" class="text-light">Sindh</a>
         <br>
            <a href="#!" class="text-light">Punjab</a>
          <br>
            <a href="#!" class="text-light">Balochistan</a>
         <br>
            <a href="#!" class="text-light">Khyber Pakhtunkhwa</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-2 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h5 class="text-uppercase font-weight-bold">Contact</h5>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            Muhammad Haroon</p>
          <p>
            m.haroonheavydrill@gmail.com</p>
          <p>
             + 92 3122432175</p>
          <p>
             + 92 3222325469</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

  </footer>
  <!-- Footer -->
<!--footer end-->
    
	<div>
	



<!--host name-->

<div class="c-subfooter-links o-grid o-grid--medium bg-warning">
    <div class="o-grid__item u-1-of-4-bp4 c-footer-panel">
        <div class="c-tagline">
    
        </div>
    </div>
    <div class="o-grid__item u-3-of-4-bp4 c-footer-panel">
        
        <ul class="c-nav-footer">
            <li class="c-nav-footer__item">
                <span class="c-nav-footer__text">© 2019 M Haroon Heavydrill</span>
            </li>
            
                
                <li class="c-nav-footer__item">
                    
                    <a href="#" class="c-nav-footer__link text-dark">Muhammad Anas</a>
                </li>
                
            
        </ul>
    </div>
</div>
		
<!--host name end-->
		
</div>



<!-- Always Load jQuery First -->
    <script src="./index_files/jquery.min.js.download"></script>
    
    <script>window.jQuery || document.write('<script src="/etc/designs/epiroccommons/clientlib-jquery/jquery.min.js"><\/script>')</script>

    
    
    
<script type="text/javascript" src="./index_files/csrf.min.7c38388879e68856a949a756438995e8.js.download"></script>
<script type="text/javascript" src="./index_files/clientlib-postloaded.min.5afe99327c05e68c50def84c17438941.js.download"></script>




    <script src="./index_files/api.js.download" async="" defer=""></script>

    
    


    <!--[if lte IE 8]>
    <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/v2-legacy.js"></script>
    <![endif]-->
    <script charset="utf-8" type="text/javascript" src="./index_files/v2.js.download"></script>

    <!-- DTM embeded ending tag -->
    
        
            <script type="text/javascript">if(typeof _satellite != 'undefined'){_satellite.pageBottom();}</script>
        
        
    
    <!-- DTM embeded ending tag -->
    




</div><iframe src="./index_files/satellite-5c123f7564746d181a012794.html" style="display: none;"></iframe><script type="text/javascript" id="">(function(){function a(){"none"!=b.style.display?dataLayer.push({event:"event_contact_form_submitted"}):setTimeout(a,500)}var b=document.querySelector("form.basic-form .js-alert-success-zone");b&&a()})();</script></body></html>