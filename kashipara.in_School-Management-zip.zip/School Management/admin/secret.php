<?php
define("ADMINUSER", "INDIA");
define("ADMINPASSWORD", "GUJARAT");
define("ADMINHOME", "index.php");
?>