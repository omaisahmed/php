<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"> 
<html> 
<head> 
<title>:SAHJANAND VIDHAYALAY,RAJKOT::</title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link  rel="stylesheet" href="style.css" type="text/css"> 
 <link href="images/title.gif" rel="shortcut icon" type="image/x-icon" > 

 <style type="text/css">
<!--
.style2 {
	font-size: 18px;
	color: #999999;
}
.style5 {font-size: 1px}
-->
 </style>
</head> 
 
<body  leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#E2F0FE"> 
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0"> 
  <tr> 
    <td valign="top" height="18" colspan="2"> 
      <style type="text/css"> 
<!--
.style1 {color: #336666}
-->
</style> 
<a  name="top"></a> 
<table cellpadding="0" cellspacing="0"> 
  <tr> 
    <td colspan="2"><img  src="images/banner.gif" width="1019" height="103"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> <td height="21" colspan="2" align="right" background="images/toplinkbg.gif"> 
      <p>&nbsp;&nbsp;&nbsp; <a  href="index.php"><img src="images/link_home.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="about.php"><img src="images/link_about.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="contact.php"><img src="images/link_contact.gif"  align="middle" border="0"></a> </p></td> </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
</table> 
</td> 
  </tr> 
  <tr> 
    <td valign="top" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%" > 
        <tr><td width="13%" background="images/side.gif"  valign="top"> <style type="text/css"> 
<!--
.style1 {
	font-size: 13px;
	font-weight: bold;
	color: #99FF00;
}
-->
</style> 
<table width="160" border="0" cellspacing="0" cellpadding="0"> 
   <tr> 
    <td height="26"><a  href="index.php"><font size="+1">Home</font></a></td> 
  </tr> 
  <tr> 
    <td height="26"><a  href="about.php"><font size="+1">About us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="standard.php"><font size="+1">Standard</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="STAFF.php"><font size="+1">Staff</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="admission.php"><font size="+1">Admission</font></a></td> 
  </tr> 
 
  <tr> 
    <td height="26" ><a  href="activity.php"><font size="+1">StudentActivity</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="contact.php"><font size="+1">Contact us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="feedback.php"><font size="+1">Feedback</font></a></td> </tr>
    <td>&nbsp;</td> 
  </tr> 
</table> 
<p>&nbsp;</p></td> 
          <td width="83%" valign="top" bgcolor="#E6FBF3"> 
            <table width="98%" border="0" cellspacing="0" cellpadding="0" align="center"> 
              <tr> 
                <td><table width="100%"  border="0" cellspacing="1" cellpadding="1" align="center" class="border"> 
                  <tr> 
                    <td bgcolor="#E2F0FE"> 
                      
                     <table width="100%" cellpadding="0" cellspacing="0"> 
                        
						<tr>
						<td align="center"height="20" colspan="3" ><span class="style2">INSTITUTE</span></td>
						
						<tr> 
						<td width="5%">&nbsp;</td>
                          <td width="93%" height="135" bclass ="maintaxt">
						  <p align ="justify" class="paragraph"><b>Sahjanand Vidhyalay</b>&nbsp;&nbsp;is a premier school in Rajkot  set with the objectives of imparting higher education in various Standard of School. The school is affiliated to Gujarat Board and school is established in 1990 . It is situated adjacent to Gujrat Board. The campus is having building for various class, offices, hostels, library with 20,000 sq.m. plinth area. The School made a modest start with 75 students for programs in 1990.</p>
							</td>              
							<td width="1%">&nbsp;</td>
							
                        </tr> 
						<tr> 
						  <td width="5%">&nbsp;</td>
                          <td height="135"class="maintaxt">
						  <p align ="justify" class="paragraph"> &#8226;	To plan, develop, execute and monitor technical education programs, as per National and State level education policy and in tune with needs  of society and school.<br>

&#8226;	To endeavour for strong linkages with board, research computer lab and professional to provide quality.<br>

&#8226;	To establish liaison with professional and statutory organizations.<br>

&#8226;	To provide research, training and development opportunity to students, staff, teachers and professionals of the subject. 
 </p>							</td>  
							            
							<td width="1%">&nbsp;</td>
                        </tr> 
						<tr> 
						  <td width="5%">&nbsp;</td>
                          <td height="135"class="maintaxt">
						  <p align="justify" class="paragraph"> &#8226;	For the year 2010 we have to achieve our goal in any manner to become the most powerful Student. we will try our best effort to overcome the limitation of our School and to manage our mistakes.
To plan, develop, execute and monitor technical education programs, as per National and State level education policy and in tune with needs  of society.<br>





 </p>							</td>  
							            
							<td width="1%">&nbsp;</td>
                        </tr> 
                      </table> 
					  </td>
                  </tr> 
                </table></td> 
              </tr> 
              <tr> 
                <td>&nbsp;</td> 
              </tr> 
          </table>
		  </td> 
        </tr> 
        <tr> 
          <td colspan="2" valign="top" height="1"></td> 
        </tr><tr><td colspan="2" height="20" valign="top">		     <table width="100%"  border="0" cellspacing="1" cellpadding="1" background="images/bottom.gif">
<tr> <td width="67%" height="26" align="right" valign="middle">&copy; SAHJANAND VIDHAYALAY RAJKOT.</td>
  <td width="33%" align="right"><font face="verdana" style="font-size:10px" color="#006666">Website design and developed by:<a href="mailto:kamlesh.chetankumar@gmail.com">KAMLESH AND CHETANKUMAR</a></font></td>
	</tr> 
  
  <tr>
</table> 
<div align="center"></div> 
          </td> 
        </tr> 
    </table></td> 
  </tr> 
</table> 
</body> 
</html> 