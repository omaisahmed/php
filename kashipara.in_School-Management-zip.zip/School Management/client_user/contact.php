<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"> 
<html> 
<head> 
<title>::SAHJANAND VIDHAYALAY,RAJKOT::</title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link  rel="stylesheet" href="style.css" type="text/css"> 
 <link href="images/title.gif" rel="shortcut icon" type="image/x-icon"> </head> 
 
<body  leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#E2F0FE"> 
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0"> 
  <tr> 
    <td valign="top" height="18" colspan="2"> 
      <style type="text/css"> 
<!--
.style1 {color: #336666}
-->
</style> 
<a  name="top"></a> 
<table cellpadding="0" cellspacing="0"> 
  <tr>
    <td colspan="2"><img  src="images/banner.gif" width="1021" height="103"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> <td height="21" colspan="2" align="right" background="images/toplinkbg.gif">  <p>&nbsp;&nbsp;&nbsp; <a  href="index.php"><img src="images/link_home.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="about.php"><img src="images/link_about.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="contact.php"><img src="images/link_contact.gif"  align="middle" border="0"></a> </p></td> </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
</table> 
</td> 
  </tr> 
  <tr> 
    <td valign="top" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"> 
        <tr><td width="13%" background="images/side.gif"  valign="top"> <style type="text/css"> 
<!--
.style1 {
	font-size: 13px;
	font-weight: bold;
	color: #99FF00;
}
-->
</style> 
<table width="160" border="0" cellspacing="0" cellpadding="0">  <tr> 
   <tr> 
    <td height="26"><a  href="index.php"><font size="+1">Home</font></a></td> 
  </tr> 
  <tr> 
    <td height="26"><a  href="about.php"><font size="+1">About us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="standard.php"><font size="+1">Standard</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="STAFF.php"><font size="+1">Staff</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="admission.php"><font size="+1">Admission</font></a></td> 
  </tr> 
 
  <tr> 
    <td height="26" ><a  href="activity.php"><font size="+1">StudentActivity</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="contact.php"><font size="+1">Contact us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="feedback.php"><font size="+1">Feedback</font></a></td> </tr>
    <td>&nbsp;</td> 
  </tr> 
  
</table> 
</td> 
          <td width="83%" valign="top" bgcolor="#E6FBF4"> 
            <table width="99%" border="0" cellspacing="1" cellpadding="1" align="center"> 
              <tr> 
                <td><table width="100%"  border="0" cellspacing="1" cellpadding="1" align="center" class="border"> 
                  <tr> 
                    <td  bgcolor="#E2F0FE"> 
                      <table cellpadding="0" cellspacing="0" width="100%"> 
                        <tr><td valign="middle" colspan="4"  background="images/header.gif"class=title><img src="images/decoration_head.png" align="absmiddle">&nbsp;&nbsp;Contac us&nbsp;&nbsp;<img src="images/decoration_head.png" align="absmiddle"></td> 
                        </tr> 
                      </table> 
                      <br><table width="100%" cellpadding="0" cellspacing="5" bgcolor="#E2F0FE"> 
                        <tr> 
                        
                        <tr valign="middle"> 
                          <td height="135"><TABLE BORDER="0"ALIGN="center" CELLPADDING="0" CELLSPACING="0" bgcolor="#E2F0FE" class="umesh" ID="table9"> 
                                  <TR> 
                                    
                                  </TR> 
                                  
                                  <TR> 
                                    <TD CLASS="normal" ALIGN="center" VALIGN="top"> 
                                      
                                        <TABLE ID="table10" BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="502"> 
                                          <!-- MSTableType="layout" --> 
                                          <TR class="gbg"> 
                                            <TD width="134" ALIGN="right" CLASS="fheader"><div align="center"><strong><font size="+1">Address</font></strong></div>
                                            <div align="center"><img src="images/address.png" align="middle"></div></TD> 
                                            <TD width="361" HEIGHT="23" CLASS="normal"><font size="-1">The Principal</font>,</TD> 
                                          </TR> 
                                          <TR class="lgbg"> 
                                            <TD CLASS="fheader" ALIGN="right">&nbsp;</TD> 
                                            <TD CLASS="normal" HEIGHT="23"><font size="-1">Sahjanand Vidhyalay,</font></TD> 
                                          </TR> 
                                          <TR class="gbg"> 
                                            <TD CLASS="fheader" ALIGN="right">&nbsp;</TD> 
                                           <TD CLASS="normal" HEIGHT="23"><font size="-1">Shivam Society,Raiya Road,</font></TD> 
                                          </TR> 
                                          <TR class="lgbg"> 
                                            <TD CLASS="fheader" ALIGN="right">&nbsp;</TD> 
                                            <TD CLASS="normal" HEIGHT="23"><font size="-1">Rajkot-360 005. </font></TD> 
                                          </TR> 
                                          <TR class="gbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><strong>&nbsp;&nbsp;&nbsp;</strong></TD> 
                                            <TD CLASS="normal" HEIGHT="23"><font size="-1">Gujarat</font></TD> 
                                          </TR> 
                                           <TR class="lgbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><div align="center"><strong><font size="+1">Phone(O.)</font></strong><img src="images/icon_phone.gif" align="middle"></div></TD> 
                                            <TD HEIGHT="24" CLASS="normal"><font size="-1">+91 281 2554232 </font></TD> 
                                          </TR> 
                                          <TR class="gbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><div align="center"><b><font size="+1">Country</font></b></div><div align="center"><img src="images/country.jpg" align="middle"></div></TD> 
                                            <TD CLASS="normal" HEIGHT="23">India</TD> 
                                          </TR> 
                                          <TR class="lgbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><div align="center"><strong><font size="+1">Fax</font></strong></div><div align="center"><img src="images/icon_fax.gif" align="middle"></div></TD>
                                            <TD HEIGHT="24" CLASS="normal"><font size="-1">+91 281  2554232 </font></TD> 
                                          </TR> 
										   <TR class="gbg"> 
                                            <TD ALIGN="right" CLASS="fheader"><div align="center"><strong><font size="+1">Time</font></strong></div><div align="center"><img src="images/time.png" align="middle"></div></TD> 
                                            <TD HEIGHT="24" CLASS="normal"><font size="-1">9 a.m to 6 p.m (Monday - Saturday)</font>
											 </TD> 
                                          </TR>
                                          <TR class="lgbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><div align="center"><strong><font size="+1">E-mail &nbsp;</font></strong><img src="images/icon_email.gif" align="middle"></div></TD> 
                                            <TD CLASS="normal" HEIGHT="24"> <A  HREF="mailto:principal_scem@gmail.com"> <font size="-1">principal_scem@gmail.com</font></A></TD> 
                                          </TR> 
										  <TR class="gbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><div align="center"><B><font size="+1">Web&nbsp;</font></B></div><div align="center"><img src="images/browser.png" align="middle"></div></TD> 
                                            <TD CLASS="normal" HEIGHT="24"> <A  HREF="http://www.scem.com" target="_blank"><font size="-1">www.scem.com</font></A></TD> 
                                          </TR> 
										   <TR class="lgbg"> 
                                            <TD CLASS="fheader" ALIGN="right"><div align="center"><B><font size="+1">Reach us</font></B></div><div align="center"><img src="images/icon_satelite.gif" align="middle"></div></TD> 
                                            <TD CLASS="normal" HEIGHT="24"> <A  HREF="http://maps.google.com/maps/ms?ie=UTF8&hl=en&msa=0&msid=103691345185033842238.0004508e27e9123c7bb1b&ll=31.255359,75.70389&spn=0.006475,0.009398&t=h&z=17" target="_blank"><font size="-1">satellite view on google map</font></A></TD> 
                                          </TR> 
								      </TABLE>
								    </TD>
										  </TR>
										  
										  </TABLE>
										  
						  	</td>              
                        </tr> 
                      </table> 
                      </td> 
                  </tr> 
                </table></td> 
              </tr> 
              <tr> 
                <td>&nbsp;</td> 
              </tr> 
          </table></td> 
        </tr> 
        <tr> 
          <td colspan="2" valign="top" height="2"></td> 
        </tr><tr><td colspan="2" height="20" valign="top">		     <table width="100%"  border="0" cellspacing="1" cellpadding="1" background="images/bottom.gif">
<tr> 
    <td height="26" align="center" valign="bottom"><div align="center">&copy; SAHJANAND VIDHAYALAY,RAJKOT </div></td>
	</tr> 
</table> 
<div align="center"></div> 
          </td> 
        </tr> 
    </table></td> 
  </tr> 
</table> 
</body> 
</html> 