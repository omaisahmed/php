<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"> 
<html> 
<head> 
<title>::SAHJANAND VIDHYALAY,RAJKOT::</title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link  rel="stylesheet" href="style.css" type="text/css"> 
 <link href="images/title.gif" rel="shortcut icon" type="image/x-icon"> </head > 
 
<body  leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#E2F0FE"> 
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0"> 
  <tr> 
    <td valign="top" height="18" colspan="2"> 
      <style type="text/css"> 
<!--
.style1 {color: #336666;}
-->
</style> 
<a  name="top"></a> 
<table cellpadding="0" cellspacing="0"> 
  <tr> 
    <td colspan="2"><img  src="images/banner.gif" width="1020" height="103"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> <td height="21" colspan="2" align="right" background="images/toplinkbg.gif">  <p>&nbsp;&nbsp;&nbsp; <a  href="index.php"><img src="images/link_home.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="about.php"><img src="images/link_about.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="contact.php"><img src="images/link_contact.gif"  align="middle" border="0"></a> </p></td> </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
</table> 
</td> 
  </tr> 
  <tr> 
    <td valign="top" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"> 
        <tr><td width="13%" background="images/side.gif"  valign="top"> <style type="text/css"> 
<!--
.style1 {
	font-size: 13px;
	font-weight: bold;
	color: #99FF00;
}
-->
</style> 
<table width="160" border="0" cellspacing="0" cellpadding="0">  <tr> 
     <tr> 
    <td height="26"><a  href="index.php"><font size="+1">Home</font></a></td> 
  </tr> 
  <tr> 
    <td height="26"><a  href="about.php"><font size="+1">About us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="standard.php"><font size="+1">Standard</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="STAFF.php"><font size="+1">Staff</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="admission.php"><font size="+1">Admission</font></a></td> 
  </tr> 
 
  <tr> 
    <td height="26" ><a  href="activity.php"><font size="+1">StudentActivity</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="contact.php"><font size="+1">Contact us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="feedback.php"><font size="+1">Feedback</font></a></td> </tr>
    <td>&nbsp;</td> 
   
   
  </tr> 
</table> 
</td> 
          <td width="83%" valign="top" bgcolor="#E6FBF4"> 
            <table width="99%" border="0" cellspacing="1" cellpadding="1" align="center"> 
              <tr> 
                <td><table width="100%"  border="0" cellspacing="1" cellpadding="1" align="center" class="border"> 
                  <tr> 
                    <td bgcolor="#E2F0FE"><table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                      <tr>
                        <td align="center" height="20" background="images/about_missionbg.gif" colspan="3"></td>
                      </tr>
                      <tr>
                        <td width="10%">&nbsp;</td>
                        <td height="90"class="maintaxt"><p align="justify" class="paragraph"> The mission of sahjanand vidhyalay is to deliver student  and services to meet the changing needs of society  and thereby contribute to overall school development of the State in particular and Nation in general and improve quality of life of communities. Our motto is   "Create State's Best School &quot;. </p></td>
                        <td width="10%">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="center" height="20" background="images/about_vision.gif" colspan="3"></td>
                      </tr>
                      <tr>
                        <td width="2%">&nbsp;</td>
                        <td height="60"class="maintaxt"><p align="justify" class="paragraph"> sahjanand vidhyalay will be known for excellence in study of education with first choice for all students, society. where quality is the way of life.The sahjanand school, Rajkot will be one of the pioneer institute which will impart excellent  education and training, hence it is first choice among the all students and its pass out students are also a first choice of good cours. The institute will impart not only education but also transferring technology to rural community so as to improve quality of society.</p></td>
                        <td width="2%">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="center" height="20" background="images/about_quality.gif" colspan="3"></td>
                      </tr>
                      <tr>
                        <td width="2%">&nbsp;</td>
                        <td height="60"class="maintaxt"><p align="justify" class="paragraph"> Our core values are quality, equity, morality, environmental sustainability, energy saving and strong committment to the cause of  education and study.
                          
                          We believe in....<br>
                          * Equitable and harmonious growth of students, staff, society.<br>
                          * Quality education to train students enlightened with vision to be committed citizen with strong civic sense and&nbsp;&nbsp;high moral standard having concern  for local and global issues. </p></td>
                        <td width="2%">&nbsp;</td>
                      </tr>
                    </table></td> 
                  </tr> 
                </table></td> 
              </tr> 
              <tr> 
                <td>&nbsp;</td> 
              </tr> 
          </table></td> 
        </tr> 
        <tr> 
          <td colspan="2" valign="top" height="1"></td> 
        </tr><tr><td colspan="2" height="20" valign="top">		     <table width="100%"  border="0" cellspacing="1" cellpadding="1" background="images/bottom.gif">
<tr> 
    <td height="26" align="center" valign="bottom">&copy; SAHJANAND VIDHYALAY,RAJKOT</td>
	</tr> 
  
  <tr>
</table> 
<div align="center"></div> 
          </td> 
        </tr> 
    </table></td> 
  </tr> 
</table> 
</body> 
</html> 