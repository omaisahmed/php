<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"> 
<html> 
<head> 
<title>::SAHJANAND VIDHYALAY,RAJKOT::</title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link  rel="stylesheet" href="style.css" type="text/css"> 
 <link href="images/title.gif" rel="shortcut icon" type="image/x-icon"> </head > 
 
<body  leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#E2F0FE"> 
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0"> 
  <tr> 
    <td valign="top" height="18" colspan="2"> 
      <style type="text/css"> 
<!--
.style1 {color: #006666;}
-->
</style> 
<a  name="top"></a> 
<table cellpadding="0" cellspacing="0"> 
  <tr> 
    <td colspan="2"><img  src="images/banner.gif" width="1035" height="103"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
  <tr> <td height="21" colspan="2" align="right" background="images/toplinkbg.gif">  <p>&nbsp;&nbsp;&nbsp; <a  href="index.php"><img src="images/link_home.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="about.php"><img src="images/link_about.gif" align="middle" border="0"><img src="images/separator.gif" align="middle" border="0"></a><a  href="contact.php"><img src="images/link_contact.gif"  align="middle" border="0"></a> </p></td> </tr> 
  <tr> 
    <td height="2" colspan="2"></td> 
  </tr> 
</table> 
</td> 
  </tr> 
  <tr> 
    <td valign="top" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"> 
        <tr><td width="13%" background="images/side.gif"  valign="top">
	 <style type="text/css"> 
<!--

.style1 {
	font-size: 13px;
	font-weight: bold;
	 color:#009999
}
-->
</style> 

<table width="160" border="0" cellspacing="0" cellpadding="0">  <tr> 
    <tr> 
    <td height="26"><a  href="index.php"><font size="+1">Home</font></a></td> 
  </tr> 
  <tr> 
    <td height="26"><a  href="about.php"><font size="+1">About us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="standard.php"><font size="+1">Standard</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="STAFF.php"><font size="+1">Staff</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="admission.php"><font size="+1">Admission</font></a></td> 
  </tr> 
 
  <tr> 
    <td height="26" ><a  href="activity.php"><font size="+1">StudentActivity</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="contact.php"><font size="+1">Contact us</font></a></td> 
  </tr> 
  <tr> 
    <td height="26" ><a  href="feedback.php"><font size="+1">Feedback</font></a></td> </tr>
    <td>&nbsp;</td> 
  </tr> 
 
</table> 
</td> 
          <td width="83%" valign="top" bgcolor="#E6FBF4"> 
            <table width="99%" border="0" cellspacing="1" cellpadding="1" align="center"> 
              <tr> 
                <td><table width="100%"  border="0" cellspacing="1" cellpadding="1" align="center" class="border"> 
                  <tr> 
                    <td bgcolor="#E2F0FE"> 
                       
                      <table width="100%" cellpadding="0" cellspacing="0"> 
                        <tr> 
						<tr>
						<td align="center" height="20"  background="images/activity_ncc.gif"colspan="3"></td>
						</tr>
                        
                        <tr> 
						<td width="2%">&nbsp;</td>
                          <td height="90"class="maintaxt"><ul> 
                                  <li class="style1"> 
                                    <div align="justify" class="paragraph">An associated N.C.C. officer (ANO) LT. Shri R.B.Gandhi is looking After N.C.C. activities in the institute.</div> 
                                  </li> 
                                  <li class="style1"> 
                                    <div align="justify" class="paragraph">Authorized intake of 50 cadets is available with the institute.</div> 
                                  </li> 
                                  <li class="style1"> 
                                    <div align="justify" class="paragraph">Annual training camps of 12 day duration, twice in a year during January &amp; June/July, within Gujarat are organized.</div> 
                                  </li> 
                                  <li class="style1"> 
                                    <div align="justify" class="paragraph">Our N.C.C. cadets serve the nation during natural disasters like Earthquake etc. by offering their services during relief work.</div> 
                                  </li> 
                                </ul>
							</td>    
						<td width="2%">&nbsp;</td>
          
                        </tr> 
						<tr>
							<td align="center" height="20"  background="images/activity_gym.gif" colspan="3"></td>
						</tr>
						<tr> 
         				<td width="2%">&nbsp;</td>
                          <td height="60"class="maintaxt">
						  <ul> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph">Elocution competition and debate are organized once in a Semester and prizes are given to first and second winners.</div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph">Students can participate in technical exhibitions way of presenting modes, charts etc., When &amp; Where ever it is organized and winners are given prizes.</div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph">Campus has retained and increased its green cover by way of tree - plantation programs with the help of state forest department.</div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph">Under the head of the Students&rsquo; Gymkhana various extra curricular activities like Sports tournaments, Quiz, Celebration of National Days Annual function, Blood donation Camp, and Thalassemia Tests for all students are carried out. The deserving students who have shown their exception even in their study are felicitated with the memento and certificates.                                        </div> 
                                    </li> 
                                </ul>
							</td>              
							<td width="2%">&nbsp;</td>
                        </tr> 
						<tr>
							<td align="center" height="20" background="images/activity_chapter.gif"colspan="3"></td>
						</tr>
						<tr> 
						<td width="2%">&nbsp;</td>
                          <td height="60"class="maintaxt">
						  <ul> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph"> 
                                          This cell provides carrier guidance as well as any type of carrier related guidance to students.</div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph"> 
                                          If you are a sports enthusiast, the institute has indoor and outdoor sports facilities. The institute organizes cricket competition, volley ball Competition, 100 mts. running competition, chess competition etc. once in year.</div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph"> 
                                          Cultural activities and entertainments programs are also organized. </div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph"> 
                                          Blood donation camp is also organized once in a year, sometimes sponsored by some well known organization like LIONS CLUB.</div> 
                                    </li> 
                                    <li class="style1"> 
                                      <div align="justify" class="paragraph">  Student Chapter headed by the Institution of Engineers (I) is also functioning at this Institute since 2001. Technical visits, technical seminars, career guidance, Industrial visits, nature&rsquo;s education visits etc. are carried out by this chapter. </div> 
                                    </li> 
                                    </ul>
							</td>              
   		 				<td width="2%">&nbsp;</td>
                        </tr> 
                      </table> 
                      </td> 
                  </tr> 
                </table></td> 
              </tr> 
              <tr> 
                <td>&nbsp;</td> 
              </tr> 
          </table></td> 
        </tr> 
        <tr> 
          <td colspan="2" valign="top" height="1"></td> 
        </tr><tr><td colspan="2" height="20" valign="top">              
		     <table width="100%"  border="0" cellspacing="0" cellpadding="1" background="images/bottom.gif">
  <tr> 
    <td height="26" align="center" valign="bottom">&copy; 2009 SAHJANAND VIDHYALAY,RAJKOT</td>
	</tr> 
  
  <tr>
</table> 
<div align="center"></div> 
          </td> 
        </tr> 
    </table></td> 
  </tr> 
</table> 
</body> 
</html> 