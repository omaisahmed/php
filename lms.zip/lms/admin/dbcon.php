<?php
//mysql_select_db('capstone',mysql_connect('localhost','root',''))or die(mysql_error());
$con="capstone";
mysqli_connect("localhost","root","","$con");
?>