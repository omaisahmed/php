<div class="ec_admin_slider_row" style="text-align:center;">
    <h1>30+ Gateways Available in Professional and Premium Editions!</h1>
    <a href="http://docs.wpeasycart.com/wp-easycart-administrative-console-guide/?section=payment" target="_blank" class="ec_admin_gateways_all_button">Click to View Complete List</a>
</div>