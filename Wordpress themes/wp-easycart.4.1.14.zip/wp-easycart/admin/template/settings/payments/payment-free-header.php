<div class="ec_admin_slider_row">
    <h1>Free Edition Gateways</h1>
    <div style="text-align:center;">Bill Later is aboslutely free to use. PayPal, Stripe, and Square in our free edition each include a 2% application fee as well as the standard processing fees on all transactions. You may use Square or Stripe as your live payment method along side PayPal as your third party method. Upgrade to Pro anytime to remove the application fee!</div>
    <div style="text-align:center; margin:15px 0 0; font-size:18px;"><strong>Enable Bill Later, PayPal, Stripe/Square, or All 3 Methods!</strong></div>
</div>