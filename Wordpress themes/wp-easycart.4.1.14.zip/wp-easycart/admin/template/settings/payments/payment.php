<div class="ec_admin_settings_panel">

	<?php do_action( 'wp_easycart_admin_payment_options_top' ); ?>
    
    <div class="ec_admin_important_numbered_list">

        <?php do_action( 'wpeasycart_admin_payment_settings' ); ?>

    </div>

</div>