<div class="ec_admin_settings_panel">
	<div class="ec_admin_important_numbered_list_fullwidth">
            
        <?php do_action( 'wpeasycart_admin_language_editor_settings' ); ?>
            
    </div>
	<div class="ec_admin_important_numbered_list_fullwidth">
            
        <?php do_action( 'wpeasycart_admin_language_editor' ); ?>
            
    </div>

    
</div>