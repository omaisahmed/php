<div class="ec_admin_mobile_menu_close"><a href="#" onclick="ec_admin_hide_mobile_menu( ); return false;"><div class="dashicons-before dashicons-no"></div></a></div>
<ul>

    <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Dashboard</a></li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states" onclick="ec_admin_show_mobile_sub_menu( 'products' ); return false;">Products</a>
        <ul class="ec_admin_mobile_submenu" id="ec_admin_mobile_menu_products">
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Products</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Option Sets</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Categories</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Menus</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Manufacturers</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Product Reviews</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Subscription Plans</a></li>
        </ul>
    </li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states" onclick="ec_admin_show_mobile_sub_menu( 'orders' ); return false;">Orders</a>
        <ul class="ec_admin_mobile_submenu" id="ec_admin_mobile_menu_orders">
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Orders</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Subscriptions</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Manage Downloads</a></li>
        </ul>
    </li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states" onclick="ec_admin_show_mobile_sub_menu( 'users' ); return false;">Users</a>
        <ul class="ec_admin_mobile_submenu" id="ec_admin_mobile_menu_users">
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">User Accounts</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">User Roles</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Subscribers</a></li>
        </ul>
    </li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states" onclick="ec_admin_show_mobile_sub_menu( 'marketing' ); return false;">Marketing</a>
        <ul class="ec_admin_mobile_submenu" id="ec_admin_mobile_menu_marketing">
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Gift Cards</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Coupons</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Promotions</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Abandoned Cart</a></li>
        </ul>
    </li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states" onclick="ec_admin_show_mobile_sub_menu( 'settings' ); return false;">Settings</a>
        <ul class="ec_admin_mobile_submenu" id="ec_admin_mobile_menu_settings">
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Initial Setup</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Products</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Taxes</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Shipping Settings</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Shipping Rates</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Payment</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Checkout</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Accounts</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Additional Settings</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Language Editor</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Design</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Email Setup</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Third Party</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Cart Importer</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Countries</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">States/Territories</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Per Page Options</a></li>
            <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Price Points</a></li>
        </ul>
    </li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Store Status</a></li>
    <li><a href="admin.php?page=wp-easycart-settings&subpage=states">Registration</a></li>
    
</ul>