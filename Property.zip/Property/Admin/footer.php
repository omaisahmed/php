<div class="footer">
     <div class="text"> |&copy 2018 All Rights Reserved| Brought To You By <a href="http://code-projects.org/"> Code-Projects </a> </div>

   </div>
