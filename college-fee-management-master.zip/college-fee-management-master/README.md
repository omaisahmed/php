# college-fee-management
College Fee Management is a sample fee management system.<br/>
In this project for login authentication i used OTP sms.<br/>
Every time when a student pays a fee, an sms will sent to college management and principal.
