<script type="text/javascript">
	function clean (e) {
		var textfield = document.getElementById(e);
		var regex = /fuck/gi;
		textfield.value = textfield.value.replace(regex, "Funny!");
	    }
</script>

<?php 
	//Check whether the user has uploaded a cover pic or not
	$check_pic = mysqli_query($conn,"SELECT cover_pic FROM admin WHERE username='$username'");
	$get_pic_row = mysqli_fetch_assoc($check_pic);
	$cover_pic_db = $get_pic_row['cover_pic'];
	//check for cover delete
						$pro_changed = mysqli_query($conn,"SELECT * FROM posts WHERE added_by='$username' AND (discription='updated his cover photo.' OR discription='updated her cover photo.') ORDER BY id DESC LIMIT 1");
						$get_pro_changed = mysqli_fetch_assoc($pro_changed);
		$pro_num = mysqli_num_rows($pro_changed);
		if ($pro_num == 0) {
			$cover_pic= "img/default_covpic.png";
		}else {
			$pro_changed_db = $get_pro_changed['photos'];
		if ($pro_changed_db != $cover_pic_db ) {
			$cover_pic= "img/default_covpic.png";
		}else {
			$cover_pic= "userdata/profile_pics/".$cover_pic_db ;
		}
		}

	//Check whether the user has uploaded a profile pic or not
	$check_pic = mysqli_query($conn,"SELECT profile_pic FROM admin WHERE username='$username'");
	$get_pic_row = mysqli_fetch_assoc($check_pic);
	$profile_pic_db = $get_pic_row['profile_pic'];
						//check for propic delete
						$pro_changed = mysqli_query($conn,"SELECT * FROM posts WHERE added_by='$username' AND (discription='changed his profile picture.' OR discription='changed her profile picture.') ORDER BY id DESC LIMIT 1");
						$get_pro_changed = mysqli_fetch_assoc($pro_changed);
		$pro_num = mysqli_num_rows($pro_changed);
		if ($pro_num == 0) {
			$profile_pic = "img/default_propic.png";
		}else {
			$pro_changed_db = $get_pro_changed['photos'];
		if ($pro_changed_db != $profile_pic_db) {
			$profile_pic = "img/default_propic.png";
		}else {
			$profile_pic = "userdata/profile_pics/".$profile_pic_db;
		}
		}

	//edit profile
	if (isset($_POST['updateProfile'])) {
		header("location: adminprofile_update.php");
	}

	//sent messege
	if (isset($_POST['sendmsg'])) {
		header("location: messages.php?user=$username");
	}



	//follow request system


	//unfriend system
	//name query

	$about_query = mysqli_query($conn,"SELECT admin_name,verify_id FROM admin WHERE username='$username'");
	$get_result = mysqli_fetch_assoc($about_query);
	$first_name_user = $get_result['admin_name'];
	$verify_id_user = $get_result['verify_id'];
?>
<div>
	<div class="prifile_cov"  style= "background: url(<?php echo $cover_pic; ?>) no-repeat center center; margin-top:2.8%;">
		<div style="width: 100%; height: 280px;">
			<div style="width: 960px; padding-top: 55px; margin: 0 auto;">
				<ul>
					<li>
						<div class="u_profile" style= "background: url(<?php echo $profile_pic; ?>) repeat;"></div>
					</li>
					<li style="float: left; margin: 84px 0 0 24px; text-shadow: 0px 0px 7px #000; text-align: center;">
						<ul style="line-height: 1.3;">
							<?php 
								if ($verify_id_user == 'yes') {
									echo '<span style="font-size: 25px; margin-right: 8px; float: left; font-weight: 800; color: #ffffff">'.$first_name_user.'</span><div class="verifiedicon" style="background: url(img/verifiLogo.png) repeat; background-size: cover !important;" title="Verified profile"></div>';
								}else {
									echo '<span style="font-size: 25px; margin-right: 13px; float: left; font-weight: 800; color: #ffffff">'.$first_name_user.'</span>';
								}
							 ?>
							
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="profileMainmenu">
		<div>
		<ul style="width: 900px; margin: 0 auto;">
			<li style="float: left; padding: 8px 0;">
				<form action="adminprofile_update.php" method="POST">
				<?php
					$user == $username; 
					{
					echo "<button value='button' name='updateProfile' style='background-color:#0f3572;' class='frndPokMsg'>Edit your profile</button>";
					}
					?>
				
			</form>

			</li>
