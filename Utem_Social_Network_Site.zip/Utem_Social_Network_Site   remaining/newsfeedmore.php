<?php 
 include ("connect.php");
session_start();
if (!isset($_SESSION['username'])) {
	header('location: index.php');
}
else {
	$user = $_SESSION['username'];
}
 //showmore for profile home post
 $newsfeedlastid = $_REQUEST['newsfeedlastid'];
 if (isset($newsfeedlastid)) {
 	$newsfeedlastid = $_REQUEST['newsfeedlastid'];
 }else {
 	header("location: newsfeed.php");
 }
 if ($newsfeedlastid >= 1) {
		//timeline query table
		$getposts = mysqli_query($conn,"SELECT * FROM posts WHERE newsfeedshow ='1' AND report ='0' AND note='0' AND message_give='0' AND id < $newsfeedlastid ORDER BY id DESC");
		if (mysqli_num_rows($getposts)) {
		
		//declear variable
		$getpostsNum= 0;
			while ($row = mysqli_fetch_assoc($getposts)) {
				$added_by = $row['added_by'];
				if ($added_by == $user) {
					include ( "./inc/newsfeed.inc.php");
					$getpostsNum++;
				}
				
				$newsfeedlastvalue = $row['id'];
				if ($getpostsNum == 10){
					break;
				}
		}
			echo '<li class="newsfeedmore" id="'.$newsfeedlastvalue.'">Show More</li>';
		}else {
			echo '<li class="nomorepost" style="color: #000;" >Opps! Nothing more found.</li>';
	}
 }
?>