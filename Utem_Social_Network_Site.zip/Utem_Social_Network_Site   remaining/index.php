<?php

	date_default_timezone_set("Asia/Kuala_Lumpur");
    $fb_join_date = date("Y-m-d H:i:s");
?>
<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
<script>
	function open_developer_details()
	{
		document.getElementById("my_details").style.display='block';
		document.getElementById("my_name").style.textDecoration = "underline"
	}
	function close_developer_details()
	{
		document.getElementById("my_details").style.display='none';
		document.getElementById("my_name").style.textDecoration = "none"
	}
</script>
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script> 
	<link href="css/signin.css" rel="stylesheet">
	<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
	<link href="fb_files/fb_index_file/fb_css_file/index_css.css" rel="stylesheet" type="text/css">
    <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
</head>

<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  
	  <!--Login-->
	 <form  action="login.php" method="post">
	 <div style="position:absolute; left:57.7%; top:14%; font-size:14px; color:#FFFFFF; font-weight:bold;">Admin / Lecturer / Matric.No</div>
	 <div style="position:absolute; left:57.7%; top:35%; width:15%;"><input type="text" class="form-control" height="20" name="username"  placeholder="Enter Your ID" required autofocus autocomplete="off" /></div>
	 <div style="position:absolute; left:57.7%; top:75%; font-size:12px; color:#FFFFFF; font-weight:bold;">Don't have an account!<a href="enroll.php" style="color:#00ff00; font-size:14px; text-decoration:none;"> Sign up </a></div>
	 <div style="position:absolute; left:75%; top:14%; font-size:14px; color:#FFFFFF; font-weight:bold;">Password</div>
	 <div style="position:absolute; left:75%; top:35%; width:15%;"><input type="password" class="form-control" height="20" name="password" placeholder="Enter Password" required autofocus autocomplete="off"></div>
	 <div style="position:absolute; left:75%; top:75%; font-size:12px; color:#FFFFFF; font-weight:bold;"><a href="forgot_password.php" style="color:#FFFFFF; text-decoration:underline;"> Forgotten account? </a> </div>   
	 <div class="form-group submitButtonFooter" style="position:absolute; left:89%; top:35%; ">
	 <div class="col-sm-offset-2 col-sm-10">
	 <button type="submit" name="Login" class="btn btn-info" style="font-size:16px; font-weight:bold;" id="add" data-loading-text="Loading...">Log In</button>
	 </div></div>
	 </form>	 
     </header>  
     <div style="height:112%; width:100%; background-color:#E7EBF2;  background-repeat: no-repeat; background-size: cover;  background-position: center">
	 </div>
	
		<!--Left part-->
		<!--Mobile Image--> 	
	<div style="position:absolute; height:87.9%; width:58%; left:0%; top:12%; background-image: url(images/Utem_img.jpg); background-repeat: no-repeat; background-size: cover;  background-position: center;"> </div>
    <div style="position:absolute; left:12%; top:22%; color:#FFA500; font-size:28px; font-weight:bold; font-style: italic; font-family:New Century Schoolbook;">"ALWAYS A PIONEER ALWAYS AHEAD"</div>
    
	<div style="position:absolute; left:60%; top:20%; color:#3B5998; font-size:20px; font-weight:bold; font-family:Georgia;">WELCOME TO</div>
	<div style="position:absolute; left:60%; top:25%; height:2; width:150; background-color:#a6a6a6;"></div>
	<div style="position:absolute; left:60%; top:27%; color:#3B5998; font-size:20px; font-weight:bold; font-family:Georgia;">Universiti Teknikal Malaysia Melaka</div>
	
	<div style="position:absolute; left:60%; top:35%; color:#000000; font-family:Arial; font-size:14px; text-align:justify;">
	Established on 1st December 2000 as the 1st Technical Public University in Malaysia. Located </br>
	in the UNESCO world heritage city of Melaka, Set within 766 acres of lush verdant </br>
	landscape boasting state-of-the art facilities in all its seven faculties.<br></br>
	As a Focus University, UTeM boasts strengths in technical fields – namely Engineering, IT,</br> 
	and Management Technology. UTeM has cemented a reputation of being a source of high-</br>
	quality engineering graduates with the capability of meeting the requirements of high-tech</br>
	industries. UTeM also has research competencies in areas that it has identified as being </br>
	key to enhancing the University’s unique proposition and also contributes to the nation </br>
	such as Green Technology, Systems Engineering, Human-Technology Interaction, </br>
	and Emerging Technology.
	<br></br>
	UTeM admits not only local but also international students and this includes students from</br> 
	Indonesia, Saudi Arabia, Chad, Syria, Pakistan, Cameroon, Bangladesh, Tanzania, India, </br>
	Somalia, Singapore, Qatar, Palestine, Libya, Iraq, Iran, Ghana, France, Yemen, Nigeria </br>
	and Jordan.</div>
		
	<div style="position:absolute; left:60%; top:82%; color:#000000; font-weight:bold; font-style: italic; font-family:New Century Schoolbook; font-size:20px;">"Utem social network helps you connectand share with the people in your life."</div>
	
	<!-- Registration -->
</body>
</html>