<?php include ("connect.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
	header('location: index.php');
}
else {
	$user = $_SESSION['username'];
}
//update online time
$sql = mysqli_query($conn,"UPDATE user_profile SET chatOnlineTime=now() WHERE username='$user'");

?>
<?php 
	$username ="";
	$firstname ="";
	if (isset($_GET['user'])) {
		$username = mysqli_real_escape_string($conn,$_GET['user']);
		if (ctype_alnum($username)) {
			//check user exists
			$check = mysqli_query($conn,"SELECT username FROM user_profile WHERE username='$username'");
			if (mysqli_num_rows($check)===1) {
				$get = mysqli_fetch_assoc($check);
				$username = $get['username'];
			}
			else {
				die();
			}
		}
	}

	$get_title_info = mysqli_query($conn,"SELECT * FROM user_profile WHERE username='$username'");
	$get_title_fname = mysqli_fetch_assoc($get_title_info);
	$title_fname = $get_title_fname['name'];

	
//Check whether the user has uploaded a cover pic or not
$check_pic = mysqli_query($conn,"SELECT cover_pic FROM user_profile WHERE username='$user'");
$get_pic_row = mysqli_fetch_assoc($check_pic);
$cover_pic_db = $get_pic_row['cover_pic'];
//check for userfrom propic delete
						$pro_changed = mysqli_query($conn,"SELECT * FROM posts WHERE added_by='$user' AND (discription='updated his cover photo.' OR discription='updated her cover photo.') ORDER BY id DESC LIMIT 1");
						$get_pro_changed = mysqli_fetch_assoc($pro_changed);
		$pro_num = mysqli_num_rows($pro_changed);
		if ($pro_num == 0) {
			$cover_pic= "img/default_covpic.png";
		}else {
			$pro_changed_db = $get_pro_changed['photos'];
		if ($pro_changed_db != $cover_pic_db ) {
			$cover_pic= "img/default_propic.png";
		}else {
			$cover_pic= "userdata/profile_pics/".$cover_pic_db ;
		}
		}

//Check whether the user has uploaded a profile pic or not
$check_pic = mysqli_query($conn,"SELECT profile_pic FROM user_profile WHERE username='$user'");
$get_pic_row = mysqli_fetch_assoc($check_pic);
$profile_pic_db = $get_pic_row['profile_pic'];
//check for userfrom propic delete
						$pro_changed = mysqli_query($conn,"SELECT * FROM posts WHERE added_by='$user' AND (discription='changed his profile picture.' OR discription='changed her profile picture.') ORDER BY id DESC LIMIT 1");
						$get_pro_changed = mysqli_fetch_assoc($pro_changed);
		$pro_num = mysqli_num_rows($pro_changed);
		if ($pro_num == 0) {
			$profile_pic= "img/default_propic.png";
		}else {
			$pro_changed_db = $get_pro_changed['photos'];
		if ($pro_changed_db != $profile_pic_db ) {
			$profile_pic= "img/default_propic.png";
		}else {
			$profile_pic= "userdata/profile_pics/".$profile_pic_db ;
		}
		}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Newsfeed</title>
	<link rel="icon" href="" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="./css/header.css">
	
	<style type="text/css">
		table {
		  table-layout: fixed;
		}
	</style>
	<script type="text/javascript" src="js/main.js"></script>
	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
</head>
<body>
<?php include ( "./inc/header.inc.php");?> 
<div style="width: 1220px; margin: 52px auto;">

<table>
	<tbody>
			<tr>
				<td style="vertical-align: top; padding: 0px 10px;" >
					<div style="">
				<div class="homeLeftSideContent" >
					<div class="home_cov" style= "background: url(<?php echo $cover_pic; ?>) repeat center center;">
						<div style="float: left;">
							<img src="<?php echo $profile_pic; ?>" height="70" width="70" style="border-radius: 40px; margin: 20px 0 0 10px;border: 2px solid #fff;" />
						</div>
						<div class="home_cov_data">
							<a href="profile_update.php" class="home_cov_nm" >Edit your profile</a><br>
						</div><br>
						<div class="homenavemanu">
							<div >
								<div ><a href="index.php">Home</a></div>
								<div ><a href="newsfeed.php" style="color: #0f3572">Newsfeed</a></div>
								<div ><a href="profile.php?user=<?php echo $user; ?>">Me</a></div>
							</div>
						</div>
					</div>
				</div>
				<div class="settingsleftcontent" style="width: 301px; margin-top: 15px;">
				</div>
			</div>
    		<div>
				</td>
				<td style="vertical-align: top; padding: 0px 10px;" >
					<div style="width: 560px; margin: 0px auto;">
		<div class="postForm">
			<form action="newsfeed.php" method="POST">
				<textarea name="post" rows="4" cols="58"  class="postForm_text" placeholder="What you are thinking... " style="border: 2px solid #000000;"></textarea>
				<?php
					echo'<input type="submit" name="send" value="Post" class="postSubmit" style="background-color: #0f3572;" >'; 
				?>
			</form>
		</div>
		<div class="profilePosts">
		<?php 
		//post update
		$profilehmlastid = "";
		//$post = ($_POST['post']);
		$post = isset($_POST['post']) ? $_POST['post'] : '';
		//$post = htmlspecialchars(@$_POST['post'], ENT_QUOTES);
		$post = trim($post);
		$post = mysqli_real_escape_string($conn,$post);

		if ($post != "") {
			$date_added = date("Y-m-d");
			$added_by = $user;
			$user_posted_to = $user;
			$sqlCommand = "INSERT INTO posts(body,date_added,added_by,user_posted_to) VALUES('$post', '$date_added','$added_by', '$user_posted_to')";
			$query = mysqli_query($conn,$sqlCommand);
		}

		//for getting post

		$getposts = mysqli_query($conn,"SELECT * FROM posts WHERE newsfeedshow ='1' AND report ='0' AND note='0' AND message_give='0' ORDER BY id DESC");
		
		echo '<ul id="frndpost">';
		//declear variable
		$getpostsNum= 0;
		while ($row = mysqli_fetch_assoc($getposts)) {
				$added_by = $row['added_by'];
				if ($added_by == $user) {
					include ( "./inc/newsfeed.inc.php");
					$getpostsNum++;
					
				}else {
					$checkDeactiveUser= mysqli_query($conn,"SELECT * FROM user_profile WHERE username = '$added_by'");
					$checkDeactiveUser_row = mysqli_fetch_assoc($checkDeactiveUser);
					$activeOrNot = $checkDeactiveUser_row ['activated'];
					if ($activeOrNot != '0') {					
						$check_if_follow = mysqli_query($conn,"SELECT * FROM follow WHERE (user_from='$user' AND user_to='$added_by ') ORDER BY id DESC LIMIT 2");
						$num_follow_found = mysqli_num_rows($check_if_follow);
						if ($num_follow_found != "") {
						include ( "./inc/newsfeed.inc.php");
						$getpostsNum++;
					}
				     }
				}
				
				$newsfeedlastid = $row['id'];
				if ($getpostsNum == 10){
					break;
				}
			}
			echo '<li class="newsfeedmore" id="'.$newsfeedlastid.'" >Show More</li>';
			echo '</ul>
			</div>';
			
		echo'</br>
	</div>
</div>
				</td>
				<td style="vertical-align: top; padding: 0px 10px;" >
				<div style="">
				<div  style="padding: 10px; height: 290px;" class="homeLeftSideContent" >
				<p style="padding: 4px 0; font-weight: bold; font-size: 16px;" >People You May Know</p>';
				
			echo'</div>
			</div>
			</div>
		</div>
	</div>';
?>
				</td>
			</tr>
	</tbody>
</table>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('.newsfeedmore').live('click',function() {
			var newsfeedlastid = $(this).attr('id');
			$.ajax({
				type: 'GET',
				url: 'newsfeedmore.php',
				data: 'newsfeedlastid='+newsfeedlastid,
				beforeSend: function() {
					$('.newsfeedmore').html('Loading ...');
				},
				success: function(data) {
					$('.newsfeedmore').remove();
					$('#frndpost').append(data);
				}
			});
		});
	});
</script>
</body>
</html>
