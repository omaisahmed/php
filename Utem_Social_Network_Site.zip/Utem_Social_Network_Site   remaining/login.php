<?php

include "connect.php";

if(isset($_POST['Login']))
{
    // get values form input text and number
	
		$username=$_POST['username'];
		$password=$_POST['password'];

	if (empty($username) || empty($password)) 
		{
			echo ("<script language='javascript'>window.alert('Empty fields!');window.location.href='index.php';</script>");
            exit();
        }
		
		
		else if ($username == "krismalini23@gmail.com"){
		 $sql = "SELECT * FROM admin where admin_email=?";
         $stmt = mysqli_stmt_init($conn);
		    if(!mysqli_stmt_prepare($stmt,$sql)){
			 echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='index.php';</script>");
             exit();
            }
			
	else {
		mysqli_stmt_bind_param($stmt, "s", $username);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		if($row=mysqli_fetch_assoc($result)){
			$pwdcheck = password_verify($password, $row["password"]);
			if($pwdcheck == false) {
			echo ("<script language='javascript'>window.alert('Wrong Password!');window.location.href='index.php';</script>");
             exit();
			}
		else if($pwdcheck == true){
			session_start();
			$_SESSION['admin_id']= $row['admin_id'];
			$_SESSION['username']= $row['username'];
			
			echo ("<script language='javascript'>window.location.href='admin_home.php';</script>");
            exit();
		}
		
		else{
			echo ("<script language='javascript'>window.alert('Wrong Password!');window.location.href='index.php';</script>");
            exit();
		}
		}
		else{
			echo ("<script language='javascript'>window.alert('No User!');window.location.href='index.php';</script>");
             exit();
		}
	}		
	}
  
	else{
		 $sql = "SELECT * FROM user_profile where username=?";
         $stmt = mysqli_stmt_init($conn);
		    if(!mysqli_stmt_prepare($stmt,$sql)){
			 echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='index.php';</script>");
             exit();
            }
			
	else {
		mysqli_stmt_bind_param($stmt, "s", $username);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		if($row=mysqli_fetch_assoc($result)){
			$pwdcheck = password_verify($password, $row["password"]);
			if($pwdcheck == false) {
			echo ("<script language='javascript'>window.alert('Wrong Password!');window.location.href='index.php';</script>");
             exit();
			}
		
		else if($pwdcheck == true && $row['role']== "Lecturer"){
			session_start();
			$_SESSION['user_id']= $row['user_id'];
			$_SESSION['role']= $row['role'];
			$_SESSION['username']= $row['username'];
			
			echo ("<script language='javascript'>window.location.href='lecturer_home.php';</script>");
            exit();
		}
		
		else if($pwdcheck == true && $row['role']== "Student"){
			session_start();
			$_SESSION['user_id']= $row['user_id'];
			$_SESSION['role']= $row['role'];
			$_SESSION['username']= $row['username'];
			
			echo ("<script language='javascript'>window.location.href='newsfeed.php';</script>");
            exit();
		}
		
		else{
			echo ("<script language='javascript'>window.alert('Wrong Password!');window.location.href='index.php';</script>");
            exit();
		}
		}
		else{
			echo ("<script language='javascript'>window.alert('No User!');window.location.href='index.php';</script>");
             exit();
		}
	}		
	}
}
else{
	header("location:index.php");
	exit();
}
?>