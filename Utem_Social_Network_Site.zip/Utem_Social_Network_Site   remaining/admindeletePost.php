<?php include ("connect.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
	header('location: index.php');
}
else {
	$user = $_SESSION['username'];
}

if (isset($_REQUEST['pid'])) {
	$id = $_REQUEST['pid'];
	//delete from directory
	$get_file = mysqli_query($conn,"SELECT * FROM posts WHERE id='$id'");
	$get_file_name = mysqli_fetch_assoc($get_file);
	$db_filename = $get_file_name['photos'];
	$db_username = $get_file_name['added_by'];
	if($db_username == $user) {
		$delete_file = unlink("./userdata/profile_pics/".$db_filename);
		//delete post
		$result = mysqli_query($conn,"DELETE FROM post_likes WHERE post_id='$id'");
		$result = mysqli_query($conn,"DELETE FROM posts WHERE id='$id'");
		header("location: adminprofile.php?user=$user");
	}else {
		header('location: adminnewsfeed.php');
	}
	
}else {
	header('location: adminnewsfeed.php');
}

?>