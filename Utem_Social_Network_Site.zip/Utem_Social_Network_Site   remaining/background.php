<?php
//start session
session_start();
//database connection
include("connect.php");
$user = $_SESSION['username'];
		
		$query1=mysqli_query($conn,"select * from user_profile where username='$user'");
		$rec1=mysqli_fetch_array($query1);
		$userid=$rec1[1];
		$query2=mysqli_query($conn,"select * from user_profile_pic where user_id='$userid'");
		$rec2=mysqli_fetch_array($query2);
		
		$name=$rec1[2];
		$role=$rec1[6];
		$gender=$rec1[6];
		$img=$rec2[2];

?>

<html>
<head>
<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
   <!-- custom css -->
   <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
   <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
   <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>
	<script src="background_file/background_js/event.js"></script>
	<script src="background_file/background_js/searching.js"></script>
	<script src="background_file/background_js/searched_reco_event.js">
	</script>
	<script src="background_file/background_js/submited_searched_reco_event.js"></script>
    <link href="../fb_font/font.css" rel="stylesheet" type="text/css">
    <LINK REL="SHORTCUT ICON" HREF="../fb_title_icon/Faceback.ico" />
</head>
<body>

<!--Head background-->
<div style="position:fixed;left:0;top:0; height:12%; width:100%; z-index:1; background:#0f3572;">   </div>

<!--Head logo -->
<div id="logo" style="position:fixed; left:2%; top:2%; z-index:2;"><img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/></div>

<div style="position:fixed; left:8%; top:2%; z-index:1;"><img src="images/notification.png" width="65" height="65" title="News Feed"></div>
<div style="position:fixed; left:12%; top:2%; z-index:1;"><img src="images/request.png" alt="" width="65" height="65" title="Friend Request"></div>
<div style="position:fixed; left:16%; top:2%; z-index:1;"><a href="Group_Message.php"><img src="images/messages.png" width="65" height="65" title="Messages"></a></div>

<script>
	function bcheck()
	{
		s=document.fb_search.search1.value;
		
		if(s=="")
		{
			return false;
		}
		return true;
	}
</script>
<form name="fb_search" action="Search_Display_submit.php" method="get" onSubmit="return bcheck()">

    <div style="position:absolute; left:24%; top:4%; z-index:1; width:30%;">
	<input type="text" class="form-control" class="inputbox" style="font-size:16px;" name="search1" onKeyUp="searching();" id="search_text1" placeholder="Search for friends" />	
	</div>
	

	<div id="searching_ID"></div> 
	<div style="position:fixed; left:55%; top:4%; z-index:1; ">
    <button type="submit" class="form-control" style="width:40px; height:34.5px;"><i class="fa fa-search"></i></button>
	</div>
</form>

<div style="position:fixed; left:70%; top:3%; z-index:1;">
	<table cellspacing="0">
	<tr id="hedarname2">
	
		<td style="padding-left:7;" id="head_img"><a href="profile.php"><img src="fb_users/<?php echo $gender; ?>/<?php echo $user; ?>/Profile/<?php echo $img; ?>" style="height:50; width:50;"></a></td>	
		<td id="head_name_bg" ><a href="profile.php" id="head_name_font" style="color:#DEDEEF; font-size:18px; font-weight:900;font-family:lucida Bright; text-transform:capitalize; text-decoration:none;"> &nbsp;  <?php echo $name; ?> &nbsp;</a> </td>
		<td style="color:#DEDEEF;"> | </td>
		<td id="head_home_bg" > <a href="student_home.php" id="head_home_font" style="color:#DEDEEF; font-size:18px; font-weight:900;font-family:lucida Bright; text-decoration:none;"> &nbsp; Home &nbsp; </a> </td>
        <td style="color:#DEDEEF;">|</td>
	</tr>
	</table>
</div>

<!--fb option-->
<script src="background_file/background_js/options.js"></script>

		<div style="position:fixed; left:96%; top:3%; z-index:1;"> <img src="images/setting.png" height="45" width="45" onClick="open_option()"> </div>        
		<div style="display:none" id="option">
		<div style="position:fixed; left:96%; top:3%; z-index:1;"> <img src="images/setting.png" height="45" width="45" onClick="close_option()"></div>	
        <div class="form-control" style="position:fixed; left:84%; top:9%; z-index:3; background:#FFF; height:34%; width:14%; box-shadow:0px 2px 10px 1px rgb(0,0,0);"></div> 
		
        <div style="position:fixed; left:86%; top:12%; z-index:3;">
		<a href="profile.php"><img src="img/timeline.png" width="18" height="18" onMouseOver="head_timeline_over()" onMouseOut="head_timeline_out()"></a>
        </div>	
        <div style="position:fixed; left:88%; top:10.5%; z-index:3;">
        <a href="profile.php" style="text-decoration:none; color:#000;" id="head_timeline" onMouseOver="head_timeline_over()" onMouseOut="head_timeline_out()" ><h4>Timeline</h4></a> 
        </div>
		
        <div style="position:fixed; left:86%; top:17%; z-index:3;">
        <a href="../fb_profile/about.php"><img src="img/about.png" width="18" height="18" onMouseOver="head_about_over()" onMouseOut="head_about_out()"></a>
        </div> 
        <div style="position:fixed; left:88%; top:15.5%; z-index:3;">
        <a href="../fb_profile/about.php" style="text-decoration:none; color:#000;" id="head_about" onMouseOver="head_about_over()" onMouseOut="head_about_out()"><h4>About</h4></a> 
        </div>
        
        <div style="position:fixed; left:86%; top:22%; z-index:3;"> 
		<a href="../fb_profile/photos.php"><img src="img/photo&video.PNG" width="18" height="18" onMouseOver="head_photos_over()" onMouseOut="head_photos_out()"></a>
		</div>
		<div style="position:fixed; left:88%; top:20.5%; z-index:3;">
		<a href="../fb_profile/photos.php" style="text-decoration:none; color:#000;" id="head_photos" onMouseOver="head_photos_over()" onMouseOut="head_photos_out()"><h4>Photos</h4></a>
		</div>

		<div style="position:fixed; left:86%; top:27%; z-index:3;">
		<a href="Settings.php"><img src="img/settings2.png" height="18" width="18" onMouseOver="head_settings_over()" onMouseOut="head_settings_out()"></a> 
		</div>
		<div style="position:fixed; left:88%; top:25.5%; z-index:3;">
		<a href="Settings.php" style="text-decoration:none; color:#000;" id="head_settings" onMouseOver="head_settings_over()" onMouseOut="head_settings_out()"><h4> Account Settings</h4></a>
		</div>

		<div style="position:fixed; left:86%; top:32%; z-index:3;"> 
		<a href="feedback.php"> <img src="background_file/background_icons/icon-feedback.png" height="18" width="18" onMouseOver="head_feedback_over()" onMouseOut="head_feedback_out()"></a> 
		</div>
		<div style="position:fixed; left:88%; top:30.5%; z-index:3;">
		<a href="feedback.php" style="text-decoration:none; color:#000;" id="head_feedback" onMouseOver="head_feedback_over()" onMouseOut="head_feedback_out()"><h4> Feedback </h4></a>
		</div>

		<div style="position:fixed; left:86%; top:37%; z-index:3;"> 
		<a href="../fb_logout/logout.php"> <img src="background_file/background_icons/logout.png" height="18" width="18"  onMouseOver="head_logout_over()" onMouseOut="head_logout_out()"></a> 
		</div>
		<div style="position:fixed; left:88%; top:35.5%; z-index:3;">
		<a href="../fb_logout/logout.php" style="text-decoration:none; color:#000;" id="head_logout" onMouseOver="head_logout_over()" onMouseOut="head_logout_out()"><h4> Logout </h4></a></div>
		</div>
		
				<!--left part-->
		<div style="position:fixed; left:3%; top:15%; z-index:1;">
		<a href="profile.php" style="color:#000000; font-size:18px; font-weight:900; font-family:lucida Bright; text-transform:capitalize; text-decoration:none;" id="left_name"><?php echo $role; ?></a>
		</div>
		
		<div style="position:fixed; left:3%; top:20%; z-index:1;">
		<table border="0">
		<tr>
		<td>
		<a href="profile.php"><img src="fb_users/<?php echo $gender; ?>/<?php echo $user; ?>/Profile/<?php echo $img; ?>" style="height:90; width:90;"></a><br></br>
		<a href="profile.php" onMouseOver="left_name_over()" onMouseOut="left_name_out()" style="color:#000000; font-size:16px; font-weight:900; font-family:lucida Bright; text-transform:capitalize; text-decoration:none;" id="left_name"><?php echo $name; ?></a></td>
		</tr>
		</table>
		</div>
		
		<div style="position:fixed; left:2%; top:45%;">
		<a href="student_home.php"><img src="img/News_Feed.PNG" width="50" height="50" onMouseOver="left_news_feed_over()" onMouseOut="left_news_feed_out()"></a> 
		</div>
		<div style="position:fixed; left:6%; top:46%;"> 
		<a href="student_home.php" style="text-decoration:none; color:#000;" id="news_feed" onMouseOver="left_news_feed_over()" onMouseOut="left_news_feed_out()"><h4>News Feed</h4></a>
		</div>

		<div style="position:fixed; left:2.7%; top:53%;">
		<a href="../fb_profile/Profile.php"><img src="img/timeline.png" width="30" height="30" onMouseOver="left_timeline_over()" onMouseOut="left_timeline_out()"></a> 
		</div>
		<div style="position:fixed; left:6%; top:52%;">
		<a href="../fb_profile/Profile.php" style="text-decoration:none; color:#000;" id="timeline" onMouseOver="left_timeline_over()" onMouseOut="left_timeline_out()" ><h4>Timeline</h4></a>
		</div>

		<div style="position:fixed; left:2.5%; top:60%;">
		<a href="../fb_profile/about.php"><img src="img/about.png" width="30" height="30" onMouseOver="left_about_over()" onMouseOut="left_about_out()"></a> 
		</div>
		<div style="position:fixed; left:6%; top:59%;">
		<a href="../fb_profile/about.php" style="text-decoration:none; color:#000;" id="about" onMouseOver="left_about_over()" onMouseOut="left_about_out()"><h4>About</h4></a>
		</div>

		<div style="position:fixed; left:2%; top:65%;"> 
		<a href="../fb_profile/photos.php"> <img src="img/photo&video.PNG" width="45" height="45" onMouseOver="left_photos_over()" onMouseOut="left_photos_out()"></a> 
		</div>
		<div style="position:fixed; left:6%; top:66%;">
		<a href="../fb_profile/photos.php" style="text-decoration:none; color:#000;" id="photos" onMouseOver="left_photos_over()" onMouseOut="left_photos_out()"><h4>Photos</h4></a>
		</div>

		<div style="position:fixed; left:2.5%; top:73%;"> 
		<a href="Group_Message.php"> <img src="img/group.png" height="40" width="40" onMouseOver="left_group_message_over()" onMouseOut="left_group_message_out()"></a> 
		</div>
		<div style="position:fixed; left:6%; top:72%;"><a href="Group_Message.php" style="text-decoration:none; color:#000;" id="group_message" onMouseOver="left_group_message_over()" onMouseOut="left_group_message_out()"><h4>Group Chat</h4></a>
		</div>

		<div style="position:fixed; left:2.5%; top:80%;"> 
		<a href="Settings.php"> <img src="img/settings2.png" height="40" width="40" onMouseOver="left_settings_over()" onMouseOut="left_settings_out()"></a> 
		</div>
		<div style="position:fixed; left:6%; top:79%;"><a href="Settings.php" style="text-decoration:none; color:#000;" id="settings" onMouseOver="left_settings_over()" onMouseOut="left_settings_out()"><h4>Settings</h4></a>
		</div>


		<!--left hr-->
		<hr style="position:fixed; left:18%; top:10%; height:100%; width:2%; border-color:#CCCCCC; box-shadow:-5px 0px 5px 0px rgb(0,0,0);">
		<!--right hr-->
		<hr style="position:fixed; left:82%; top:10%; height:100%; width:2%; border-color:#CCCCCC; box-shadow:5px 0px 5px 0px rgb(0,0,0);">
	

</body>
</html>