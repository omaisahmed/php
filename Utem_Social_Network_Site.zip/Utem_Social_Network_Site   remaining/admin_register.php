<?php

include "connect.php";

	date_default_timezone_set("Asia/Kuala_Lumpur");
    $fb_join_date = date("Y-m-d H:i:s");
	
if(isset($_POST['signup']))
{
    // get values form input text and number
	
        $Name=$_POST['first_name'].' '.$_POST['last_name'];
		$Email=$_POST['email'];
		$Username=$_POST['username'];
		$Password=$_POST['password'];
		
    // mysqli query to insert data
	
	    if (empty($Name) || empty($Email) || empty($Username) || empty($Password)) 
		{
			echo ("<script language='javascript'>window.alert('You must fill in all of the fields!');window.location.href='index.php';</script>");
            exit();
        }
	
		else if (!filter_var($Email, FILTER_VALIDATE_EMAIL))
		{
            echo ("<script language='javascript'>window.alert('Invalid Email!');window.location.href='index.php';</script>");
            exit();
        }
			
        else if(!preg_match("/^[a-zA-Z]/", $Name))
		{
            echo ("<script language='javascript'>window.alert('Invalid Characters!');window.location.href='index.php';</script>");
            exit();
        }
        else if(!preg_match("/[0-9]/", $Password) && !preg_match("/[A-Z]/", $Password) && !preg_match("/[a-z]/", $Password) && !preg_match("/\d/", $Password) && !preg_match("/\W/", $Password)){
            echo ("<script language='javascript'>window.alert('Password contain Minimum 8 Character, Upper Case, Lower Case, Numeral and Speacial Character!');window.location.href='index.php';</script>");
            exit();
        }

        else{
             
			 $sql = "SELECT * FROM admin where email=?";
             $stmt = mysqli_stmt_init($conn);
		     if(!mysqli_stmt_prepare($stmt,$sql)){
				echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='index.php';</script>");
                exit();
            }
			else {
				mysqli_stmt_bind_param($stmt, "s", $email);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
                $resultCheck = mysqli_stmt_num_rows($stmt);
                if($resultCheck > 0){
                   echo ("<script language='javascript'>window.alert('There is an existing account associated with this email!');window.location.href='index.php';</script>");
                exit(); 
                }
                else{           
                     $sql = "INSERT INTO admin(name,email,username,password) VALUES (?,?,?,?); ";
                     $stmt = mysqli_stmt_init($conn);
					 if(!mysqli_stmt_prepare($stmt,$sql)){
					echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='index.php';</script>");
					exit();
                }
				else {
				$hashedPwd = password_hash($Password, PASSWORD_DEFAULT);
				
				mysqli_stmt_bind_param($stmt, "ssss", $Name, $Email, $Username, $hashedPwd);
				mysqli_stmt_execute($stmt);
			    
				echo ("<script language='javascript'>window.alert('Successfully Registered!!');window.location.href='index.php';</script>");
			    exit();
		
            }
        }
}
}
mysqli_stmt_close($stmt);
mysqli_close($conn);
}
else{
	header("location:index.php");
	exit();
}
?>

<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
<script>
	function open_developer_details()
	{
		document.getElementById("my_details").style.display='block';
		document.getElementById("my_name").style.textDecoration = "underline"
	}
	function close_developer_details()
	{
		document.getElementById("my_details").style.display='none';
		document.getElementById("my_name").style.textDecoration = "none"
	}
</script>
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script> 
	<link href="css/signin.css" rel="stylesheet">
	<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
	<link href="fb_files/fb_index_file/fb_css_file/index_css.css" rel="stylesheet" type="text/css">
    <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
</head>
<script>
	function time_get()
	{
		d = new Date();
		mon = d.getMonth()+1;
		time = d.getDate()+"-"+mon+"-"+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes();
		Reg.fb_join_time.value=time;
	}
</script>
<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  
	  <!--Login-->	 
     </header>  
     <div style="height:110%; width:100%; background-color:#E7EBF2;  background-repeat: no-repeat; background-size: cover;  background-position: center">
	 </div>
	
		<!--Left part-->
		<!--Mobile Image--> 	
	<div style="position:absolute; left:5%; top:35%;"> <img src="fb_files/fb_index_file/fb_image_file/Faceback_map.PNG" width="700" height="350"> </div>
	<div style="position:absolute; height:87.9%; width:58%; left:0%; top:12%; background-image: url(images/Utem_img.jpg); background-repeat: no-repeat; background-size: cover;  background-position: center;"> </div>
    <div style="position:absolute; left:12%; top:22%; color:#FFA500; font-size:28px; font-weight:bold; font-style: italic; font-family:New Century Schoolbook;">"ALWAYS A PIONEER ALWAYS AHEAD"</div>
    
	
	
	<!-- Registration -->
	<form action="" method="post" onSubmit="return check();" name="Reg">
		<div style="position:absolute; left:64%; top:16.5%;"><h2 style="color:#000066; font-size:32px; font-weight:bold;">Create an account</h2></div>
		<div style="position:absolute; left:64%; top:25.6%; color:#000000;">Please enter your details. It's quick and easy.</div>
		<div style="position:absolute; left:64%; top:29.5%; height:1; width:383; background-color:#CCCCCC;"></div>
        
		<div style="position:absolute; left:64%; top:34%; font-size:16px; color:#000000">First Name</div>
		<div style="position:absolute; left:71.2%; top:33%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="first_name" placeholder="Enter First Name" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:41%; font-size:16px; color:#000000">Last Name</div>
		<div style="position:absolute; left:71.2%; top:40%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="last_name" placeholder="Enter Last Name" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:48%; font-size:16px; color:#000000">Email</div>
		<div style="position:absolute; left:71.2%; top:47%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="email" placeholder="Enter Your Email" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:55%; font-size:16px; color:#000000">Username</div>
		<div style="position:absolute; left:71.2%; top:54%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="username" placeholder="Enter Your Username" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:62%; font-size:16px; color:#000000">Password</div>
		<div style="position:absolute; left:71.2%; top:61%; width:20%;">
		<input type="password" class="form-control" class="inputbox"  name="password" placeholder="Enter Your New Password" required autofocus autocomplete="off" />	
		</div>
		
		<div class="form-group submitButtonFooter" style="position:absolute; left:75%; top:70%; ">
	    <div class="col-sm-offset-2 col-sm-10">
	    <button type="submit" name="signup" class="btn btn-success" style="font-size:16px; font-weight:bold;" id="add" data-loading-text="Loading...">Sign Up</button>
	    </div></div>	
</form>	
</body>
</html>