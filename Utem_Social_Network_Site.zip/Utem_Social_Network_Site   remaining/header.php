<html>
<head>
<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
<link href="css/style2.css" rel="stylesheet" />
<script>
	function open_developer_details()
	{
		document.getElementById("my_details").style.display='block';
		document.getElementById("my_name").style.textDecoration = "underline"
	}
	function close_developer_details()
	{
		document.getElementById("my_details").style.display='none';
		document.getElementById("my_name").style.textDecoration = "none"
	}
</script>
</head>
<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
      </header>  
      <div style="height:100%; width:100%; z-index:-1; background-color:#E7EBF2;  background-repeat: no-repeat; background-size: cover;  background-position: center">
	  </div>	
</body>
</html>

    