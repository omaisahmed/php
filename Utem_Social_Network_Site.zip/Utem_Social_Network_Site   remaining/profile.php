<?php 
session_start();
include("connect.php"); 


if (!isset($_SESSION['username'])) {
	header('location: index.php');
	exit();
}
else {
	$user = $_SESSION['username'];
}

//update online time
$sql = mysqli_query($conn,"UPDATE user_profile SET chatOnlineTime=now() WHERE username='$user'");
?>
<?php
	$username ="";
	$firstname ="";
	if (isset($_GET['user'])) {
		$username = mysqli_real_escape_string($conn,$_GET['user']);
		if (ctype_alnum($username)) {
			//check user exists
			$check = mysqli_query($conn,"SELECT username, name FROM user_profile WHERE username='$username'");
			if (mysqli_num_rows($check)===1) {
				$get = mysqli_fetch_assoc($check);
				$username = $get['username'];
			}
			else {
				die();
			}
		}
	}

	$get_title_info = mysqli_query($conn,"SELECT * FROM user_profile WHERE username='$username'");
	$get_title_fname = mysqli_fetch_assoc($get_title_info);
	$title_fname = $get_title_fname['name'];
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title_fname; ?></title>
	<link rel="icon" href="" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="./css/header.css">
	<script type="text/javascript" src="js/main.js"></script>
	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

	<script type="text/javascript">
		$(function() {
		  $('body').on('keydown', '#search', function(e) {
		    console.log(this.value);
		    if (e.which === 32 &&  e.target.selectionStart === 0) {
		      return false;
		    }  
		  });
		});
	</script>
	<script type="text/javascript">
		$(function() {
		  $('body').on('keydown', '#post', function(e) {
		    console.log(this.value);
		    if (e.which === 32 &&  e.target.selectionStart === 0) {
		      return false;
		    }  
		  });
		});
	</script>

</head>
<body>
<div id="top" ></div>
<?php 
$result = mysqli_query($conn,"SELECT * FROM user_profile WHERE username='$username'");
	$num = mysqli_num_rows($result);
	if ($num == 1) {
			include ("./inc/header.inc.php");
			include ("./inc/profile.inc.php");
			echo '<li style="float: right;">
							
							
							<div >
								<nav>
								<ul>
								<li><a href="photo.php?user='.$username.'" style="color:#0f3572;">Photo</a></li>
								<li><a href="about.php?user='.$username.'" style="color:#0f3572;">About</a></li>
								<li><a href="profile.php?user='.$username.'" style="background-color: #cdcdcd; color:#0f3572; ">Post</a></li>
								</ul>
								</nav>
							</div>
							
						</li>
					</ul>
					
					</div>
				</div>
			</div>';
		echo '	
		<div id="top">
			<div style="width: 560px; margin: 0 auto;">';
			$get_msg_num = mysqli_query($conn,"SELECT * FROM pvt_messages WHERE user_from='$username' AND user_to='$user' LIMIT 2");
			$msg_count = mysqli_num_rows($get_msg_num);
			if (($msg_count >=1 ) || ($username == $user)){
				echo '
					<div class="postForm">
					<form action="profile.php?user='.$username.'" method="POST" enctype="multipart/form-data">
						<textarea type="text" id="post" name="post" onkeyup="clean("post")" onkeydown="clean("post")" rows="4" cols="58"  style="border: 2px solid #000000;" class="postForm_text" placeholder="What you are thinking..."></textarea>
						<input type="submit" name="send" value="Post" class="postSubmit" style="background-color: #0f3572;">
					</form>
					</div>
				';
			}else {
				//nothing
			}
				echo '<div class="profilePosts">';

				//post update
					$profilehmlastid = "";
					$post = htmlspecialchars(@$_POST['post'], ENT_QUOTES);
					$post = trim($post);
					$post = mysqli_real_escape_string($conn,$post);

					if ($post != "") {
						$date_added = date("Y-m-d");
						$added_by = $user;
						$user_posted_to = $username;
						if ($username == $user) {
							$newsfeedshow = '1';
						}else {
							$newsfeedshow = '0';
						}
						$sqlCommand = "INSERT INTO posts(body,date_added,added_by,user_posted_to,newsfeedshow ) VALUES('$post', '$date_added','$added_by', '$user_posted_to', '$newsfeedshow')";
						$query = mysqli_query($conn,$sqlCommand);
					}

				//for getting post

				$getposts = mysqli_query($conn,"SELECT * FROM posts WHERE user_posted_to ='$username' AND message_give='0' AND note='0' AND report='0' ORDER BY id DESC LIMIT 9");
				$count_post = mysqli_num_rows($getposts);
				echo '<ul id="profilehmpost">';
				while ($row = mysqli_fetch_assoc($getposts)) {
						include ("./inc/newsfeed.inc.php");
						$profilehmlastid = $row['id'];
						$profilehm_uname = $row['user_posted_to'];
					}
					if ($count_post >= 9) {
						echo '<li class="profilehmmore" id="'.$profilehmlastid.'" >Show More</li>';
						echo '</ul>';
						echo '
						</div>
						<a href="#top" class="backtotop">top</a>
						</br>
					</div>
				</div>
			</div>
			</div>';
					}else {
					echo '</ul>';
					echo '
					</div>
				</br>
			</div>
		</div>
	</div>
	</div>';
					}

	}

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('.profilehmmore').live('click',function() {
			var profilehmlastid = $(this).attr('id');
			$.ajax({
				type: 'GET',
				url: 'profilehmmore.php',
				data: 'profilehmlastid='+profilehmlastid,
				beforeSend: function() {
					$('.profilehmmore').html('Loading ...');
				},
				success: function(data) {
					$('.profilehmmore').remove();
					$('#profilehmpost').append(data);
				}
			});
		});
	});
</script>
</body>
</html>