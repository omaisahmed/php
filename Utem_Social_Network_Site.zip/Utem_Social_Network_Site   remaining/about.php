<?php include ("connect.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
	header('location: index.php');
}
else {
	$user = $_SESSION['username'];
}
?>
<?php 
	$username ="";
	$firstname ="";
	if (isset($_GET['user'])) {
		$username = mysqli_real_escape_string($conn,$_GET['user']);
		if (ctype_alnum($username)) {
			//check user exists
			$check = mysqli_query($conn,"SELECT username, name FROM user_profile WHERE username='$username'");
			if (mysqli_num_rows($check)===1) {
				$get = mysqli_fetch_assoc($check);
				$username = $get['username'];
				$firstname = $get['name'];
			}
			else {
				die();
			}
		}
	}

	$get_title_info = mysqli_query($conn,"SELECT * FROM user_profile WHERE username='$username'");
	$get_title_fname = mysqli_fetch_assoc($get_title_info);
	$title_fname = $get_title_fname['name'];
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title_fname; ?></title>
	<link rel="icon" href="" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="./css/header.css">
	<script type="text/javascript" src="js/main.js"></script>
</head>
<body>

	<?php 

	$result = mysqli_query($conn,"SELECT * FROM user_profile WHERE username='$username'");
	$num = mysqli_num_rows($result);
	if ($num == 1) {

	include ( "./inc/header.inc.php");
	include ( "./inc/profile.inc.php");
	echo '<li style="float: right;">
							
							
					<div >
						<nav>
						<ul>
						<li><a href="photo.php?user='.$username.'" style="color: #0f3572">Photo</a></li>
						<li><a href="about.php?user='.$username.'" style="background-color: #cdcdcd; color: #0f3572">About</a></li>
						<li><a href="profile.php?user='.$username.'" style="color: #0f3572">Post</a></li>
						</ul>
						</nav>
					</div>
					
				</li>
			</ul>
			
			</div>
		</div>
	</div>';
	$get_msg_num = mysqli_query($conn,"SELECT * FROM pvt_messages WHERE user_from='$username' AND user_to='$user' LIMIT 2");
	$msg_count = mysqli_num_rows($get_msg_num);
	if (($msg_count >=1 ) || ($username == $user)) {

	$about_query = mysqli_query($conn,"SELECT * FROM user_profile WHERE username='$username'");
					$get_result = mysqli_fetch_assoc($about_query);
					
					$programme = $get_result['role'];
					$city_name_user = $get_result['city'];
					$hometown_name_user = $get_result['hometown'];
					$user_queote = $get_result['quotes'];
					$user_bio = $get_result['bio'];
					$user_mobile = $get_result['mobile'];
					$user_pub_email = $get_result['email'];
					
	
	echo '<div class="uiaccountstyle" style="text-align: left; height: auto; width: 507px; padding: 25px; margin: 15px auto;">
		<div>
			<p style="font-size: 13px; font-weight: bold; color: #959695;">PROGRAMME';
				if ($user==$username) {
					echo '<a href="workedu_update.php" style="float: right; text-decoration: none; font-size: 12px; color: #0f3572">Edit</a>';	
				}else {
					
				}
			echo '</p>

			<hr style="background-color: #ddd;">';
			
					echo '
			<p style="font-size: 15px; margin-left: 25px; font-weight: bold; color: #000000;">'.$programme.'<br></p>
				';
			
		echo '</div>
		<div>
		</br><p style="font-size: 13px; font-weight: bold; color: #959695;">MOBILE AND EMAIL';
				if ($user==$username) {
					echo '<a href="cbinfo_update.php" style="float: right; text-decoration: none; font-size: 12px; color: #0f3572">Edit</a>';	
				}else {
					
				}
		echo '</p>
			<hr style="background-color: #ddd;">
			<p style="font-size: 15px; margin-left: 25px; font-weight: bold; color: #000000;">'.$user_mobile.'</p>
			<p style=" font-weight: bold; margin-left: 25px; ">Mobile</P><br>
			<p style="font-size: 15px; margin-left: 25px; font-weight: bold; color: #000000;">'.$user_pub_email.'</p>
			<p style="font-weight: bold; margin-left: 25px; ">Email</p>
		</div>
		<div>
		</br><p style="font-size: 13px; font-weight: bold; color: #959695;">CURRENT CITY AND HOMETOWN';
				if ($user==$username) {
					echo '<a href="location_update.php" style="float: right; text-decoration: none; font-size: 12px; color: #0f3572">Edit</a>';	
				}else {
					
				}
		echo '</p>
			<hr style="background-color: #ddd;">
			<p style="font-size: 15px; margin-left: 25px; font-weight: bold; color: #000000;">'.$city_name_user.'</p>
			<p style=" font-weight: bold; margin-left: 25px; ">Current City</P><br>
			<p style="font-size: 15px; margin-left: 25px; font-weight: bold; color: #000000;">'.$hometown_name_user.'</p>
			<p style=" font-weight: bold; margin-left: 25px; ">Hometown</p>
		</div>
		<div>
		<br><p style="font-size: 13px; font-weight: bold; color: #959695;">DETAILS ABOUT';
				if ($user==$username) {
					echo '<a href="details_update.php" style="float: right; text-decoration: none; font-size: 12px; color: #0f3572">Edit</a>';	
				}else {
					
				}
		echo '</p>
			<hr style="background-color: #ddd;">
			<p style=" color: #000000; margin-left: 25px; font-size: 14px; line-height: 18px; "> '.nl2br($user_bio).'<br></p>
		<br><p style="font-size: 13px; font-weight: bold; color: #959695;">FAVORITE QUEOTE';
				if ($user==$username) {
					echo '<a href="details_update.php" style="float: right; text-decoration: none; font-size: 12px; color: #0f3572">Edit</a>';	
				}else {
					
				}
		echo '</p>
			<hr style="background-color: #ddd;">
			<p style=" color: #000000; margin-left: 25px; font-size: 14px; line-height: 18px; ">'.nl2br($user_queote).'<br></p>
		</div>
	</div>';
	}else {
		echo "<p style='text-align: center; color: #4A4848; margin: 30px; font-weight: bold; font-size: 36px;'>Sorry! Nothing to view. </p>";
	}
}else {
	header("location: profile.php?user=$user");
} 

?>
</body>
</html>