<?php

include "connect.php";

if(isset($_POST['signup']))
{
    // get values form input text and number
	
        $Name=$_POST['first_name'].' '.$_POST['last_name'];
		$Email=$_POST['email'];
		$Role=$_POST['role'];
		$ID=$_POST['id'];
		$Programme=$_POST['programme'];
		$Gender=$_POST['gender'];
		$Birthday_Date=$_POST['day'].'-'.$_POST['month'].'-'.$_POST['year'];
		$Approval=0;
		$day=intval($_POST['day']);
		$month=intval($_POST['month']);
		$year=intval($_POST['year']);

    // mysql query to insert data
	
	    if (empty($Name) || empty($Email) || empty($Role) || empty($ID) || empty($Programme) || empty($Gender) || empty($Birthday_Date)) 
		{
			echo ("<script language='javascript'>window.alert('You must fill in all of the fields!');window.location.href='admin_student_register.php';</script>");
            exit();
        }
	
		else if (!filter_var($Email, FILTER_VALIDATE_EMAIL))
		{
            echo ("<script language='javascript'>window.alert('Invalid Email!');window.location.href='admin_student_register.php';</script>");
            exit();
        }
			
        else if(!preg_match("/^[a-zA-Z]/", $Name))
		{
            echo ("<script language='javascript'>window.alert('Invalid Characters!');window.location.href='admin_student_register.php';</script>");
            exit();
        }

        else{
             
			 $sql = "SELECT * FROM users where username=?";
             $stmt = mysqli_stmt_init($conn);
		     if(!mysqli_stmt_prepare($stmt,$sql)){
				echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='admin_student_register.php';</script>");
                exit();
            }
			else {
				mysqli_stmt_bind_param($stmt, "s", $ID);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
                $resultCheck = mysqli_stmt_num_rows($stmt);
                if($resultCheck > 0){
                   echo ("<script language='javascript'>window.alert('There is an existing account associated with this matric number!');window.location.href='admin_student_register.php';</script>");
                exit(); 
                }
                else{           
                     $sql = "INSERT INTO users(name,email,role,username,programme,gender,date_of_birth,approval) VALUES (?,?,?,?,?,?,?,?); ";
                     $stmt = mysqli_stmt_init($conn);
					 if(!mysqli_stmt_prepare($stmt,$sql)){
					echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='admin_student_register.php';</script>");
					exit();
                }
				else {
				
				mysqli_stmt_bind_param($stmt, "ssssssss", $Name, $Email, $Role, $ID, $Programme, $Gender, $Birthday_Date,$Approval);
				mysqli_stmt_execute($stmt);
					
				echo ("<script language='javascript'>window.alert('Successfully Registered!!');window.location.href='admin_student_register.php';</script>");		
            }
        }
}
}
mysqli_stmt_close($stmt);
mysqli_close($conn);
}
else{
	header("location:admin_student_register.php");
	exit();
}
?>