<?php
	session_start();
	if(isset($_SESSION['username']))
	{
		 
		include ("../../../connect.php");
		$user=$_SESSION['username'];
		$que1=mysqli_query($conn,"select * from user_profile where username='$user'");
		$rec=mysqli_fetch_array($que1);
		$userid=$rec[1];
		$gender=$rec[6];
		if($gender=="Male")
		{
			$que2=mysqli_query($conn,"select * from user_profile_pic where user_id=$userid");
			$count1=mysqli_num_rows($que2);
			if($count1==0)
			{
		
?>

<?php

	if(isset($_POST['file']) && ($_POST['file']=='Upload'))
	{
		$path = "../../../fb_users/Male/".$user."/Profile/";
		$path2 = "../../../fb_users/Male/".$user."/Post/";
		$path3 = "../../../fb_users/Male/".$user."/Cover/";
		mkdir($path, 0, true);
		mkdir($path2, 0, true);
		mkdir($path3, 0, true);
		
		$img_name=$_FILES['file']['name'];
    	$img_tmp_name=$_FILES['file']['tmp_name'];
    	$prod_img_path=$img_name;
    	move_uploaded_file($img_tmp_name,"../../../fb_users/Male/".$user."/Profile/".$prod_img_path);
		
		mysqli_query($conn,"insert into user_profile_pic(user_id,image) values('$userid','$img_name');");
		echo ("<script language='javascript'>window.alert('Successfully Uploaded! Try to login!');window.location.href='../../../index.php';</script>");
	} 
?>

<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="../../../css/style2.css" rel="stylesheet" />
	<link rel="stylesheet" href="../../../assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="../../../assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="../../../assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="../../../custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="../../../assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="../../../assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="../../../assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="../../../assests/jquery-ui/jquery-ui.min.css">
  <script src="../../../assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script type="text/javascript" src="../../../../fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
	<link href="step1_css/step1.css" rel="stylesheet" type="text/css">
    <link href="../../fb_font/font.css" rel="stylesheet" type="text/css">
    <LINK REL="SHORTCUT ICON" HREF="../../fb_title_icon/Faceback.ico" />
	<script src="step1_js/Image_check.js" language="javascript">
	</script>
</head>
<body>
<header>
      <div id="logo">
	  <img class="img" src="../../../images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  
	  <div style="position:absolute; left:40%; top:120%;"><h3 style="font-weight:bold;"> Upload Your Profile Picture</h3> </div>

	  <div style="position:absolute; left:43%; top:250%; border-width:5px; border-style:solid; border-color: grey;">
	  <img src="step1_images/Male.jpg" style=" height:180; width:180;"/> 
	  </div>

	  <div style="position:absolute; left:43%; top:470%;"> 
		<table>
			<tr>
				<td></td> <td>&nbsp;  </td> <td style="text-transform:capitalize"> <h4><?php echo $rec[2]; ?></h4></td>
			</tr>
		</table> 
	  </div>
<br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
     <form method="post" enctype="multipart/form-data"  name="uimg" onSubmit="return Img_check();">
	 <div class="col-sm-3" style="margin-left:500px;">	
	 <input type="file"  class="form-control" name="file" id="img"/>  
	 </div>
	
	 <div class="form-group submitButtonFooter" style="position:absolute; left:56%; top:573%;" id="upload">
	 <div class="col-sm-offset-2 col-sm-10">
	 <button type="submit" name="file" value="Upload" class="btn btn-primary" style="font-size:16px; font-weight:bold;" id="upload_button">Upload</button>
	 </div></div>
     </form>
	<?php
		include("step1_erorr/step1_erorr.php");
	?>
</body>
</html>
<?php
			}		
		}		
	}
?>