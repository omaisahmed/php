<?php

	date_default_timezone_set("Asia/Kuala_Lumpur");
    $fb_join_date = date("Y-m-d H:i:s");
?>
<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="../../../../css/style2.css" rel="stylesheet" />
	<link rel="stylesheet" href="../../../../assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="../../../../assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="../../../../assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="../../../../custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="../../../../assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="../../../../assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="../../../../assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="../../../../assests/jquery-ui/jquery-ui.min.css">
  <script src="../../../../assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script type="text/javascript" src="../../../../fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
	
</head>
<body>
<header>


</form>	
</body>
</html>