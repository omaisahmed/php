<?php 
//start session
session_start();
//database connection
include("connect.php");
$user = $_SESSION['user_id'];

$get_user = mysqli_query($conn,"SELECT * FROM users WHERE user_id = '$user'");
$rsU = mysqli_fetch_assoc($get_user);
$name = $rsU['name'];
$member = $name;
?>
<html>
<head>
<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
<link href="css/style2.css" rel="stylesheet" />
<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

</head>
<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-has-children"><a href="admin_home.php">Home</a></li>
          
		   <li class="menu-has-children"><a href="">Account</a>
            <ul>
              <li><a href="admin_student_register.php">Register User</a></li>
              <li><a href="admin_manage_users.php">Manage User</a></li>
            </ul>
          </li>
		  
          <li class="menu-has-children"><a href="">News Feed</a>
            <ul>
              <li><a href="add_purchase.php">Add Events</a></li>
              <li><a href="admin_manage_news.php">Manage Events</a></li>
            </ul>
          </li>
          
		  <li class="menu-has-children">
          <a href="" class="dropdown-toggle"><i class="glyphicon glyphicon-user"></i><span class="caret"></span></a>
          <ul>
			<li><a href="report.php"><i class="glyphicon glyphicon-edit"></i>&nbsp;Report&nbsp;</a></li>		  
            <li><a href="setting.php"><i class="glyphicon glyphicon-wrench"></i>&nbsp;Setting&nbsp;</a></li>            
            <li><a href="logout.php"><i class="glyphicon glyphicon-log-out"></i>&nbsp;Logout&nbsp;</a></li>            
          </ul>
        </li>
			<li class="menu-has-children"><a><?php echo ucwords(strtolower($member));?></a></li>		
        </ul>
      </nav>
      </header>  
<br></br>
	  <div class="container">
		<div class="container-fluid">
				</div>	  

				<?php
//database connection
include("connect.php");
    include "admin_header.php";
	date_default_timezone_set("Asia/Kuala_Lumpur");
    $fb_join_date = date("Y-m-d H:i:s");
?>
<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script> 
	<link href="css/signin.css" rel="stylesheet">
	<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
	<link href="fb_files/fb_index_file/fb_css_file/index_css.css" rel="stylesheet" type="text/css">
    <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
</head>
<body>
		<!--Left part-->
		<!--Mobile Image--> 	
	
	

</body>
</html>
    