<?php
//new mysqli ('localhost', user, password, dbname)
$conn=mysqli_connect("localhost", "root", "") or die("Connection Fail");
mysqli_select_db($conn,"student_social_network_site") or die("Cannot connect to database");
?>
