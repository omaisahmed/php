<?php include ( "connect.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
	header('location: index.php');
}
else {
	$user = $_SESSION['username'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Details Settings</title>
	<link rel="icon" href="" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="./css/header.css">
</head>
<body>
<?php include ( "./inc/header.inc.php"); ?>
<?php
//take the user back
if ($user) {
	if (isset($_POST['no'])) {
		header('Location: details_update.php');
	}
}
else {
	die("You must be logged in to view this page!");
}
?>

<?php 

$updateinfo = @$_POST['updateinfo'];
$update = @$_POST['update'];
//Update Bio and first name last name query
$get_info = mysqli_query($conn,"SELECT bio,quotes FROM user_profile WHERE username='$user'");
$get_row = mysqli_fetch_assoc($get_info);
$db_bio = $get_row['bio'];
$db_queote = $get_row['quotes'];

//submit what the user type in database
if ($updateinfo) {
	$bio = $_POST['bio'];
	$bio = trim($bio);
	$bio = mysqli_real_escape_string($conn,$bio);
		//submit the form to database
		$info_submit_query = mysqli_query($conn,"UPDATE user_profile SET bio='$bio' WHERE username='$user'");
		echo "<p class='error_echo'>Your Profile Bio Has Been Updated.</p>";
		header("Location: about.php?user=$user");
	}
if ($update) {
	$queote = $_POST['queote'];
	$queote = trim($queote);
	$queote = mysqli_real_escape_string($conn,$queote);
		//submit the form to database
		$info_submit_query = mysqli_query($conn,"UPDATE user_profile SET quotes='$queote' WHERE username='$user'");
		echo "<p class='error_echo'>Your Profile Quotes Has Been Updated.</p>";
		header("Location: about.php?user=$user");
	}
?>
<div style="margin-top: 48px;">
<div style="width: 900px; margin: 0 auto;">
	<ul>
		<li style="float: left;">
			<div class="settingsleftcontent">
				<ul>
					<li><a href="profile_update.php" style="color: #000;">Profile Update</a></li>
					<li><a href="password_update.php"style="color: #000;" >Password</a></li>
					<li><a href="workedu_update.php" style="color: #000;">Work and Education</a></li>
					<li><a href="cbinfo_update.php" style="color: #000;">Contact and Basic Info</a></li>
					<li><a href="location_update.php" style="color: #000;">Location and Places</a></li>
					<li><a href="details_update.php" style="background-color: #0f3572; border-radius: 3px; color: #fff;">Details About</a></li>
				</ul>
			</div>
			<div class="settingsleftcontent">
				
			</div>
		</li>
		<li style="float: right;">
			<div class="uiaccountstyle">
				<form action="#" method="post">
					<h2><p>Update Your Profile Info: </p></h2></br></br>
					<p style="font-size:14px; color: #000; margin-right:75%;">ABOUT YOU:</p>
					<textarea name="bio" id="aboutyou" class="placeholder" style="margin: 10px; padding: 5px; width: 500px; height: 140px; resize: none;font-size:14px; color: #000;"> <?php echo $db_bio; ?> </textarea> </br>
					<input type="submit" name="updateinfo" id="updateinfo" style="background-color: #0f3572; border-radius: 5px; color: #fff;" class="confirmSubmit" value="Update Information">&nbsp;&nbsp;
					<input type="submit" name="no" value="Cancel" style="background-color: #ff0000; border-radius: 5px; color: #fff;" title="Back to Settings" class="cancelSubmit"> </br></br></br>
					<p style="font-size:14px; color: #000; margin-right:67%;">FAVORITE QUOTES:</p>
					<textarea name="queote" id="queote" class="placeholder" style="margin: 10px; padding: 5px; width: 500px; height: 140px; resize: none; font-size:14px; color: #000;"> <?php echo $db_queote; ?> </textarea> </br>
					<input type="submit" name="update" id="update" style="background-color: #0f3572; border-radius: 5px; color: #fff;"  class="confirmSubmit" value="Update Information">&nbsp;&nbsp;
					<input type="submit" name="no" value="Cancel" style="background-color: #ff0000; border-radius: 5px; color: #fff;" title="Back to Settings" class="cancelSubmit"> </br>
				</form>
			</div>
		</li>
	</ul>
</div>
</div>
</body>
</html>