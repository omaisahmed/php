<?php
//database connection
	include("connect.php");
    include "admin_header.php";
	
	$result=mysqli_query($conn,"SELECT * FROM users");
	$rowSelect = (mysqli_num_rows($result));
	date_default_timezone_set("Asia/Kuala_Lumpur");
    $fb_join_date = date("Y-m-d H:i:s");
?>
<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->

	<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
<script src="assests/bootstrap/js/bootstrap.min.js"></script> 
<link rel="stylesheet" href="css/style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style/jquery-ui.css">
<script type="text/javascript" src="scripts/table.js"></script>
<script type="text/javascript" src="scripts/gs_sortable.js"></script>
<script type="text/javascript">
<!--
var TSort_Data = new Array ('TABLE_2', 'i', 's', 's', 'i', 'i', 's', 'i');
tsRegister();
// -->
</script>
<link rel="stylesheet" type="text/css" href="style/table.css" media="all">
   <style>
     /* Remove the navbar's default margin-bottom and rounded borders */
     .navbar {
       margin-bottom: 0;
       border-radius: 0;
     }

     /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
     .row.content {height: 750px}

     /* Set gray background color and 100% height */
     .sidenav {
       padding-top: 20px;
       background-color: #e3f2fd;
       height: 100%;
     }

     /* Set black background color, white text and some padding */
     footer {
       background-color: #555;
       color: white;
       padding: 15px;
     }

     /* On small screens, set height to 'auto' for sidenav and grid */
     @media screen and (max-width: 991.98px) {
       .sidenav {
         height: auto;
         padding: 15px;
       }
       .row {height:auto;}
     }

     #myBtn {
     display: none; /* Hidden by default */
     position: fixed; /* Fixed/sticky position */
     bottom: 20px; /* Place the button at the bottom of the page */
     right: 30px; /* Place the button 30px from the right */
     cursor: pointer; /* Add a mouse pointer on hover */
	 background-color: #ff1919;
     }

     #myBtn:hover {
     background-color: grey; /* Add a dark-grey background on hover */
     }
   </style>
 </head>
 <body style="margin-top:80px;">
 <div class="container">
<div class="container-fluid"></div>

             <h1 id="title1" style="margin:2%;font-size:30px;font-weight:600;">Manage Profile</h1>
			 <div class="panel panel-default">
	<div class="panel-heading">
	<i class="glyphicon glyphicon-edit"></i> Manage Profile
	</div>
	
       <form method="post" >
	   <div class="panel-body">
		<br>
       <div class="row border border-info d-flex p-2 bd-highlight">
	   <div  class="form-group" style="margin:2%">
         <label for="category" class="col-lg-1 col-form-label" align="right" style="padding-top:0.5%">Search</label>
         <div class="col-lg-4">
           <input type="text" class="form-control" name="searchName" placeholder="Search By Name / Matric No">
         </div></div>

          <div class="col-lg-2">
            <button type="submit" class="btn btn-primary btn" name="search"><i class="fa fa-search"></i></button>
            <button type="reset" class="btn btn-primary btn" onclick="refresh()"><i class="fa fa-refresh"></i></button>
          </div>
      </div></form>
     
      <br></br>
	   <!-- /div-action -->
      <?php

        if(isset($_POST["search"]))
        {
          $searchName = $_POST["searchName"];
          $searchQry = "";

          if(!$searchName==NULL)
          {
              $searchQry = $searchQry . "name LIKE '%$searchName%' OR matric_no LIKE '%$searchName%'";
          }

          $searchQry = "SELECT * FROM users
                        WHERE $searchQry
                        ORDER BY fb_join_date DESC";
          $resultSearch = mysqli_query($conn,$searchQry);
          $rowSearch = (mysqli_num_rows($resultSearch));

          if($rowSearch == 0)
          {
			  echo"
			  <table align='center' class='table table-bordered' class='example table-autosort:0 table-stripeclass:alternate' id='TABLE_2'>
                   				<thead>
									<tr style='background-color: #0f3572;'>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>NO.</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Matric No</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Name</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Email</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Role</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Gender</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>BirthDay Date</th>
									</tr>
            
                  </thead>
                <tr>  
                     <td colspan='12'>No Record Found!</td>  
                </tr> 
				</table>";
          }
          else
          {
            echo"
			<table align='center' class='table table-bordered' class='example table-autosort:0 table-stripeclass:alternate' id='TABLE_2'>
                   				<thead>
									<tr style='background-color: #0f3572;'>
									    <th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>NO.</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Matric No</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Name</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Email</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Role</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Gender</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>BirthDay Date</th>
									</tr>
            
                  </thead>
                  <tbody>
            ";
            $no =1 ;

            while($rws=mysqli_fetch_array($resultSearch))
            {
                $matric_no = $rws["matric_no"];
				$name = $rws["name"];
				$email = $rws["email"];
                $role = $rws["role"];
                $gender = $rws["gender"];
				$date_of_birth = $rws["date_of_birth"];

				
              echo"
                    <tr align='left'>
                    <td>$no</td>
					<td>$matric_no</td>
                    <td>$name</td>
                    <td>$email</td>
					<td>$role</td>
					<td>$gender</td>					
					<td>$date_of_birth</td>
                    </tr>
               ";
               $no++;
            }

            echo"
                  </tbody>
                  </table>
                  </div>

             ";
          }
        }
        else
         {
            if($rowSelect == 0)
            {
              echo"<script>window.alert('Do not have any supplier data.Register one now.');</script>";
            }
            else
            {
              echo"
             <table align='center' class='table table-bordered' class='example table-autosort:0 table-stripeclass:alternate' id='TABLE_2'>
                   				<thead>
									<tr style='background-color: #0f3572;'>
									    <th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>NO.</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Matric No</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Name</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Email</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Role</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>Gender</th>
										<th class='table-sortable:numeric table-sortable table-sorted-asc' style='color: #fff;' title='Click to sort'>BirthDay Date</th>
									</tr>
										
             </thead>
                    <tbody>
              ";
              $no =1 ;

              while($rws=mysqli_fetch_array($result))
              {
                $matric_no = $rws["matric_no"];
				$name = $rws["name"];
				$email = $rws["email"];
                $role = $rws["role"];
                $gender = $rws["gender"];
				$date_of_birth = $rws["date_of_birth"];

				
              echo"
                    <tr align='left'>
                    <td>$no</td>
					<td>$matric_no</td>
                    <td>$name</td>
                    <td>$email</td>
					<td>$role</td>
					<td>$gender</td>					
					<td>$date_of_birth</td>
                    </tr>
                 ";
                 $no++;
              }

              echo"
                    </tbody>
                    </table>
                    </div>

               ";

          }

        }
       ?>


     </div>
   </div>
 </div>
 <script>
     function refresh()
     {
       document.location='admin_manage_users.php';
     }

     // When the user scrolls down 20px from the top of the document, show the button
     window.onscroll = function() {scrollFunction()};

     function scrollFunction() {
         if (document.body.scrollTop >20|| document.documentElement.scrollTop >20){
             document.getElementById("myBtn").style.display = "block";
         } else {
             document.getElementById("myBtn").style.display = "none";
         }
     }

     // When the user clicks on the button, scroll to the top of the document
     function topFunction() {
         document.body.scrollTop = 0; // For Safari
         document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
     }

     function deletePat()
     {
         var ic = prompt("Please Reenter Staff ICNO:");

         if(isNaN(ic))
         {
             alert("The ICNO was invalid");
         }
         else
       {
         if (ic == null||ic == "")
         {
           alert("The Staff ICNO was left empty.Please fill in the blank");
         }
         else
         {
           window.location = 'delete_user.php?action=delete_user&ic_no=' + ic;
         }

       }

     }
 </script>
 <script src="js/jquery-3.0.0.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
     <script>
     $(document).ready(function(){
         $('[data-toggle="tooltip"]').tooltip();
     });
     </script>
	  </form>
</body>
</html>