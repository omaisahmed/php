<?php 
//start session
session_start();
//database connection
include("connect.php");
$admin = $_SESSION['admin_id'];

$get_user = mysqli_query($conn,"SELECT * FROM admin WHERE admin_id = '$admin'");
$rsU = mysqli_fetch_assoc($get_user);
$name = $rsU['admin_name'];
$member = $name;

date_default_timezone_set("Asia/Kuala_Lumpur");
$current_date = date("Y-m-d H:i:s");
?>

<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
<script>
	function open_developer_details()
	{
		document.getElementById("my_details").style.display='block';
		document.getElementById("my_name").style.textDecoration = "underline"
	}
	function close_developer_details()
	{
		document.getElementById("my_details").style.display='none';
		document.getElementById("my_name").style.textDecoration = "none"
	}
</script>
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
	<!-- custom css -->
	<link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
	<link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">
	<!-- file input -->
	<link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">
  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script> 
	<link href="css/signin.css" rel="stylesheet">
	<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
	<link href="fb_files/fb_index_file/fb_css_file/index_css.css" rel="stylesheet" type="text/css">
    <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
</head>

<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  
	  <div style="position:absolute; left:60%; top:40%;"><a href="admin_home.php" style="color:#ffffff; font-size:18px; font-weight:bold; text-transform:uppercase;">HOME</a></div>
	  <div style="position:absolute; left:75%; top:30%;"><h2 style="color:#ffffff; font-size:16px; font-weight:bold; text-transform:uppercase;">ADMINISTRATOR: &nbsp&nbsp<?php echo ucwords(strtolower($member));?></h2></div>    
	  <div style="position:absolute; left:87%; margin-top:-2.5%;"><h2 style="color:#ffffff; font-size:16px; font-weight:bold;"><?php echo $current_date;?></h2></div>	 
	  </header>  
      <div style="height:123%; width:100%; background-color:#E7EBF2;  background-repeat: no-repeat; background-size: cover;  background-position: center">
	  </div>
	
		<!--Left part-->
		<!--Mobile Image--> 	
	<div style="position:absolute; height:92.5%; width:58%; left:0%; top:12%; background-image: url(images/Utem_img.jpg); background-repeat: no-repeat; background-size: cover;  background-position: center;"> </div>
    <div style="position:absolute; left:12%; top:22%; color:#FFA500; font-size:28px; font-weight:bold; font-style: italic; font-family:New Century Schoolbook;">"ALWAYS A PIONEER ALWAYS AHEAD"</div>	
	
	<!-- Registration -->
	<form action="sign_up.php" method="post" onSubmit="return check();" name="Reg">
		<div style="position:absolute; left:64%; top:16.5%;"><h2 style="color:#000066; font-size:32px; font-weight:bold;">Create an account</h2></div>
		<div style="position:absolute; left:64%; top:25.6%; color:#000000;">Please enter your details. It's quick and easy.</div>
		<div style="position:absolute; left:64%; top:29.5%; height:1; width:383; background-color:#CCCCCC;"></div>
        
		<div style="position:absolute; left:64%; top:34%; font-size:16px; color:#000000">First Name</div>
		<div style="position:absolute; left:71.2%; top:33%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="first_name" placeholder="Enter First Name" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:41%; font-size:16px; color:#000000">Last Name</div>
		<div style="position:absolute; left:71.2%; top:40%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="last_name" placeholder="Enter Last Name" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:48%; font-size:16px; color:#000000">Email</div>
		<div style="position:absolute; left:71.2%; top:47%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="email" placeholder="Enter Your Email" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:55%; font-size:16px; color:#000000">Role</div>
		<div style="position:absolute; left:71.2%; top:54%; width:20%;">
		<select class="form-control" class="inputbox"  name="role" required autofocus autocomplete="off">	
		<option value="Select Role">Select Role</option>
		<option value="Lecturer">Lecturer</option>
		<option value="Student">Student</option>
		</select>
		</div>
		
		<div style="position:absolute; left:64%; top:61%; font-size:16px; color:#000000">Matric.No /</br>Lecturer ID</div>
		<div style="position:absolute; left:71.2%; top:61%; width:20%;">
		<input type="text" class="form-control" class="inputbox"  name="id" placeholder="Enter Your Matric Number / Lecturer ID" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:64%; top:69%; font-size:16px; color:#000000">Programme</div>
		<div style="position:absolute; left:71.2%; top:68%; width:20%;">
		<select class="form-control" class="inputbox"  name="programme" required autofocus autocomplete="off">
		<option value="">Select Programme</option>
		<?php
		$res=mysqli_query($conn,"select * from programmes ORDER BY programme_name ASC");
		while($row=mysqli_fetch_array($res))
		{
		?>
		<option value="<?php echo $row["programme_id"];?>"><?php echo $row["programme_name"];?></option>
		<?php
		}
		?>
		</select>
		</div>

		<div style="position:absolute; left:64%; top:76%; font-size:16px; color:#000000">Gender</div>
		<div style="position:absolute; left:71.2%; top:75%; width:20%;">
		<select class="form-control" class="inputbox"  name="gender" required autofocus autocomplete="off">	
		<option value="Select Sex">Select Gender</option>
		<option value="Female"> Female </option>
		<option value="Male"> Male </option>
		</select>
		</div>
		
		<div style="position:absolute; left:64%; top:83%; font-size:16px; color:#000000">Birthday</div>
		<div style="position:absolute; left:71.2%; top:82%;">
		<select class="form-control" class="inputbox"  name="month" required autofocus autocomplete="off">	
		<option value="Month">Month</option>
			<script type="text/javascript">
	
			var m=new Array("","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
			for(i=1;i<=m.length-1;i++)
			{
				document.write("<option value='"+i+"'>" + m[i] + "</option>");
			}	
			</script>
		</select>
		</div>
		
		<div style="position:absolute; left:77.5%; top:82%;">
		<select class="form-control" class="inputbox"  name="day" required autofocus autocomplete="off">
	    <option value="Day">Day</option>
			<script type="text/javascript">
	
			for(i=1;i<=31;i++)
			{
				document.write("<option value='"+i+"'>" + i + "</option>");
			}	
			</script>
		</select>
		</div>	

		<div style='position:absolute; left:83%; top:82%;'>
		<select class="form-control" class="inputbox"  name="year" required autofocus autocomplete="off">
		<option value="Year">Year</option>
			<script type="text/javascript">
	
			for(i=2019;i>=1960;i--)
			{
				document.write("<option value='"+i+"'>" + i + "</option>");
			}
			</script>
		</select>
		</div>
		
		<div class="form-group submitButtonFooter" style="position:absolute; left:69%; top:90%; ">
	    <div class="col-sm-offset-2 col-sm-10">
	    <button type="submit" name="signup" class="btn btn-success" style="font-size:16px; font-weight:bold;" id="add" data-loading-text="Loading...">Sign Up</button>
	    </div></div>	
</form>	
</body>
</html>