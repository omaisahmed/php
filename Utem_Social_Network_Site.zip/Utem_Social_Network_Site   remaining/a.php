
<?php
include("connect.php");

if(isset($_POST["submit"])){
	
$filename = $_FILES['img']['name'];
$tmpname = $_FILES['img']['tmp_name'];
$filetype = $_FILES['img']['type'];
for($i=0; $i<=count($tmpname)-1; $i++){
$name = addslashes($filename[$i]);
$tmp = addslashes(file_get_contents($tmpname[$i]));
mysqli_query($conn,"Insert into multiple(name,image) values('$name','$tmp')");
}
}

$res = mysqli_query($conn,"SELECT * FROM multiple");
while($row = mysqli_fetch_array($res)){
$displ = $row['image'];
echo '<img src="data:image/jpeg;base64,'.base64_encode($displ).'" width="250" height="250">';
}
?>

<form action="#" enctype="multipart/form-data" method="post">
<input multiple="multiple" name="img[]" type="file" />
<input name="submit" type="submit" />
</form>