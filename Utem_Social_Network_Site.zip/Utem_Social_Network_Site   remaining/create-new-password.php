   <?php
    include "header.php";
	date_default_timezone_set("Asia/Kuala_Lumpur");
    $fb_join_date = date("Y-m-d H:i:s");
?>
<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
<script>
	function open_developer_details()
	{
		document.getElementById("my_details").style.display='block';
		document.getElementById("my_name").style.textDecoration = "underline"
	}
	function close_developer_details()
	{
		document.getElementById("my_details").style.display='none';
		document.getElementById("my_name").style.textDecoration = "none"
	}
</script>
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script> 
	<link href="css/signin.css" rel="stylesheet">
	<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
	<link href="fb_files/fb_index_file/fb_css_file/index_css.css" rel="stylesheet" type="text/css">
    <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
</head>
<body>

    <div style="position:absolute; left:5%; top:35%;"> <img src="fb_files/fb_index_file/fb_image_file/Faceback_map.PNG" width="700" height="350"> </div>
    <div style="position:absolute; left:7%; top:24%; color:#3B5998; font-size:28px;"> <font face="myFbFont"> Utem social network helps you connect</font> </div>
    <div style="position:absolute; left:7%; top:30%; color:#3B5998; font-size:28px;"> <font face="myFbFont"> and share with the people in your life.</font></div>
	
<?php

$selector = $_GET["selector"];
$validator = $_GET["validator"];

if(empty($selector) || empty($validator)){
	echo "Could not validate your request!";
}
else
{
	if(ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false){
		?>
		
	<!-- Registration -->
	<form action="reset/reset_password.php" method="post" onSubmit="return check();" name="Reg">
		<div style="position:absolute; left:58%; top:16.5%;"><h2 style="color:#000066; font-size:32px; font-weight:bold;">Reset your password</h2></div>
		<div style="position:absolute; left:58%; top:25.6%; color:#000000;">An email will be send to you with instructions on how to reset your password.</div>
		<div style="position:absolute; left:57.7%; top:29.5%; height:1; width:480; background-color:#CCCCCC;"></div>
        
        <input type="hidden" name="selector" value="<?php echo $selector;?>" />	
		<input type="hidden" name="validator" value="<?php echo $validator;?>" />
		
		<div style="position:absolute; left:58%; top:33%; width:30%;">
		<input type="password" class="form-control" class="inputbox" style="font-size:18px; font-weight:bold;" name="password" placeholder="Enter A New Password" required autofocus autocomplete="off" />	
		</div>
		
		<div style="position:absolute; left:58%; top:40%; width:30%;">
		<input type="password" class="form-control" class="inputbox" style="font-size:18px; font-weight:bold;" name="password1" placeholder="Repeat New Password" required autofocus autocomplete="off" />	
		</div>

		<div class="form-group submitButtonFooter" style="position:absolute; left:56%; top:47%; ">
	    <div class="col-sm-offset-2 col-sm-10">
	    <button type="submit" name="reset-password" class="btn btn-success" style="font-size:18px; font-weight:bold;" id="add" data-loading-text="Loading...">RESET PASSWORD</button>
	    </div></div>	
</form>	
		
		<?php
	}
}
?>
</body>
</html>