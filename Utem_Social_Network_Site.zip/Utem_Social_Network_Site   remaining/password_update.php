<?php include ("connect.php"); ?>
<?php  
ob_start();
session_start();
if (!isset($_SESSION['username'])) {
	header('location: index.php');
}
else {
	$user = $_SESSION['username'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Password Settings</title>
	<link rel="icon" href="" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="./css/header.css">
</head>
<body>

<?php include ( "./inc/header.inc.php"); ?>

<?php 

//take the user back
if ($user) {
	if (isset($_POST['no'])) {
		header("Location: password_update.php");
	}
}

//password update
$senddata = @$_POST['senddata'];
//password variable
$oldpassword = strip_tags(@$_POST['oldpassword']);
$newpassword = strip_tags(@$_POST['newpassword']);
$repear_password = strip_tags(@$_POST['newpassword2']);
$oldpassword = trim($oldpassword);
$newpassword = trim($newpassword);
$repear_password = trim($repear_password);

//update pass
if ($senddata) {
	//if the information submited
	$password_query = mysqli_query($conn,"SELECT password FROM user_profile WHERE username='$user'");
	while ($row = mysqli_fetch_assoc($password_query)) {
		$db_password = $row['password'];
		//try to change MD5 pass
		$oldpassword_md5 = $oldpassword;
		if ($oldpassword_md5 == $db_password) {
			if ($newpassword == $repear_password) {
				//Awesome.. Password match.
				$newpassword_md5 =$newpassword;
				if ($newpassword_md5 <= 3) {
					$error = "<p class='error_echo'>Sorry! But your new password must be 8 character!</p>";
				}else {
				$password_update_query = mysqli_query($conn,"UPDATE user_profile SET password='$newpassword_md5' WHERE username='$user'");
				$error = "<p class='succes_echo'>Success! Your password updated.</p>";
				// send email
				
				}
			}else {
				$error = "<p class='error_echo'>Two new password don't match!</p>";
			}

		}else {
			$error = "<p class='error_echo'>The old password is incorrect!</p>";
		}
	}
}else {
	$error = "";
}

?>
<div style="margin-top: 48px;">
<?php echo $error; ?>
<div style="width: 900px; margin: 0 auto;">
	<ul>
		<li style="float: left;">
			<div class="settingsleftcontent">
				<ul>
					<li><a href="profile_update.php" style="color: #000;">Profile Update</a></li>
					<li><a href="password_update.php" style="background-color: #0f3572; border-radius: 3px; color: #fff;">Password</a></li>
					<li><a href="workedu_update.php" style="color: #000;">Work and Education</a></li>
					<li><a href="cbinfo_update.php" style="color: #000;">Contact and Basic Info</a></li>
					<li><a href="location_update.php" style="color: #000;">Location and Places</a></li>
					<li><a href="details_update.php" style="color: #000;">Details About</a></li>
				</ul>
			</div>
			<div class="settingsleftcontent" style="background-color: #fff;">
			</div>
		</li>
		<li style="float: right;">
		<form action="password_update.php" method="post">
			<div class="uiaccountstyle">
				<h2><p>Change Your Password: </p></h2><br></br>
				<p style="font-size:14px; color: #000; margin-right:23%;">Your Old Password:</p>
				<input type="password" name="oldpassword" style="font-size:14px; color: #000;" class="placeholder" size="30"></br></br>
				<p style="font-size:14px; color: #000; margin-right:22%;">Your New Password:</p>
				<input type="password" name="newpassword" style="font-size:14px; color: #000;" class="placeholder" size="30"></br></br>
				<p style="font-size:14px; color: #000; margin-right:18%;">Retype New Password:</p>
				<input type="password" name="newpassword2" style="font-size:14px; color: #000;" class="placeholder" size="30"></br>
				</hr><br></br>
				<input type="submit" name="senddata" id="senddata" style="background-color: #0f3572; border-radius: 5px; color: #fff;" class="confirmSubmit" value="Update Password">&nbsp;&nbsp;
				<input type="submit" name="no" value="Cancel" title="Back to Settings" style="background-color: #ff0000; border-radius: 5px; color: #fff;" class="cancelSubmit"> </br>
				</div>
			</form>
		</li>
	</ul>
</div>
</div>
</body>
</html>