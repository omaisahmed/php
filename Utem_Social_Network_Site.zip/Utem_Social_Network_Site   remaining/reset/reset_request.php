<?php

if(isset($_POST['reset-request']))
{
    // get values form input text and number
	
	$selector = bin2hex(random_bytes(8));
	$token = random_bytes(32);
	
	$url = "http://localhost/Utem_Social_Network_Site/create-new-password.php?selector=" . $selector . "$validator=" . bin2hex($token);
	
	$expires = date("U") + 1800;
	
	require "connect.php";
	
	$email = $_POST["email"];
	
	$sql = "DELETE FROM password_reset WHERE reset_email=?;";
	$stmt = mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql)){
		echo ("<script language='javascript'>window.alert('There was an error!');</script>");
        exit();
	}
	else{
		mysqli_stmt_bind_param($stmt, "s", $email);
		mysqli_stmt_execute($stmt);
	}
	
	$sql = "INSERT INTO password_reset(reset_email,reset_selector,reset_token,reset_expires) VALUES(?,?,?,?);";
	$stmt = mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql)){
		echo ("<script language='javascript'>window.alert('There was an error!');</script>");
        exit();
	}
	else{
		$hashedToken = password_hash($token, PASSWORD_DEFAULT);
		mysqli_stmt_bind_param($stmt, "ssss", $email, $selector, $hashedToken, $expires);
		mysqli_stmt_execute($stmt);
	}
	
mysqli_stmt_close($stmt);
mysqli_close($conn);

$to = $email;

$subject = 'Reset your password';

$message = '<p>We recieved a password reset request. The link to reset your password is below, if did not
make this request, you can ignore this email</p>';
$message .= '<p>Here is your password reset link: </br>';
$message .= '<a href="' . $url . '">' . $url . '</a></p>';

$headers = "From: UTEM <krismalini23@gmail.com>\r\n";
$headers .= "Reply-To: krismalini23@gmail.com\r\n";
$headers .= "Content-type: text/html\r\n";

mail($to, $subject, $message, $headers);

echo ("<script language='javascript'>window.alert('Successfully reset your password!');window.location.href='forgot_password.php';</script>");

}
else
{
	header("Location:../index.php");
	exit();
}
?>