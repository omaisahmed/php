<?php

if(isset($_POST['reset-password']))
{
    // get values form input text and number
	
		$selector=$_POST['selector'];
		$validator=$_POST['validator'];
		$password=$_POST['password'];
		$password1=$_POST['password1'];

		if (empty($password) || empty($password1)) 
		{
			echo ("<script language='javascript'>window.alert('You must fill in all of the fields!');window.location.href='../create-new-password.php';</script>");
            exit();
        }
		else if($password != $password1) {
			echo ("<script language='javascript'>window.alert('Password mismatch!');window.location.href='../create-new-password.php';</script>");
            exit();
		}
		
		$currentDate = date("U");
		
		require "connect.php";
		
		$sql = "SELECT * FROM password_reset WHERE reset_selector=? AND reset_expires >= ?;";
		$stmt = mysqli_stmt_init($conn);
	    if(!mysqli_stmt_prepare($stmt,$sql)){
		echo ("<script language='javascript'>window.alert('There was an error!');</script>");
        exit();
	}
	else{
		mysqli_stmt_bind_param($stmt, "ss", $selector,$currentDate);
		mysqli_stmt_execute($stmt);
		
		$result = mysqli_stmt_get_result($stmt);
		if($row=mysqli_fetch_assoc($result)){
			echo ("<script language='javascript'>window.alert('You need to re-submit your reset request.!');</script>");
            exit();
			}
			else{
				$tokenBin = hex2bin($validator);
			$tokenCheck = password_verify($tokenBin, $row["reset_token"]);
			
			if($tokenCheck === false){
			echo ("<script language='javascript'>window.alert('You need to re-submit your reset request.!');</script>");
            exit();
			}
			else if($tokenCheck === true){
				
				$tokenEmail = $row['reset_email'];
				
				$sql = "SELECT * FROM users WHERE email=?;";
				$stmt = mysqli_stmt_init($conn);
				if(!mysqli_stmt_prepare($stmt,$sql)){
				echo ("<script language='javascript'>window.alert('There was an error!');</script>");
				exit();
				}
				else{
					mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
					mysqli_stmt_execute($stmt);
					$result = mysqli_stmt_get_result($stmt);
		            if($row=mysqli_fetch_assoc($result)){
			        echo ("<script language='javascript'>window.alert('There was an error.!');</script>");
                    exit();
		         	}
		        	else{
						
						$sql = "UPDATE users SET password=? WHERE email=?;";
						$stmt = mysqli_stmt_init($conn);
						if(!mysqli_stmt_prepare($stmt,$sql)){
						echo ("<script language='javascript'>window.alert('There was an error!');</script>");
						exit();
						}
						else{
							$newPwdHash = password_hash($password, PASSWORD_DEFAULT);
							mysqli_stmt_bind_param($stmt, "ss", $newPwdHash, $tokenEmail);
							mysqli_stmt_execute($stmt);
							
							$sql = "DELETE FROM password_reset WHERE reset_email=?;";
							$stmt = mysqli_stmt_init($conn);
							if(!mysqli_stmt_prepare($stmt,$sql)){
								echo ("<script language='javascript'>window.alert('There was an error!');</script>");
								exit();
							}
							else{
								mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
								mysqli_stmt_execute($stmt);
								echo ("<script language='javascript'>window.alert('Successfully Updated!!');window.location.href='../index.php';</script>");
							}
						}
					}
				}
			}
			}
	}
}
else{
	header("location:index.php");
	exit();
}
?>