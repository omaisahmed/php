
<?php 
//start session
session_start();
//database connection
include("connect.php");
$username = $_SESSION['username'];


$username = null;
if(isset($_GET["username"]))
{
$username = $_GET["username"];
}

$selectQry = "SELECT * FROM users WHERE username='".$username."' ";
			  
$resultSelect = mysqli_query($conn,$selectQry);
$rws = mysqli_fetch_array($resultSelect);

$user_id = $rws["user_id"];
$name = $rws["name"];
$email = $rws["email"];
$gender = $rws["gender"];
$role = $rws["role"];
$username = $rws["username"];

date_default_timezone_set("Asia/Kuala_Lumpur");
$current_date = date("Y-m-d H:i:s");

if(isset($_POST['submit']))
{
    // get values form input text and number
		
		$User_id = $rws["user_id"];
		$Username=$_POST['username'];
        $Name=$_POST['name'];
		$Email=$_POST['email'];
		$Password=$_POST['password'];
		$Gender=$_POST['gender'];
		$Role=$_POST['role'];
		$FB_Join_Date=$_POST['fb_join_date'];
		$Approval=1;

		$sql2 = "UPDATE users SET approval='$Approval' WHERE username='".$Username."';";
		$upd=mysqli_query($conn,$sql2);	
				

    // mysql query to insert data
	
	    if (empty($Name) || empty($Email) || empty($Username) || empty($Password)) 
		{
			echo ("<script language='javascript'>window.alert('You must fill in all of the fields!');window.location.href='register.php';</script>");
            exit();
        }
	
		else if (!filter_var($Email, FILTER_VALIDATE_EMAIL))
		{
            echo ("<script language='javascript'>window.alert('Invalid Email!');window.location.href='register.php';</script>");
            exit();
        }
			
        else if(!preg_match("/^[a-zA-Z]/", $Name))
		{
            echo ("<script language='javascript'>window.alert('Invalid Characters!');window.location.href='register.php';</script>");
            exit();
        }
        else if(!preg_match("/[0-9]/", $Password) && !preg_match("/[A-Z]/", $Password) && !preg_match("/[a-z]/", $Password) && !preg_match("/\d/", $Password) && !preg_match("/\W/", $Password)){
            echo ("<script language='javascript'>window.alert('Password contain Minimum 8 Character, Upper Case, Lower Case, Numeral and Speacial Character!');window.location.href='register.php';</script>");
            exit();
        }

        else{
             
			 $sql = "SELECT * FROM user_profile where username=?";
             $stmt = mysqli_stmt_init($conn);
		     if(!mysqli_stmt_prepare($stmt,$sql)){
				echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='register.php';</script>");
                exit();
            }
			else {
				mysqli_stmt_bind_param($stmt, "s", $Username);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
                $resultCheck = mysqli_stmt_num_rows($stmt);
                if($resultCheck > 0){
                   echo ("<script language='javascript'>window.alert('There is an existing account associated with this matric number!');window.location.href='register.php';</script>");
                exit(); 
                }
                else{           
                     $sql = "INSERT INTO user_profile(user_id,name,email,username,password,gender,role,fb_join_date) VALUES (?,?,?,?,?,?,?,?); ";
                     $stmt = mysqli_stmt_init($conn);
					 if(!mysqli_stmt_prepare($stmt,$sql)){
					echo ("<script language='javascript'>window.alert('SQL Error!');window.location.href='register.php';</script>");
					exit();
                }
				else {
				$hashedPwd = password_hash($Password, PASSWORD_DEFAULT);
				
				mysqli_stmt_bind_param($stmt, "ssssssss", $User_id, $Name, $Email, $Username, $hashedPwd, $Gender, $Role, $FB_Join_Date);
				mysqli_stmt_execute($stmt);

				$_SESSION['username']=$username;
			    if($Gender=="Male")
			{
				echo ("<script language='javascript'>window.alert('Successfully Registered!!');window.location.href='fb_files/fb_step/fb_step1/Step1_Male.php';</script>");
			}
			else
			{
				echo ("<script language='javascript'>window.alert('Successfully Registered!!');window.location.href='fb_files/fb_step/fb_step1/Step1_Female.php';</script>");
			}
		
            }
        }
}
}
mysqli_stmt_close($stmt);
mysqli_close($conn);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous"/>
	
  <!-- bootstrap js -->
	<link href="css/style2.css" rel="stylesheet" />
</head>
<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  <div style="position:absolute; left:60%; top:40%;"><a href="index.php" style="color:#ffffff; font-size:18px; font-weight:bold; text-transform:uppercase;">HOME</a></div>
	  <br></br><br></br>
    <div class="container">       
        <p class="h2 text-center">Create New Password</p></br>
        <form action="" method="post">
            <div class="preview text-center">
                <input type="hidden" name="user_id" value="<?php echo $user_id;?>" />
				<div class="form-group" align="left">
                <label >Username</label>
                <input class="form-control" type="text" name="username" value="<?php echo $username;?>" readonly  />
            </div>
            <div class="form-group" align="left">
                <label >Full Name</label>
                <input class="form-control" type="text" name="name" value="<?php echo $name;?>" readonly  />
            </div>
            <div class="form-group" align="left">
                <label>Email</label>
                <input class="form-control" type="email" name="email" value="<?php echo $email;?>" readonly />
            </div>
            <div class="form-group" align="left">
                <label>Password</label>
                <input class="form-control" type="password" name="password" required placeholder="Enter Password"/>
            </div>
			<input type="hidden" name="approval" value=""  class="form-control" />
			<input type="hidden" name="gender" value="<?php echo $gender;?>"  class="form-control" />
			<input type="hidden" name="role" value="<?php echo $role;?>"  class="form-control" />
			<input type="hidden" name="fb_join_date" value="<?php echo $current_date;?>"  class="form-control" />
            <div class="form-group">
                <input class="btn btn-primary btn-block" name="submit" type="submit" value="Submit"/>
            </div>
        </form>
    </div>
	
	<style>
	html,body
{
    width: 500px;
    margin: auto;
}
.container
{
    width: 500px;
    margin: 20px auto;
}

.preview
{
    padding: 10px;
    position: relative;
}

.preview i
{
    color: white;
    font-size: 35px;
    transform: translate(50px,130px);
}

.preview-img
{
    border-radius: 100%;
    box-shadow: 0px 0px 5px 2px rgba(0,0,0,0.7);
}

.browse-button
{
    width: 200px;
    height: 200px;
    border-radius: 100%;
    position: absolute; /* Tweak the position property if the element seems to be unfit */
    top: 10px;
    left: 132px;
    background: linear-gradient(180deg, transparent, black);
    opacity: 0;
    transition: 0.3s ease;
}

.browse-button:hover
{
    opacity: 1;
}

.browse-input
{
    width: 200px;
    height: 200px;
    border-radius: 100%;
    transform: translate(-1px,-26px);
    opacity: 0;
}

.form-group
{
    width:  250px;
    margin: 10px auto;
}

.form-group input
{
    transition: 0.3s linear;
}

.form-group input:focus
{
    border: 1px solid crimson;
    box-shadow: 0 0 0 0;
}

.Error
{
    color: crimson;
    font-size: 13px;
}

.Back
{
    font-size: 25px;
}
</style>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>

