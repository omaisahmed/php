-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2019 at 04:56 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_social_network_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(255) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile_pic` text NOT NULL,
  `cover_pic` text NOT NULL,
  `verify_id` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `hometown` varchar(255) NOT NULL,
  `quotes` text NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `activated` int(255) NOT NULL,
  `chatOnlineTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `username`, `password`, `profile_pic`, `cover_pic`, `verify_id`, `gender`, `role`, `country`, `city`, `hometown`, `quotes`, `mobile`, `bio`, `activated`, `chatOnlineTime`) VALUES
(1, 'KRISMALINI MURUGAN', 'krismalini23@gmail.com', 'krisma23', '$2y$10$zbdHY/fO5vE6sVXn4sr4POk64nL/qEB9E24G0MEyneqwGX3aKEkhC', 'krisma23/1573396397.jpg', 'krisma23/1573396444.jpg', 'no', 'Female', '', '', '', '', '', '+60 14678499', '', 0, '2019-11-10 14:57:02');

-- --------------------------------------------------------

--
-- Table structure for table `admin_comments`
--

CREATE TABLE `admin_comments` (
  `id` int(255) NOT NULL,
  `admin_body` text NOT NULL,
  `date_added` date NOT NULL,
  `time` datetime NOT NULL,
  `admin_by` varchar(255) NOT NULL,
  `admin_to` varchar(255) NOT NULL,
  `opened` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(255) NOT NULL,
  `faculty_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `faculty_name`) VALUES
(1, 'FACULTY OF ELECTRONICS AND COMPUTER ENGINEERING'),
(2, 'FACULTY OF ELECTRONICS AND COMPUTER ENGINEERING'),
(3, 'FACULTY OF ELECTRICAL ENGINEERING'),
(4, 'FACULTY OF MECHANICAL ENGINEERING'),
(5, 'FACULTY OF MANUFACTURING ENGINEERING'),
(6, 'FACULTY OF INFORMATION AND COMMUNICATIONS TECHNOLOGY'),
(7, 'FACULTY OF TECHNOLOGY MANAGEMENT AND TECHNOPRENEURSHIP'),
(8, 'FACULTY OF ELECTRICAL AND ELECTRONIC ENGINEERING TECHNOLOGY'),
(9, 'FACULTY OF MECHANICAL AND MANUFACTURING ENGINEERING TECHNOLOGY'),
(10, 'CENTRE FOR LANGUAGES AND HUMAN DEVELOPMENT');

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

CREATE TABLE `follow` (
  `id` int(11) NOT NULL,
  `user_from` varchar(32) NOT NULL,
  `user_to` varchar(32) NOT NULL,
  `time` datetime NOT NULL,
  `opened` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset`
--

CREATE TABLE `password_reset` (
  `reset_id` int(255) NOT NULL,
  `reset_email` varchar(100) NOT NULL,
  `reset_selector` varchar(100) NOT NULL,
  `reset_token` varchar(100) NOT NULL,
  `reset_expires` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `message_body` text NOT NULL,
  `date_added` date NOT NULL,
  `post_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(255) NOT NULL,
  `user_posted_to` varchar(255) NOT NULL,
  `share_post` int(11) NOT NULL,
  `message_post` int(11) NOT NULL,
  `message_give` tinyint(1) NOT NULL DEFAULT '0',
  `discription` text NOT NULL,
  `photos` text NOT NULL,
  `newsfeedshow` tinyint(1) NOT NULL DEFAULT '1',
  `report` tinyint(1) NOT NULL DEFAULT '0',
  `note` tinyint(1) NOT NULL DEFAULT '0',
  `note_privacy` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `message_body`, `date_added`, `post_time`, `added_by`, `user_posted_to`, `share_post`, `message_post`, `message_give`, `discription`, `photos`, `newsfeedshow`, `report`, `note`, `note_privacy`) VALUES
(230, 'hi', '', '2019-11-08', '2019-11-08 20:33:15', 'B0998877', 'B0998877', 0, 0, 0, '', '', 1, 0, 0, ''),
(231, 'hi', '', '2019-11-08', '2019-11-08 20:36:15', 'B0998877', 'B0998877', 0, 0, 0, '', '', 1, 0, 0, ''),
(232, 'bye', '', '2019-11-08', '2019-11-08 20:42:05', 'B0998877', 'B0998877', 0, 0, 0, '', '', 1, 0, 0, ''),
(233, 'bye', '', '2019-11-08', '2019-11-08 20:42:36', 'B0998877', 'B0998877', 0, 0, 0, '', '', 1, 0, 0, ''),
(234, 'hello', '', '2019-11-08', '2019-11-08 20:47:52', 'B0998877', 'B0998877', 0, 0, 0, '', '', 1, 0, 0, ''),
(235, '', '', '2019-11-09', '2019-11-09 10:20:28', 'B0998877', 'B0998877', 0, 0, 0, 'changed her profile picture.', 'B0998877/1573294828.png', 1, 0, 0, ''),
(236, '', '', '2019-11-09', '2019-11-09 10:21:26', 'B0998877', 'B0998877', 0, 0, 0, 'updated her cover photo.', 'B0998877/1573294886.jpg', 1, 0, 0, ''),
(239, 'As a Focus University, UTeM boasts strengths in technical fields â€“ namely Engineering, IT,\r\nand Management Technology. UTeM has cemented a reputation of being a source of high-\r\nquality engineering graduates with the capability of meeting the requirements of high-tech\r\nindustries. UTeM also has research competencies in areas that it has identified as being\r\nkey to enhancing the Universityâ€™s unique proposition and also contributes to the nation\r\nsuch as Green Technology, Systems Engineering, Human-Technology Interaction,\r\nand Emerging Technology.\r\n\r\nUTeM admits not only local but also international students and this includes students from\r\nIndonesia, Saudi Arabia, Chad, Syria, Pakistan, Cameroon, Bangladesh, Tanzania, India,\r\nSomalia, Singapore, Qatar, Palestine, Libya, Iraq, Iran, Ghana, France, Yemen, Nigeria\r\nand Jordan.', '', '2019-11-10', '2019-11-10 07:34:52', 'B0998877', 'B0998877', 0, 0, 0, '', '', 1, 0, 0, ''),
(240, 'hi', '', '2019-11-10', '2019-11-10 13:28:39', 'krisma23', 'krisma23', 0, 0, 0, '', '', 1, 0, 0, ''),
(241, 'hi', '', '2019-11-10', '2019-11-10 13:32:56', 'krisma23', 'krisma23', 0, 0, 0, '', '', 1, 0, 0, ''),
(242, 'bye', '', '2019-11-10', '2019-11-10 14:05:40', 'krisma23', 'krisma23', 0, 0, 0, '', '', 1, 0, 0, ''),
(243, '', '', '2019-11-10', '2019-11-10 14:33:17', 'krisma23', 'krisma23', 0, 0, 0, 'changed her profile picture.', 'krisma23/1573396397.jpg', 1, 0, 0, ''),
(244, '', '', '2019-11-10', '2019-11-10 14:34:04', 'krisma23', 'krisma23', 0, 0, 0, 'updated her cover photo.', 'krisma23/1573396444.jpg', 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `id` int(11) NOT NULL,
  `post_body` text NOT NULL,
  `date_added` date NOT NULL,
  `time` datetime NOT NULL,
  `posted_by` varchar(255) NOT NULL,
  `posted_to` varchar(255) NOT NULL,
  `opened` varchar(3) NOT NULL DEFAULT 'no',
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`id`, `post_body`, `date_added`, `time`, `posted_by`, `posted_to`, `opened`, `post_id`) VALUES
(1, 'hi', '2019-11-09', '2019-11-10 05:06:19', 'B0998877', 'B0998877', 'no', 235),
(2, 'bye', '2019-11-09', '2019-11-10 05:06:27', 'B0998877', 'B0998877', 'no', 235),
(3, 'hi', '2019-11-10', '2019-11-10 14:48:05', 'B0998877', 'B0998877', 'no', 236),
(4, 'hi', '2019-11-10', '2019-11-10 15:38:13', 'B0998877', 'B0998877', 'no', 239),
(5, 'hi', '2019-11-10', '2019-11-10 22:56:23', 'krisma23', 'krisma23', 'no', 245),
(6, 'bye', '2019-11-10', '2019-11-10 22:56:27', 'krisma23', 'krisma23', 'no', 245),
(7, 'hi', '2019-11-10', '2019-11-10 22:56:45', 'krisma23', 'krisma23', 'no', 243),
(8, 'nice', '2019-11-10', '2019-11-10 22:56:49', 'krisma23', 'krisma23', 'no', 243);

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `id` int(11) NOT NULL,
  `user_name` varchar(15) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`id`, `user_name`, `post_id`) VALUES
(2, 'B0998877', 236),
(3, 'B0998877', 235),
(4, 'B0998877', 239),
(6, 'krisma23', 243),
(7, 'krisma23', 244);

-- --------------------------------------------------------

--
-- Table structure for table `programmes`
--

CREATE TABLE `programmes` (
  `programme_id` int(255) NOT NULL,
  `faculty_id` int(255) DEFAULT NULL,
  `programme_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `programmes`
--

INSERT INTO `programmes` (`programme_id`, `faculty_id`, `programme_name`) VALUES
(1, 1, 'Diploma in Electronics Engineering'),
(2, 1, 'Bachelor of Electronics Engineering With Honours'),
(3, 1, 'Bachelor of Computer Engineering With Honours'),
(4, 2, 'Diploma in Electrical Engineering'),
(5, 2, 'Bachelor of Electrical Engineering With Honours'),
(6, 2, 'Bachelor of Mechatronics Engineering With Honours'),
(7, 3, 'Diploma in Mechanical Engineering'),
(8, 3, 'Bachelor of Mechanical Engineering With Honours'),
(9, 4, 'Diploma in Manufacturing Engineering'),
(10, 4, 'Bachelor of Manufacturing Engineering With Honours'),
(11, 5, 'Diploma in Information Technology'),
(12, 5, 'Bachelor of Computer Science (Software Development) With Honours'),
(13, 5, 'Bachelor of Computer Science (Computer Networking) With Honours'),
(14, 5, 'Bachelor of Computer Science (Database Management) With Honours'),
(15, 5, 'Bachelor of Computer Science (Interactive Media) With Honours'),
(16, 5, 'Bachelor of Computer Science (Artificial Intelligence) With Honours'),
(17, 5, 'Bachelor of Computer Science (Computer Security) With Honours'),
(18, 5, 'Bachelor of Information Technology (Games Technology) With Honours'),
(19, 6, 'Bachelor Of Technology Management With Honours (Technology Innovation)'),
(20, 6, 'Bachelor Of Technology Management With Honours (High Technology Marketing)'),
(21, 6, 'Bachelor of Technopreneurship With Honours'),
(22, 6, 'Bachelor of Technology Management (Supply Chain Management and Logistics) with Honours'),
(23, 7, 'Bachelor of Electrical Engineering Technology (Industrial Power) With Honours'),
(24, 7, 'Bachelor of Electrical Engineering Technology (Industrial Automation And Robotics) With Honours'),
(25, 7, 'Bachelor of Electronics Engineering Technology (Telecommunications) With Honours'),
(26, 7, 'Bachelor of Electronics Engineering Technology (Industrial Electronics) With Honours'),
(27, 7, 'Bachelor of Computer Engineering Technology (Computer Systems) With Honours'),
(28, 7, 'Bachelor of Electrical Engineering Technology With Honours'),
(29, 7, 'Bachelor of Electronics Engineering Technology With Honours'),
(30, 8, 'Bachelor of Mechanical Engineering Technology (Automotive Technology) With Honours'),
(31, 8, 'Bachelor of Mechanical Engineering Technology (Refrigeration And Air Conditioning Systems) With Hono'),
(32, 8, 'Bachelor of Mechanical Engineering Technology (Maintenance Technology) With Honours'),
(33, 8, 'Bachelor of Manufacturing Engineering Technology (Process And Technology) With Honours'),
(34, 8, 'Bachelor of Manufacturing Engineering Technology (Product Design) With Honours'),
(35, 8, 'Bachelor of Mechanical Engineering Technology With Honours'),
(36, 8, 'Bachelor of Manufacturing Engineering Technology With Honours'),
(37, 9, 'Department of Languages'),
(38, 9, 'Department of Islamic Studies & Humanities'),
(39, 9, 'Department of Human Development'),
(40, 9, 'Department of Co-Curiculum Studies');

-- --------------------------------------------------------

--
-- Table structure for table `pvt_messages`
--

CREATE TABLE `pvt_messages` (
  `id` int(11) NOT NULL,
  `user_from` varchar(255) NOT NULL,
  `user_to` varchar(255) NOT NULL,
  `msg_body` text NOT NULL,
  `date` date NOT NULL,
  `msg_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `opened` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `programme` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `approval` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `role`, `username`, `programme`, `gender`, `date_of_birth`, `approval`) VALUES
(1, 'Abu Manik', 'abu@gmail.com', 'Student', 'B0123456', '16', 'Male', '19-10-2004', 1),
(2, 'Amira Hidayah', 'amira@gmail.com', 'Lecturer', 'A0823988', '15', 'Female', '15-7-2012', 1),
(3, 'Chen Seng', 'chen@gmail.com', 'Student', 'B0998877', '2', 'Female', '18-10-2004', 1),
(4, 'Maniam Maruthu', 'vani@gmail.com', 'Student', 'B00112233', '34', 'Male', '16-9-2003', 1),
(6, 'Ben Gen', 'ben@gmail.com', 'Student', 'B0012234', '33', 'Male', '17-11-2002', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `profile_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `profile_pic` text NOT NULL,
  `cover_pic` text NOT NULL,
  `fb_join_date` varchar(100) NOT NULL,
  `verify_id` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `hometown` varchar(255) NOT NULL,
  `activated` int(255) NOT NULL,
  `bio` text NOT NULL,
  `quotes` text NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `chatOnlineTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`profile_id`, `user_id`, `name`, `email`, `username`, `password`, `gender`, `role`, `profile_pic`, `cover_pic`, `fb_join_date`, `verify_id`, `country`, `city`, `hometown`, `activated`, `bio`, `quotes`, `mobile`, `chatOnlineTime`) VALUES
(1, 1, 'Abu Manik', 'abu@gmail.com', 'B0123456', '$2y$10$2dme1wd9YsMCPY2pRuf79e.XzIZgXML5/4yVZTxtg4U/zopNtOaaa', 'Male', 'Student', '', '', '2019-11-08 15:44:11', '', '', '', '', 0, '', '', '0', '2019-11-08 17:47:56'),
(2, 2, 'Amira Hidayah', 'amira@gmail.com', 'A0823988', '$2y$10$Muep1sMyK3znOFp1NjaYP.edyV0tSzbHVRZYLFHaGEHi5PxVzO3DK', 'Female', 'Lecturer', '', '', '2019-11-08 15:47:39', '0', '', '', '', 0, '', '', '0', '2019-11-08 14:19:06'),
(14, 4, 'Maniam Maruthu', 'vani@gmail.com', 'B00112233', '$2y$10$sUW/LZMZFrhoZxd3R9OqZuSmkToPQ.9Id4FqGIT.BgRWuMahVkUWa', 'Male', 'Student', '', '', '2019-11-08 17:05:28', '0', '', '', '', 0, '', '', '0', '2019-11-08 14:19:06'),
(22, 6, 'Ben Gen', 'ben@gmail.com', 'B0012234', '$2y$10$bHQk37LV4zX/hlOS6mH9ie.oyp7.SoZz3EEXiYoE9CwsgaMerWgv2', 'Male', 'Student', '', '', '2019-11-08 20:28:30', 'no', '', '', '', 0, '', '', '0', '2019-11-08 17:48:04'),
(24, 3, 'Chen Seng', 'chen12@gmail.com', 'B0998877', '$2y$10$S49TeZ4widNELsg6L6wNseRbf9dqv8xA6frB047hXiUHYRSX3FMc2', 'Female', 'Student', 'B0998877/1573294828.png', 'B0998877/1573294886.jpg', '2019-11-08 20:38:02', 'no', 'Malaysia', 'Klang', 'Selangor', 1, 'I\'m a student. I like to eat nasi lemak.', 'Life is a train.', '+60 14678455', '2019-11-10 14:07:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile_pic`
--

CREATE TABLE `user_profile_pic` (
  `pic_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_profile_pic`
--

INSERT INTO `user_profile_pic` (`pic_id`, `user_id`, `image`) VALUES
(2, 6, 'Member.jpg'),
(3, 3, 'logo2.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `admin_comments`
--
ALTER TABLE `admin_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `follow`
--
ALTER TABLE `follow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset`
--
ALTER TABLE `password_reset`
  ADD PRIMARY KEY (`reset_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programmes`
--
ALTER TABLE `programmes`
  ADD PRIMARY KEY (`programme_id`),
  ADD KEY `faculty_id` (`faculty_id`);

--
-- Indexes for table `pvt_messages`
--
ALTER TABLE `pvt_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`profile_id`);

--
-- Indexes for table `user_profile_pic`
--
ALTER TABLE `user_profile_pic`
  ADD PRIMARY KEY (`pic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_comments`
--
ALTER TABLE `admin_comments`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `follow`
--
ALTER TABLE `follow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `password_reset`
--
ALTER TABLE `password_reset`
  MODIFY `reset_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `programmes`
--
ALTER TABLE `programmes`
  MODIFY `programme_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `pvt_messages`
--
ALTER TABLE `pvt_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `profile_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_profile_pic`
--
ALTER TABLE `user_profile_pic`
  MODIFY `pic_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `programmes`
--
ALTER TABLE `programmes`
  ADD CONSTRAINT `programmes_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
