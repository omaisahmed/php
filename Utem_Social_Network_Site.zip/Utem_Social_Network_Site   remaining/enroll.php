
<html>
<head>
	<title>UTEM STUDENT SOCIAL NETWORK SITE SYSTEM</title>
	<link href="css/style2.css" rel="stylesheet" />
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">
	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script type="text/javascript" src="../../../../fb_files/fb_index_file/fb_js_file/Registration_validation.js"> </script>
	<link href="step1_css/step1.css" rel="stylesheet" type="text/css">
    <link href="../../fb_font/font.css" rel="stylesheet" type="text/css">
    <LINK REL="SHORTCUT ICON" HREF="../../fb_title_icon/Faceback.ico" />
	<script src="step1_js/Image_check.js" language="javascript">
	</script>
</head>
<body>
<header>
      <div id="logo">
	  <img class="img" src="images/UtemLogo.png" alt="" width="60" height="60" title=""/>
      <h1><a href="">STUDENT SOCIAL NETWORK SITE</a></h1>
      </div>
	  <div style="position:absolute; left:60%; top:40%;"><a href="index.php" style="color:#ffffff; font-size:18px; font-weight:bold; text-transform:uppercase;">HOME</a></div>
	  <form  action="verify.php" method="post">
		<div class="container box">  
		<div class="form-group"><br/>    
		<h3 align="center" style="font-size:26px; font-weight:bold;">Enroll Your Account</h3><br/>  
		<label style="font-size:16px;">Matric No. / Lecturer ID</label>  
		<input type="text" name="username" id="username" placeholder="Enter Your Matric No./Lecturer ID" class="form-control" />
		<br /><br />
		<div class="form-group submitButtonFooter" style="position:absolute; left:69%; top:400%; ">
		<button type="submit" name="verify" class="btn btn-primary">Enroll</button>
		<br />
		</div></div>    
		<br />  
		<br />  
		</div>  
		</form>

  <style>  
  body  
  {  
   margin:0;  
   padding:0;  
   background-color:#f1f1f1;  
  }  
  .box  
  {  
   width:800px;  
   border:1px solid #ccc;  
   background-color:#fff;  
   border-radius:5px;
   margin-top:150px;  
  }  
  </style>  
</body>
</html>




