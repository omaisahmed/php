<?php

/**
 * This class must contains logic to load messages to db
*/
class LoadMessagesToDB {

}

?>