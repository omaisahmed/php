<?php
$firstname=$_POST["firstname"];
$lastname=$_POST["lastname"];
$email=$_POST["email"];
$password=$_POST["password"];


$login=$_POST["loginemail"];
$pass=$_POST["loginpass"];


$connect=mysqli_connect("localhost","root","","bootstrap-shop");
$sql="insert into register(Firstname,Lastname,Email,Password) values('$firstname','$lastname','$email','$password')";
$result=$connect->query($sql);


$sql="select * from bootstrap-shop ORDER BY id DESC LIMIT 1;";
$result=$connect->query($sql);
$row=$result->fetch_assoc();
 


$e=$row["email"];
$p=$row["password"];

if($e==$login && $p==$pass){
	echo "<script>alert('Login Properly')</script>";
}
else{
	echo "<script>alert('Login Failure')</script>";
}




//echo "<script>alert('login successfully!')</script>";
?>