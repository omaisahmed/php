-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2019 at 08:07 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `examuser`
--

CREATE TABLE `examuser` (
  `loginid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examuser`
--

INSERT INTO `examuser` (`loginid`, `password`) VALUES
('farhan', '123'),
('', ''),
('omais', '123'),
('omais', '123'),
('', ''),
('', ''),
('', ''),
('', ''),
('omais', '123'),
('', ''),
('', ''),
('omais', '123'),
('', ''),
('omais', '123'),
('', ''),
('omais', '123'),
('', ''),
('omais', '123'),
('', ''),
('', ''),
('', ''),
('omais', '123'),
('omais', '123'),
('omais', '123'),
('', ''),
('omais', '123'),
('omais', '123'),
('omais', '123'),
('', ''),
('', ''),
('omais', '123'),
('omais', '123'),
('omais', '123'),
('omais', '123'),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('omais', '123'),
('omais', '123');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(4) NOT NULL,
  `q` varchar(200) NOT NULL,
  `op1` varchar(50) NOT NULL,
  `op2` varchar(50) NOT NULL,
  `op3` varchar(50) NOT NULL,
  `op4` varchar(50) NOT NULL,
  `ans` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `q`, `op1`, `op2`, `op3`, `op4`, `ans`, `subject`) VALUES
(1, 'What does HTML stand for?', 'Home Tool Markup Language', 'Hyperlinks and Text Markup Language', 'Hyper Text Markup Language', 'None of the above', 'Hyper Text Markup Language', 'HTML'),
(2, 'Who is making the Web standards?', 'The World Wide Web Consortium', 'Google', 'Yahoo', 'Microsoft', 'The World Wide Web Consortium', 'HTML'),
(3, 'Choose the correct HTML element for the largest heading:', '<head>', 'heading', 'h1', '<h6>', '<h1>', 'HTML'),
(4, 'What is the correct HTML element for inserting a line break?', '<br>', 'lb', 'break', 'None of these', '<br>', 'HTML'),
(1, ' Inside which HTML element do we put the JavaScript?', '<javascript>', 'scripting', 'script', '<js>', '<script>', 'JAVA SCRIPTING'),
(2, 'What is the correct JavaScript syntax to change the content of the HTML element below?<br><p id=\"demo\">This is a demonstration.</p>', 'document.getElementByName(\"p\").innerHTML = \"Hello ', '#demo.innerHTML = \"Hello World!\";', 'document.getElementById(\"demo\").innerHTML = \"Hello', 'document.getElement(\"p\").innerHTML = \"Hello World!', 'document.getElementById(\"demo\").innerHTML = \"Hello', 'JAVA SCRIPTING');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `qid` int(4) NOT NULL,
  `q` varchar(500) NOT NULL,
  `op1` varchar(50) NOT NULL,
  `op2` varchar(50) NOT NULL,
  `op3` varchar(50) NOT NULL,
  `op4` varchar(50) NOT NULL,
  `ans` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`qid`, `q`, `op1`, `op2`, `op3`, `op4`, `ans`, `subject`) VALUES
(1, 'A hollow iron pipe is 21 cm long and its external diameter is 8 cm. If the thickness of the pipe is 1 cm and iron weighs 8 g/cm3, then the weight of the pipe is:', '3.6 kg', '3.696 kg', '36 kg', '36.9 kg', '3.6 kg', 'Aptitude Test - Random'),
(2, '	 Excluding stoppages, the speed of a bus is 54 kmph and including stoppages, it is 45 kmph. For how many minutes does the bus stop per hour?', '9', '10', '12', '20', '10', 'Aptitude Test - Random'),
(3, 'Two pipes A and B can fill a cistern in 37 minutes and 45 minutes respectively. Both pipes are opened. The cistern will be filled in just half an hour, if the B is turned off after:', '5 min', '9 min.', '10 min.', '15 min.', '9 min', 'Aptitude Test - Random'),
(4, 'If 0.75 : x :: 5 : 8, then x is equal to:', '1.12', '1.2', '1.25', '1.30', '1.2', 'Aptitude Test - Random'),
(5, 'The banker\'s gain on a bill due 1 year hence at 12% per annum is Rs. 6. The true discount is:', 'Rs. 72', 'Rs. 36', 'Rs. 54', 'Rs. 50', 'Rs. 50', 'Aptitude Test - Random'),
(6, 'A flagstaff 17.5 m high casts a shadow of length 40.25 m. The height of the building, which casts a shadow of length 28.75 m under similar conditions will be:', '10 m', '12.5 m', '17.5 m', '21.25 m', '12.5 m', 'Aptitude Test - Random'),
(7, 'If a quarter kg of potato costs 60 price, how many price will 200 gm cost?', '48 price', '54 price', '56 price', '72 price', '48 price', 'Aptitude Test - Random'),
(8, 'A trader owes a merchant Rs. 10,028 due 1 year hence. The trader wants to settle the account after 3 months. If the rate of interest 12% per annum, how much cash should he pay?', 'Rs. 9025.20', 'Rs. 9200', 'Rs. 9600', 'Rs. 9560', 'Rs. 9200', 'Aptitude Test - Random'),
(9, 'In how many ways can a group of 5 men and 2 women be made out of a total of 7 men and 3 women?', '63', '90', '126', '45', '63', 'Aptitude Test - Random'),
(10, '	\r\nSachin is younger than Rahul by 7 years. If their ages are in the respective ratio of 7 : 9, how old is Sachin?', '16 years', '18 years', '28 years', '24.5 years', '24.5 years', 'Aptitude Test - Random'),
(11, '	\r\nA 300 metre long train crosses a platform in 39 seconds while it crosses a signal pole in 18 seconds. What is the length of the platform?', '320 m', '350 m', '650 m', 'Data inadequate', '350 m', 'Aptitude Test - Random'),
(12, 'A train 360 m long is running at a speed of 45 km/hr. In what time will it pass a bridge 140 m long?', '40 sec', '42 sec', '45 sec', '48 sec', '40 sec', 'Aptitude Test - Random'),
(13, 'Find out the wrong number in the given sequence of numbers:\r\n8, 13, 21, 32, 47, 63, 83', '47', '63', '32', '83', '47', 'Aptitude Test - Random'),
(14, 'Work done will be maximum if the angle between the force F and displacement d is', '45', '90', '180', '0', '0', 'Aptitude Test - Random'),
(15, 'A field in which the work done in a moving a body along closed path is zero is called', 'electric field', 'conservative field', 'electromagnetic field', 'gravitational field', 'conservative field', 'Aptitude Test - Random');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
