<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>HTML Education Template</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Lato:700%7CMontserrat:400,600" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="css/style.css"/>

	<script	src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		<script type="text/javascript">
			
			function options(){
	
	var inputs = document.querySelectorAll('input[type="radio"]');
for (var i = 0; i < inputs.length; i++) {
  inputs[i].disabled = 'true';
}
}

			
		</script>
    </head>
	<body onload="options()">

		<!-- Header -->
		<header id="header">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a class="logo" href="home.php">
							<img src="./img/logo1.png" alt="logo">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Mobile toggle -->
					<button class="navbar-toggle">
						<span></span>
					</button>
					<!-- /Mobile toggle -->
				</div>

				<!-- Navigation -->
				<nav id="nav">
					<ul class="main-menu nav navbar-nav navbar-right">
						<li><a href="home.php">Home</a></li>
						<li><a href="#">About</a></li>
						<li><a href=blog.html>Blog</a></li>
						
						<li><a href="quiz.php">Quizzes</a></li>
						<li><a href="contact.html">Contact</a></li>
					</ul>
				</nav>
				<!-- /Navigation -->

			</div>
		</header>
		<!-- /Header -->

		<!-- Hero-area -->
		

		

		<!-- Blog -->
<?php
session_start();
//error_reporting(0);
$a=$_POST["qid"];
$b=$_POST["s"];

$servername="localhost";
$uname="root";
$password="";
$dbname="onlineexam";

$connect=new MySQLi($servername,$uname,$password,$dbname);

echo "<div class='table-responsive-sm'>";
echo "<table class=table border=1 align=center>";
echo "<tr bgcolor='black'><th colspan=2><h3 align=center><font color=white>$b Quiz</font></tr></th></h3>";

$sql="select * from quiz";
$result=$connect->query($sql);
while($row=$result->fetch_array()){
    $qid=$row["qid"];
    $question = $row['q'];
    $option_a = $row['op1'];
    $option_b =$row['op2'];
    $option_c = $row['op3'];
    $option_d = $row['op4'];
    $answer = $row['ans'];

$c=$a+1;

//$anspost=$_GET["p1"];
if (isset($_POST["p1"]))
{
$ans1=$_POST["p1"];
//$ans1=$_SESSION["p1"];
echo "$ans1";
}
echo "<tr bgcolor='lightgrey'><td align=center width=2%><b>Q.$qid</b></td><td><b>$question</b></td></tr>";
echo "<tr><td align=center><input type=radio name=p1 id=r1 value=off onclick='options()'></td><td>$option_a</td></tr>";
echo "<tr><td align=center><input type=radio  name=p1 id=r2 value=off onclick='options()'></td><td>$option_b</td></tr>";
echo "<tr><td align=center><input type=radio name=p1 id=r3 value=off onclick='options()'></td><td>$option_c</td></tr>";
echo "<tr><td align=center><input type=radio name=p1 id=r4 value=off onclick='options()'></td><td>$option_d</td></tr>";

//$sql2="select * from quiz order by qid asc";
//$result2=$connect->query($sql2);
//while($row2=$result2->fetch_array()){
//$answer=$row2["ans"];
echo "<tr><td align=center>Your Answer</td><td><span style='color:blue'>$ans1</span></td></tr>";
echo "<tr><td align=center>Right Answer</td><td><span style='color:blue'>$answer</span></td></tr>";


}

//echo "<input type=hidden value='$c' name=qid>";
//echo "<input type=hidden value='$b' name=s>";
//echo "<input type=hidden value='$marks' name='marks'>";





echo "</table>";
echo "</div>";






?>		

		<!-- Footer -->
		<footer id="footer" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				<div class="row">

					

				</div>
				<!-- /row -->

				<!-- row -->
				<div id="bottom-footer" class="row">

					<!-- social -->
					<div class="col-md-4 col-md-push-8">
						<ul class="footer-social">
							<li><a href="#" class="facebook"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#" class="instagram"><i class="fa fa-instagram"></i></a></li>
							<li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>
							<li><a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
					<!-- /social -->

					<!-- copyright -->
					<div class="col-md-8 col-md-pull-4">
						<div class="footer-copyright">
							<span>&copy; Copyright 2018. All Rights Reserved. | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com">Colorlib</a></span>
						</div>
					</div>
					<!-- /copyright -->

				</div>
				<!-- row -->

			</div>
			<!-- /container -->

		</footer>
		<!-- /Footer -->

		<!-- preloader -->
		<div id='preloader'><div class='preloader'></div></div>
		<!-- /preloader -->


		<!-- jQuery Plugins -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/main.js"></script>

	</body>
</html>
